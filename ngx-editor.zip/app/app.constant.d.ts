export declare class Constants {
    static SUPPORTED_IMAGE_TYPES: string[];
    static MAXIMUM_IMAGE_SIZE: number;
}
