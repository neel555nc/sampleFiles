/**
 * enable or disable toolbar based on configuration
 *
 * @param value toolbar item
 * @param toolbar toolbar configuration object
 */
export declare function canEnableToolbarOptions(value: string, toolbar: any): boolean;
/**
 * set editor configuration
 *
 * @param value configuration via [config] property
 * @param ngxEditorConfig default editor configuration
 * @param input direct configuration inputs via directives
 */
export declare function getEditorConfiguration(value: any, ngxEditorConfig: any, input: any): any;
/**
 * return vertical if the element is the resizer property is set to basic
 *
 * @param resizer type of resizer, either basic or stack
 */
export declare function canResize(resizer: string): any;
/**
 * save selection when the editor is focussed out
 */
export declare function saveSelection(): any;
/**
 * restore selection when the editor is focussed in
 *
 * @param range saved selection when the editor is focussed out
 */
export declare function restoreSelection(range: any): boolean;
/**
 * restore toolbar formatting when the user moves the cursor
 *
 * @param selection current selection when the user moves the cursor
 */
export declare function checkFormatting(selection: any): any;
/**
 * find index of element inside parent.
 *
 * @returns- index number.
 */
export declare function getIndex(element: HTMLElement): number;
/**
 * get closest parent element as per given input selector.
 *
 * @param element- base element.
 * @param selector- css selector to find in parent tree.
 * @returns- html element with match.
 */
export declare function getClosest(element: any, selector: string): HTMLElement;
/**
 * get immediate children element list using tag name.
 *
 * @param element- parent element.
 * @param tagName- children element tag name.
 * @returns- get immediate children.
 */
export declare function getImmediateChildrenUsingTagName(element: HTMLElement, tagName: string): HTMLElement[];
/**
 * manually trigger 'input' event on given 'contenteditable' element.
 *
 * @param element - reference HTML element.
 */
export declare function triggerContentEditableInputEvent(element: HTMLElement): void;
