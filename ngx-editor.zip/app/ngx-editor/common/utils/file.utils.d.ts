export declare class FileUtils {
    private _fileName;
    private _fileType;
    private _fileSize;
    private _supportedFileTypes;
    private _maximumFileSize;
    constructor(_fileName?: string, _fileType?: string, _fileSize?: number);
    fileName: string;
    fileType: string;
    supportedFileTypes: string[];
    maximumFileSize: number;
    isValidFileType(): boolean;
    isValidFileSize(): boolean;
}
