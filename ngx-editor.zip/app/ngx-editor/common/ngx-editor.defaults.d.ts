/**
 * toolbar default configuration
 */
export declare const ngxEditorConfig: {
    editable: boolean;
    spellcheck: boolean;
    height: string;
    minHeight: string;
    width: string;
    minWidth: string;
    translate: string;
    enableToolbar: boolean;
    showToolbar: boolean;
    isMoreShow: boolean;
    placeholder: string;
    image: {
        apiDetail: {
            endPoint: string;
            method: string;
            headers: {
                scope: string;
                readonly orgCode: string;
                readonly usertoken: string;
            };
        };
    };
    table: {
        popoverRowsLength: number;
        popoverColumnsLength: number;
    };
    toolbar: string[][];
};
