export declare class NgxEditorModule {
}
