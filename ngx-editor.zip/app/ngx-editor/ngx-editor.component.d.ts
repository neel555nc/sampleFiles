import { OnInit, EventEmitter, Renderer2, OnChanges, AfterViewInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ContextMenu } from 'primeng/primeng';
import { CommandExecutorService } from './common/services/command-executor.service';
import { MessageService } from './common/services/message.service';
import { NgxEditorToolbarComponent } from './ngx-editor-toolbar/ngx-editor-toolbar.component';
export declare class NgxEditorComponent implements OnInit, ControlValueAccessor, OnChanges, AfterViewInit, OnDestroy {
    private _messageService;
    private _commandExecutor;
    private _renderer;
    /** Specifies weather the textarea to be editable or not */
    editable: boolean;
    /** The spellcheck property specifies whether the element is to have its spelling and grammar checked or not. */
    spellcheck: boolean;
    /** Placeholder for the textArea */
    placeholder: string;
    /**
     * The translate property specifies whether the content of an element should be translated or not.
     *
     * Check https://www.w3schools.com/tags/att_global_translate.asp for more information and browser support
     */
    translate: string;
    /** Sets height of the editor */
    height: string;
    /** Sets minimum height for the editor */
    minHeight: string;
    /** Sets Width of the editor */
    width: string;
    /** Sets minimum width of the editor */
    minWidth: string;
    /**
     * Toolbar accepts an array which specifies the options to be enabled for the toolbar
     *
     * Check ngxEditorConfig for toolbar configuration
     *
     * Passing an empty array will enable all toolbar
     */
    toolbar: Object;
    /**
     * The editor can be resized vertically.
     *
     * `basic` resizer enables the html5 reszier. Check here https://www.w3schools.com/cssref/css3_pr_resize.asp
     *
     * `stack` resizer enable a resizer that looks like as if in https://stackoverflow.com
     */
    resizer: string;
    /**
     * The config property is a JSON object
     *
     * All avaibale inputs inputs can be provided in the configuration as JSON
     * inputs provided directly are considered as top priority
     */
    config: {
        editable: boolean;
        spellcheck: boolean;
        height: string;
        minHeight: string;
        width: string;
        minWidth: string;
        translate: string;
        enableToolbar: boolean;
        showToolbar: boolean;
        isMoreShow: boolean;
        placeholder: string;
        image: {
            apiDetail: {
                endPoint: string;
                method: string;
                headers: {
                    scope: string;
                    readonly orgCode: string;
                    readonly usertoken: string;
                };
            };
        };
        table: {
            popoverRowsLength: number;
            popoverColumnsLength: number;
        };
        toolbar: string[][];
    };
    /** Weather to show or hide toolbar */
    showToolbar: boolean;
    /** Weather to enable or disable the toolbar */
    enableToolbar: boolean;
    /** Endpoint for which the image to be uploaded */
    imageEndPoint: string;
    /** List of custom buttons if any */
    customButtonsArray: any;
    setFocus: boolean;
    /**
     * If this flag is 'true', pasted text will be converted to 'plain'
     * and no styles will be imported from copied text.
     */
    pasteAsPlainText: boolean;
    languageCode: string;
    /** emits `blur` event when focused out from the textarea */
    blur: EventEmitter<string>;
    /** emits `focus` event when focused in to the textarea */
    focus: EventEmitter<string>;
    /** emits `triggerCustomClick` event when custombutton is clicked -> returns btntext to identify which button clicked */
    triggerCustomClick: EventEmitter<any>;
    change: EventEmitter<any>;
    optionClicked: EventEmitter<any>;
    /** emits message to parent component. */
    triggerMessage: EventEmitter<string>;
    /** when popover is show/hide. */
    showPopOver: EventEmitter<any>;
    hidePopOver: EventEmitter<any>;
    textArea: any;
    ngxWrapper: any;
    ngxToolbar: NgxEditorToolbarComponent;
    Utils: any;
    private onChange;
    private onTouched;
    private pasteEventListener;
    IS_IE: boolean;
    /** saves the selection from the editor when focussed out */
    savedSelection: any;
    languageObj: any;
    /** 'ngx-editor-table-container' class is used to bind event. */
    TABLE_CONTAINER_CLASS: string;
    /**
     * table html template.
     * template change will impact 'CSS Selector' used in code.
     */
    TABLE_TEMPLATES: any;
    tableCellContextMenu: ContextMenu;
    tableCellContextMenuData: any;
    /**
     * @param _messageService service to send message to the editor message component
     * @param _commandExecutor executes command from the toolbar
     * @param _renderer access and manipulate the dom element
     */
    constructor(_messageService: MessageService, _commandExecutor: CommandExecutorService, _renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(changes: any): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * this method will be called after editor value is being written via 'ngModel'.
     */
    afterWriteNgxEditorValue(): void;
    /**
     * events
     */
    onTextAreaFocus(): void;
    /** focus the text area when the editor is focussed */
    onEditorFocus(): void;
    /**
     * Executed from the contenteditable section while the input property changes
     * @param html html string from contenteditable
     */
    onContentChange(html: string): void;
    onTextAreaBlur(event: any): void;
    onSelectionChange(): void;
    /**
     * resizing text area
     *
     * @param offsetY vertical height of the eidtable portion of the editor
     */
    resizeTextArea(offsetY: number): void;
    /**
     * editor actions, i.e., executes command from toolbar
     *
     * @param commandName name of the command to be executed
     */
    executeCommand(commandName: string, emit?: boolean): void;
    /**
     * Write a new value to the element.
     *
     * @param value value to be executed when there is a change in contenteditable
     */
    writeValue(value: any): void;
    /**
     * Set the function to be called
     * when the control receives a change event.
     *
     * @param fn a function
     */
    registerOnChange(fn: any): void;
    /**
     * Set the function to be called
     * when the control receives a touch event.
     *
     * @param fn a function
     */
    registerOnTouched(fn: any): void;
    /**
     * refresh view/HTML of the editor
     *
     * @param value html string from the editor
     */
    refreshView(value: string): void;
    /**
     * toggles placeholder based on input string
     *
     * @param value A HTML string from the editor
     */
    togglePlaceholder(value: any): void;
    /**
     * returns a json containing input params
     */
    getCollectiveParams(): any;
    /**
     * when user clicks on 'Custom Button'.
     *
     * @param event- text of clicked button.
     */
    onTriggerCustomClick(btnText: string): void;
    /**
     * focuses on editable area of editor.
     */
    focusTextArea(): void;
    /**
     * executed when user paste content inside editor.
     *
     * @param event- paste event object.
     */
    executePasteAsPlainText(event: any): void;
    /**
     * inserts image inside editor on last saved selection.
     *
     * @param imageURI - URL of image.
     */
    insertImage(imageURI: string): void;
    /**
     * when 'Popover' is being shown.
     */
    onShowPopOver(): void;
    /**
     * when 'Popover' is being hidden.
     */
    onHidePopOver(): void;
    /**
     * inserts html inside editor on last saved selection.
     *
     * @param html - html content to be inserted.
     */
    insertHtml(html: string): void;
    /**
     * inserts table inside editor.
     *
     * @param tableData - ex. {totalTableRows: 5, totalTableColumns: 5}
     */
    insertTable(tableData: any): void;
    /**
     * initialized editor tables such as context menu items, events etc.
     */
    initializeNgxEditorTable(): void;
    /**
     * binds table cell context menu event.
     *
     * @param tableContainerId- id of table container.
     */
    bindNgxEditorTableContextMenuEvent(tableContainerId?: string): void;
    /**
     * binds table row cells context menu event.
     *
     * @param tableContainerId- id of table container.
     * @param rowNumber- row number of table.
     */
    bindNgxEditorTableRowContextMenuEvent(tableContainerId: string, rowNumber: number): void;
    /**
     * binds table column cells context menu event.
     *
     * @param tableContainerId- id of table container.
     * @param columnNumber- column number of table.
     */
    bindNgxEditorTableColumnContextMenuEvent(tableContainerId: string, columnNumber: number): void;
    /**
     * when context menu event of table cell executes.
     *
     * @returns boolean- prevent default context menu event.
     */
    onContextMenuTableCell(event: any): boolean;
    /**
     * when table row inserted above selected row.
     *
     * @param event - event object
     */
    onInsertTableRowAbove(event: any): void;
    /**
     * when table row inserted below selected row.
     *
     * @param event - event object
     */
    onInsertTableRowBelow(event: any): void;
    /**
     * when table column inserted before selected column.
     *
     * @param event- event object
     */
    onInsertTableColumnBefore(event: any): void;
    /**
     * when table column inserted after selected column.
     *
     * @param event- event object
     */
    onInsertTableColumnAfter(event: any): void;
    /**
     * delete table row.
     *
     * @param event- event object
     */
    onDeleteTableRow(event: any): void;
    /**
     * delete table column.
     *
     * @param event- event object
     */
    onDeleteTableColumn(event: any): void;
    /**
     * delete table and related elements.
     *
     * @param event- event object
     */
    onDeleteTable(event: any): void;
    /**
     * save selection.
     */
    private saveSelection(savedSelection);
    /**
     * focus on element inside editor.
     *
     * @param elementCssSelector- css selector of element.
     * @returns boolean- whether element focused or not successfully.
     */
    private focusElementInsideEditor(elementCssSelector?);
    /**
     * get range object of element inside editor.
     *
     * @param elementCssSelector- css selector of element.
     * @returns Range- range object of element.
     */
    private getEditorElementRange(elementCssSelector?);
    /**
     * generate table html from total rows and columns.
     *
     * @param totalTableRows- total table rows.
     * @param totalTableColumns- total table columns.
     */
    private generateTableHtml(totalTableRows, totalTableColumns);
    /**
     * generates html of table row for given number of cells.
     *
     * @param totalCells - total cell in given row.
     * @returns- returns html string.
     */
    private generateTableRowHtml(totalCells);
    /**
     * inserts row at specified position inside table.
     *
     * @param tableContainerId - id of table container.
     * @param position - insert row position.
     */
    private insertTableRow(tableContainerId, position);
    /**
     * inserts column at specified position inside table.
     *
     * @param tableContainerId - id of table container.
     * @param position - insert column position.
     */
    private insertTableColumn(tableContainerId, position);
    /**
     * delete table row.
     *
     * @param tableContainerId- id of table container.
     * @param position- delete row position.
     */
    private deleteTableRow(tableContainerId, position);
    /**
     * delete table column.
     *
     * @param tableContainerId- id of table container.
     * @param position- delete column position.
     */
    private deleteTableColumn(tableContainerId, position);
    /**
     * get table selector.
     *
     * @param tableContainerId- id of table container.
     * @returns- CSS selector of table.
     */
    private _tblSelector(tableContainerId?);
}
