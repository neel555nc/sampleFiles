import { EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PopoverConfig } from 'ngx-bootstrap';
import { CommandExecutorService } from '../common/services/command-executor.service';
import { MessageService } from '../common/services/message.service';
export declare class NgxEditorToolbarComponent implements OnInit {
    private _popOverConfig;
    private _formBuilder;
    private _messageService;
    private _commandExecutorService;
    /** Editor configuration */
    config: any;
    languageCode: string;
    languageObj: any;
    /** List of custom buttons if any */
    customButtonsArray: any;
    execute: EventEmitter<string>;
    /** emits `triggerCustomClick` event when custombutton is clicked -> returns btntext to identify which button clicked */
    triggerCustomClick: EventEmitter<any>;
    focusTextArea: EventEmitter<any>;
    triggerInsertImage: EventEmitter<string>;
    triggerInsertHtml: EventEmitter<string>;
    /** when user inserts table. */
    triggerInsertTable: EventEmitter<any>;
    /** when popover is show/hide. */
    showPopOver: EventEmitter<any>;
    hidePopOver: EventEmitter<any>;
    urlPopover: any;
    imagePopover: any;
    videoPopover: any;
    fontSizePopover: any;
    colorPopover: any;
    tablePopover: any;
    /** holds values of the insert link form */
    urlForm: FormGroup;
    /** holds values of the insert image form */
    imageForm: FormGroup;
    /** holds values of the insert video form */
    videoForm: FormGroup;
    /** set to false when image is being uploaded */
    uploadComplete: boolean;
    /** upload percentage */
    updloadPercentage: number;
    /** set to true when the image is being uploaded */
    isUploading: boolean;
    /** which tab to active for color insetion */
    selectedColorTab: string;
    /** font family name */
    fontName: string;
    /** font size */
    fontSize: string;
    /** hex color code */
    hexColor: string;
    /** show/hide image uploader */
    isImageUploader: boolean;
    urlPattern: any;
    activeButtonArray: {
        bold: boolean;
        italic: boolean;
        underline: boolean;
        superscript: boolean;
        subscript: boolean;
        orderedlist: boolean;
        unorderedlist: boolean;
        blockquote: boolean;
        removeblockquote: boolean;
        strikethrough: boolean;
    };
    isMoreShow: boolean;
    moreButtonText: string;
    tablePopoverData: any;
    constructor(_popOverConfig: PopoverConfig, _formBuilder: FormBuilder, _messageService: MessageService, _commandExecutorService: CommandExecutorService);
    ngOnInit(): void;
    /**
     * enable or diable toolbar based on configuration
     *
     * @param value name of the toolbar buttons
     */
    canEnableToolbarOptions(value: any): boolean;
    /**
     * triggers command from the toolbar to be executed and emits an event
     *
     * @param command name of the command to be executed
     */
    triggerCommand(command: string): void;
    /**
     * clears active buttons while erase.
     */
    clearActiveButtonWhileErase(): void;
    /**
     * create URL insert form
     */
    buildUrlForm(setFocus?: boolean): void;
    /**
     * inserts link in the editor
     */
    insertLink(): void;
    /**
     * create insert image form
     */
    buildImageForm(): void;
    /**
     * create insert image form
     */
    buildVideoForm(): void;
    /**
     * Executed when file is selected
     *
     * @param e- onChange event.
     */
    onFileChange(e: any): void;
    /**
     * insert image in the editor
     */
    insertImage(): void;
    /**
     * insert image in the editor
     */
    insertVideo(): void;
    /**
     * inser text/background color
     */
    insertColor(color: string, where: string): void;
    /**
     * set font size
     */
    setFontSize(fontSize: string): void;
    /**
     * set font Name/family
     */
    setFontName(fontName: string): void;
    /**
     * allow only numbers
     *
     * @param event keypress event
     */
    onlyNumbers(event: KeyboardEvent): boolean;
    /**
     * when user clicks on 'Custom Button'.
     *
     * @param event- text of clicked button.
     */
    triggerCustomButtonClick(btnText: string): void;
    /**
     * when 'Image Popover' is being shown.
     */
    onShownImagePopOver(): void;
    /**
     * when 'Image Popover' is being hidden.
     */
    onHideImagePopOver(): void;
    /**
     * when 'Table Popover' is being shown.
     */
    onShownTablePopOver(): void;
    /**
     * when 'Table Popover' is being hidden.
     */
    onHideTablePopOver(): void;
    /**
     * toggles show less/more toolbar icons.
     */
    toggleShowLessOrMore(): void;
    /**
     * show less/more based on input.
     *
     * @param isMoreShow- if true, show more and false then show less.
     */
    showLessOrMore(isMoreShow: boolean): void;
    /**
     * initializes table popover.
     */
    initTablePopover(): void;
    /**
     * reset table popover data.
     */
    resetTablePopoverData(): void;
    /**
     * when user enters mouse on 'Row Column Box' area.
     *
     * @param selectedRowIndex- selected row index of row column box.
     * @param selectedColIndex- selected column index of row column box.
     */
    onMouseEnterRowColumnBox(selectedRowIndex: number, selectedColIndex: number): void;
    /**
     * when mouse leaves from 'Row Column Box' container.
     */
    onMouseLeaveRowColumnBoxContainer(): void;
    /**
     * when user clicks on row column box.
     *
     * @param selectedRowIndex- selected row index of row column box.
     * @param selectedColIndex- selected column index of row column box.
     */
    onClickRowColumnBox(selectedRowIndex: number, selectedColIndex: number): void;
}
