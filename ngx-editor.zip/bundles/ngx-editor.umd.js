(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('rxjs/Subject'), require('rxjs/add/operator/map'), require('@angular/forms'), require('ngx-bootstrap'), require('primeng/primeng'), require('@angular/common')) :
	typeof define === 'function' && define.amd ? define('ngx-editor', ['exports', '@angular/core', '@angular/common/http', 'rxjs/Subject', 'rxjs/add/operator/map', '@angular/forms', 'ngx-bootstrap', 'primeng/primeng', '@angular/common'], factory) :
	(factory((global['ngx-editor'] = {}),global.ng.core,global.ng.common.http,global.Rx,global.Rx.Observable.prototype,global.ng.forms,global['ngx-bootstrap'],global.primeng,global.ng.common));
}(this, (function (exports,core,http,Subject,map,forms,ngxBootstrap,primeng,common) { 'use strict';

function canEnableToolbarOptions(value, toolbar) {
    if (value) {
        if (toolbar['length'] === 0) {
            return true;
        }
        else {
            var found = toolbar.filter(function (array) {
                return array.indexOf(value) !== -1;
            });
            return found.length ? true : false;
        }
    }
    else {
        return false;
    }
}
function getEditorConfiguration(value, ngxEditorConfig, input) {
    for (var i in ngxEditorConfig) {
        if (i) {
            if (input[i] !== undefined) {
                value[i] = input[i];
            }
            if (!value.hasOwnProperty(i)) {
                value[i] = ngxEditorConfig[i];
            }
        }
    }
    return value;
}
function canResize(resizer) {
    if (resizer === 'basic') {
        return 'vertical';
    }
    return false;
}
function saveSelection() {
    if (window.getSelection) {
        var sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            return sel.getRangeAt(0);
        }
    }
    else if (document.getSelection && document.createRange) {
        return document.createRange();
    }
    return null;
}
function restoreSelection(range) {
    if (range) {
        if (window.getSelection) {
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            return true;
        }
        else if (document.getSelection && range.select) {
            range.select();
            return true;
        }
    }
    else {
        return false;
    }
}
function checkFormatting(selection) {
    var obj = {
        bold: false,
        italic: false,
        underline: false,
        superscript: false,
        subscript: false,
        orderedlist: false,
        unorderedlist: false,
        blockquote: false,
        removeblockquote: false,
        strikethrough: false
    };
    if (selection && selection.focusNode) {
        if (selection.focusNode.className == 'ngx-editor-textarea' || (selection.focusNode.parentNode && selection.focusNode.parentNode.className == 'ngx-editor-textarea')) {
            return obj;
        }
        else {
            var node = selection.focusNode.parentNode;
            if (node && node.tagName) {
                do {
                    switch (node.tagName.toLowerCase()) {
                        case 'b':
                            obj.bold = true;
                            break;
                        case 'i':
                            obj.italic = true;
                            break;
                        case 'u':
                            obj.underline = true;
                            break;
                        case 'strike':
                            obj.strikethrough = true;
                            break;
                        case 'sup':
                            obj.superscript = true;
                            break;
                        case 'sub':
                            obj.subscript = true;
                            break;
                        case 'ol':
                            obj.orderedlist = true;
                            break;
                        case 'ul':
                            obj.underline = true;
                            break;
                        case 'blockquote':
                            obj.blockquote = true;
                            break;
                    }
                    if (node && node.parentNode) {
                        node = node.parentNode;
                    }
                } while (node.className != 'ngx-editor-textarea');
            }
            return obj;
        }
    }
}
function getIndex(element) {
    return Array.from(element.parentElement.children).indexOf(element);
}
function getClosest(element, selector) {
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype['matchesSelector'] ||
                Element.prototype['mozMatchesSelector'] ||
                Element.prototype['msMatchesSelector'] ||
                Element.prototype['oMatchesSelector'] ||
                Element.prototype.webkitMatchesSelector ||
                function (s) {
                    var matches = (this.document || this.ownerDocument).querySelectorAll(s);
                    var index = matches.length;
                    while (--index >= 0 && matches.item(index) !== this) { }
                    return index > -1;
                };
    }
    for (; element && element !== document; element = element.parentNode) {
        if (element.matches(selector)) {
            return element;
        }
    }
    return null;
}
function getImmediateChildrenUsingTagName(element, tagName) {
    var childList = [];
    childList = Array.from(element.children).filter(function (childElementItem) {
        return childElementItem.tagName.toLowerCase() === tagName.toLowerCase();
    });
    return childList;
}
function triggerContentEditableInputEvent(element) {
    element.dispatchEvent(new Event('input'));
}
var Utils = Object.freeze({
    canEnableToolbarOptions: canEnableToolbarOptions,
    getEditorConfiguration: getEditorConfiguration,
    canResize: canResize,
    saveSelection: saveSelection,
    restoreSelection: restoreSelection,
    checkFormatting: checkFormatting,
    getIndex: getIndex,
    getClosest: getClosest,
    getImmediateChildrenUsingTagName: getImmediateChildrenUsingTagName,
    triggerContentEditableInputEvent: triggerContentEditableInputEvent
});
var CommandExecutorService =               (function () {
    function CommandExecutorService(_http) {
        this._http = _http;
        this.savedSelection = undefined;
    }
    CommandExecutorService.prototype.execute = function (command) {
        if (!this.savedSelection && command !== 'enableObjectResizing') {
            throw new Error('Range out of Editor');
        }
        if (command === 'enableObjectResizing') {
            document.execCommand('enableObjectResizing', true, 'true');
            return;
        }
        if (command === 'blockquote') {
            document.execCommand('formatBlock', false, 'blockquote');
            return;
        }
        if (command === 'removeBlockquote') {
            document.execCommand('outdent', false, undefined);
            return;
        }
        document.execCommand(command, false, null);
        return;
    };
    CommandExecutorService.prototype.insertImage = function (imageURI) {
        if (imageURI) {
            var restored = restoreSelection(this.savedSelection);
            if (restored) {
                var inserted = document.execCommand('insertImage', false, imageURI);
                if (!inserted) {
                    throw new Error('Invalid URL');
                }
            }
        }
    };
    CommandExecutorService.prototype.insertVideo = function (videParams) {
        if (this.savedSelection) {
            if (videParams) {
                var restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isYoutubeLink(videParams.videoUrl)) {
                        var youtubeURL = '<iframe width="' + videParams.width + '" height="' + videParams.height + '"'
                            + 'src="' + videParams.videoUrl + '"></iframe>';
                        this.insertHtml(youtubeURL);
                    }
                    else if (this.checkTagSupportInBrowser('video')) {
                        if (this.isValidURL(videParams.videoUrl)) {
                            var videoSrc = '<video width="' + videParams.width + '" height="' + videParams.height + '"'
                                + ' controls="true"><source src="' + videParams.videoUrl + '"></video>';
                            this.insertHtml(videoSrc);
                        }
                        else {
                            throw new Error('Invalid video URL');
                        }
                    }
                    else {
                        throw new Error('Unable to insert video');
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    };
    CommandExecutorService.prototype.isYoutubeLink = function (url) {
        var ytRegExp = /^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+/;
        return ytRegExp.test(url);
    };
    CommandExecutorService.prototype.isValidURL = function (url) {
        var urlRegExp = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
        return urlRegExp.test(url);
    };
    CommandExecutorService.prototype.uploadImage = function (file, imageApiDetail) {
        var endPoint = imageApiDetail.endPoint;
        if (!endPoint) {
            throw new Error('Image Api Endpoint isn`t provided or invalid');
        }
        var formData = new FormData();
        if (file) {
            var method = imageApiDetail.method || 'POST';
            var headers = imageApiDetail.headers;
            if (!headers || Object.keys(headers).length === 0) {
                throw new Error('Image Api Headers aren`t provided');
            }
            formData.append('file', file);
            var req = new http.HttpRequest(method, endPoint, formData, {
                reportProgress: true,
                headers: new http.HttpHeaders(headers)
            });
            return this._http.request(req);
        }
        else {
            throw new Error('Invalid Image');
        }
    };
    CommandExecutorService.prototype.createLink = function (params) {
        if (this.savedSelection) {
            if (params.urlNewTab) {
                var newUrl = '<a href="' + params.urlLink + '" target="_blank">' + params.urlText + '</a>';
                if (document.getSelection().type !== 'Range') {
                    var restored = restoreSelection(this.savedSelection);
                    if (restored) {
                        this.insertHtml(newUrl);
                    }
                }
                else {
                    throw new Error('Only new links can be inserted. You cannot edit URL`s');
                }
            }
            else {
                var newUrl = '<a href="' + params.urlLink + '">' + params.urlText + '</a>';
                var restored = restoreSelection(this.savedSelection);
                if (restored) {
                    this.insertHtml(newUrl);
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    };
    CommandExecutorService.prototype.insertColor = function (color, where) {
        if (this.savedSelection) {
            var restored = restoreSelection(this.savedSelection);
            if (restored && this.checkSelection()) {
                if (where === 'textColor') {
                    document.execCommand('foreColor', false, color);
                }
                else {
                    document.execCommand('hiliteColor', false, color);
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    };
    CommandExecutorService.prototype.setFontSize = function (fontSize) {
        if (this.savedSelection && this.checkSelection()) {
            var deletedValue = this.deleteAndGetElement();
            if (deletedValue) {
                var restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isNumeric(fontSize)) {
                        var fontPx = '<span style="font-size: ' + fontSize + 'px;">' + deletedValue + '</span>';
                        this.insertHtml(fontPx);
                    }
                    else {
                        var fontPx = '<span style="font-size: ' + fontSize + ';">' + deletedValue + '</span>';
                        this.insertHtml(fontPx);
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    };
    CommandExecutorService.prototype.setFontName = function (fontName) {
        if (this.savedSelection && this.checkSelection()) {
            var deletedValue = this.deleteAndGetElement();
            if (deletedValue) {
                var restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isNumeric(fontName)) {
                        var fontFamily = '<span style="font-family: ' + fontName + 'px;">' + deletedValue + '</span>';
                        this.insertHtml(fontFamily);
                    }
                    else {
                        var fontFamily = '<span style="font-family: ' + fontName + ';">' + deletedValue + '</span>';
                        this.insertHtml(fontFamily);
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    };
    CommandExecutorService.prototype.insertHtml = function (html, rootElement) {
        var isHTMLInserted = document.execCommand('insertHTML', false, html);
        if (!isHTMLInserted) {
            throw new Error('Unable to perform the operation');
        }
        var styles = html.match(/<style(.*)>(.|\n)+<\/style>/ig);
        if (styles && styles.length) {
            styles.forEach(function (style) {
                rootElement.insertAdjacentHTML('beforeend', style);
            });
        }
    };
    CommandExecutorService.prototype.restoreSelectionAndInsertHtml = function (html, rootElement) {
        var restored = restoreSelection(this.savedSelection);
        if (restored) {
            this.insertHtml(html, rootElement);
        }
    };
    CommandExecutorService.prototype.isNumeric = function (value) {
        return /^-{0,1}\d+$/.test(value);
    };
    CommandExecutorService.prototype.deleteAndGetElement = function () {
        var selectedText;
        if (this.savedSelection) {
            selectedText = this.savedSelection.toString();
            this.savedSelection.deleteContents();
            return selectedText;
        }
        return false;
    };
    CommandExecutorService.prototype.checkSelection = function () {
        var slectedText = this.savedSelection.toString();
        if (slectedText.length === 0) {
            throw new Error('No Selection Made');
        }
        return true;
    };
    CommandExecutorService.prototype.checkTagSupportInBrowser = function (tag) {
        return !(document.createElement(tag) instanceof HTMLUnknownElement);
    };
    return CommandExecutorService;
}());
CommandExecutorService.decorators = [
    { type: core.Injectable },
];
CommandExecutorService.ctorParameters = function () { return [
    { type: http.HttpClient, },
]; };
var DURATION = 7000;
var MessageService =               (function () {
    function MessageService() {
        this.message = new Subject.Subject();
    }
    MessageService.prototype.getMessage = function () {
        return this.message.asObservable();
    };
    MessageService.prototype.sendMessage = function (message) {
        this.message.next(message);
        this.clearMessageIn(DURATION);
        return;
    };
    MessageService.prototype.clearMessageIn = function (milliseconds) {
        var _this = this;
        setTimeout(function () {
            _this.message.next(undefined);
        }, milliseconds);
        return;
    };
    return MessageService;
}());
MessageService.decorators = [
    { type: core.Injectable },
];
MessageService.ctorParameters = function () { return []; };
var ngxEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    isMoreShow: true,
    placeholder: 'Enter text here...',
    image: {
        apiDetail: {
            endPoint: 'http://localhost:8080/rest/attachments/uploadImage',
            method: 'POST',
            headers: {
                scope: '1',
                get orgCode() {
                    return 'QMETRY';
                },
                get usertoken() {
                    return 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGZheixMbVhOa256ZGprIiwiYXVkIjoiaHR0cDovL3FtZXRyeXNhYXMucW1ldHJ5LmNvbSIsImNsaWVudElkIjoxLCJpc3MiOiJRTWV0cnkiLCJleHAiOjE2MTk1Mjg4NTcsInVzZXJJZCI6MywiaWF0IjoxNjE5NTI3OTU3LCJqdGkiOiItMTk3NDg5OTcyMyJ9.uKrH5gDFpYLRAtvxeTuGsu9P3JjXDfqBdU7betMW6ac';
                }
            }
        }
    },
    table: {
        popoverRowsLength: 10,
        popoverColumnsLength: 10
    },
    toolbar: [
        ['bold', 'italic', 'underline', 'strikeThrough', 'superscript', 'subscript'],
        ['fontName', 'fontSize', 'color'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
        ['cut', 'copy', 'delete', 'removeFormat', 'undo', 'redo'],
        ['paragraph', 'blockquote', 'removeBlockquote', 'horizontalLine', 'orderedList', 'unorderedList'],
        ['link', 'unlink', 'image', 'video', 'table']
    ]
};
var FileUtils =               (function () {
    function FileUtils(_fileName, _fileType, _fileSize) {
        this._fileName = _fileName;
        this._fileType = _fileType;
        this._fileSize = _fileSize;
    }
    Object.defineProperty(FileUtils.prototype, "fileName", {
        get: function () {
            return this._fileName;
        },
        set: function (_fileName) {
            this._fileName = _fileName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FileUtils.prototype, "fileType", {
        get: function () {
            return this._fileType;
        },
        set: function (_fileType) {
            this._fileType = _fileType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FileUtils.prototype, "supportedFileTypes", {
        get: function () {
            return this._supportedFileTypes;
        },
        set: function (_supportedFileTypes) {
            this._supportedFileTypes = _supportedFileTypes;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FileUtils.prototype, "maximumFileSize", {
        get: function () {
            return this._maximumFileSize;
        },
        set: function (_maximumFileSize) {
            this._maximumFileSize = _maximumFileSize;
        },
        enumerable: true,
        configurable: true
    });
    FileUtils.prototype.isValidFileType = function () {
        return this._supportedFileTypes.indexOf(this._fileType) !== -1;
    };
    FileUtils.prototype.isValidFileSize = function () {
        return this._fileSize <= this._maximumFileSize;
    };
    return FileUtils;
}());
var Constants =               (function () {
    function Constants() {
    }
    return Constants;
}());
Constants.SUPPORTED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/gif'];
Constants.MAXIMUM_IMAGE_SIZE = 1024 * 1024;
var NgxEditorToolbarComponent =               (function () {
    function NgxEditorToolbarComponent(_popOverConfig, _formBuilder, _messageService, _commandExecutorService) {
        this._popOverConfig = _popOverConfig;
        this._formBuilder = _formBuilder;
        this._messageService = _messageService;
        this._commandExecutorService = _commandExecutorService;
        this.customButtonsArray = [];
        this.execute = new core.EventEmitter();
        this.triggerCustomClick = new core.EventEmitter();
        this.focusTextArea = new core.EventEmitter();
        this.triggerInsertImage = new core.EventEmitter();
        this.triggerInsertHtml = new core.EventEmitter();
        this.triggerInsertTable = new core.EventEmitter();
        this.showPopOver = new core.EventEmitter();
        this.hidePopOver = new core.EventEmitter();
        this.uploadComplete = true;
        this.updloadPercentage = 0;
        this.isUploading = false;
        this.selectedColorTab = 'textColor';
        this.fontName = '';
        this.fontSize = '';
        this.hexColor = '';
        this.isImageUploader = true;
        this.urlPattern = /https?:\/\/.+/;
        this.activeButtonArray = {
            bold: false,
            italic: false,
            underline: false,
            superscript: false,
            subscript: false,
            orderedlist: false,
            unorderedlist: false,
            blockquote: false,
            removeblockquote: false,
            strikethrough: false
        };
        this.isMoreShow = false;
        this.moreButtonText = '';
        this.tablePopoverData = {
            tablePopoverRowColumnBoxArray: [],
            popoverRowsLength: 0,
            popoverColumnsLength: 0,
            selectedTablePopoverRowIndex: -1,
            selectedTablePopoverColumnIndex: -1
        };
        this._popOverConfig.outsideClick = true;
        this._popOverConfig.placement = 'bottom';
        this._popOverConfig.container = 'body';
    }
    NgxEditorToolbarComponent.prototype.ngOnInit = function () {
        this.isMoreShow = this.config['isMoreShow'] || false;
        this.showLessOrMore(this.isMoreShow);
        this.buildUrlForm();
        this.buildImageForm();
        this.buildVideoForm();
        this.initTablePopover();
    };
    NgxEditorToolbarComponent.prototype.canEnableToolbarOptions = function (value) {
        return canEnableToolbarOptions(value, this.config['toolbar']);
    };
    NgxEditorToolbarComponent.prototype.triggerCommand = function (command) {
        if (!this._commandExecutorService.savedSelection) {
            this.focusTextArea.emit();
        }
        if (command === 'removeFormat') {
            this.clearActiveButtonWhileErase();
        }
        else {
            this.activeButtonArray[command.toLowerCase()] = !this.activeButtonArray[command.toLowerCase()];
        }
        this.execute.emit(command);
    };
    NgxEditorToolbarComponent.prototype.clearActiveButtonWhileErase = function () {
        var _this = this;
        var formattedButton = ['bold', 'italic', 'underline', 'superscript', 'subscript', 'strikethrough'];
        formattedButton.forEach(function (btn) {
            _this.activeButtonArray[btn] = false;
        });
    };
    NgxEditorToolbarComponent.prototype.buildUrlForm = function (setFocus) {
        if (setFocus === void 0) { setFocus = false; }
        if (setFocus) {
            this.focusTextArea.emit();
        }
        this.urlForm = this._formBuilder.group({
            urlLink: ['', [forms.Validators.required]],
            urlText: ['', [forms.Validators.required]],
            urlNewTab: [true]
        });
    };
    NgxEditorToolbarComponent.prototype.insertLink = function () {
        try {
            this._commandExecutorService.createLink(this.urlForm.value);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildUrlForm();
        this.urlPopover.hide();
    };
    NgxEditorToolbarComponent.prototype.buildImageForm = function () {
        this.imageForm = this._formBuilder.group({
            imageUrl: ['', [forms.Validators.required]]
        });
    };
    NgxEditorToolbarComponent.prototype.buildVideoForm = function () {
        this.videoForm = this._formBuilder.group({
            videoUrl: ['', [forms.Validators.required]],
            height: [''],
            width: ['']
        });
    };
    NgxEditorToolbarComponent.prototype.onFileChange = function (e) {
        var _this = this;
        if (e.target.files.length > 0) {
            var file = e.target.files[0];
            var imageConfig = this.config.image;
            var fileUtilsObj = new FileUtils(file.name, file.type, file.size);
            fileUtilsObj.supportedFileTypes = imageConfig.supportedFileTypes || Constants.SUPPORTED_IMAGE_TYPES;
            fileUtilsObj.maximumFileSize = imageConfig.maximumFileSize || Constants.MAXIMUM_IMAGE_SIZE;
            if (!fileUtilsObj.isValidFileType()) {
                this._messageService.sendMessage('FILE_TYPE_INVALID');
                this.buildImageForm();
                this.imagePopover.hide();
                return;
            }
            if (!fileUtilsObj.isValidFileSize()) {
                this._messageService.sendMessage('FILE_SIZE_INVALID');
                this.buildImageForm();
                this.imagePopover.hide();
                return;
            }
            this.uploadComplete = false;
            this.isUploading = true;
            try {
                this._commandExecutorService.uploadImage(file, imageConfig.apiDetail).subscribe(function (event) {
                    if (event instanceof http.HttpResponse) {
                        try {
                            _this.triggerInsertImage.emit(event.body.url);
                        }
                        catch (error) {
                            _this._messageService.sendMessage(error.message);
                        }
                        _this.buildImageForm();
                        _this.imagePopover.hide();
                        _this.updloadPercentage = 100;
                        _this.uploadComplete = true;
                        _this.isUploading = false;
                    }
                }, function (error) {
                    if (error instanceof http.HttpErrorResponse) {
                        _this.buildImageForm();
                        _this.imagePopover.hide();
                        _this._messageService.sendMessage('SERVICE_FAILED');
                        _this.uploadComplete = true;
                        _this.isUploading = false;
                    }
                });
            }
            catch (error) {
                this._messageService.sendMessage(error.message);
                this.uploadComplete = true;
                this.isUploading = false;
            }
        }
    };
    NgxEditorToolbarComponent.prototype.insertImage = function () {
        try {
            this.triggerInsertImage.emit(this.imageForm.value.imageUrl);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildImageForm();
        this.imagePopover.hide();
    };
    NgxEditorToolbarComponent.prototype.insertVideo = function () {
        try {
            this._commandExecutorService.insertVideo(this.videoForm.value);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildVideoForm();
        this.videoPopover.hide();
    };
    NgxEditorToolbarComponent.prototype.insertColor = function (color, where) {
        try {
            this._commandExecutorService.insertColor(color, where);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.colorPopover.hide();
    };
    NgxEditorToolbarComponent.prototype.setFontSize = function (fontSize) {
        try {
            this._commandExecutorService.setFontSize(fontSize);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.fontSizePopover.hide();
    };
    NgxEditorToolbarComponent.prototype.setFontName = function (fontName) {
        try {
            this._commandExecutorService.setFontName(fontName);
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
        this.fontSizePopover.hide();
    };
    NgxEditorToolbarComponent.prototype.onlyNumbers = function (event) {
        return !isNaN((event.key));
    };
    NgxEditorToolbarComponent.prototype.triggerCustomButtonClick = function (btnText) {
        this.triggerCustomClick.emit(btnText);
    };
    NgxEditorToolbarComponent.prototype.onShownImagePopOver = function () {
        this.showPopOver.emit();
    };
    NgxEditorToolbarComponent.prototype.onHideImagePopOver = function () {
        this.hidePopOver.emit();
    };
    NgxEditorToolbarComponent.prototype.onShownTablePopOver = function () {
        this.showPopOver.emit();
    };
    NgxEditorToolbarComponent.prototype.onHideTablePopOver = function () {
        this.hidePopOver.emit();
    };
    NgxEditorToolbarComponent.prototype.toggleShowLessOrMore = function () {
        this.showLessOrMore(!this.isMoreShow);
    };
    NgxEditorToolbarComponent.prototype.showLessOrMore = function (isMoreShow) {
        this.isMoreShow = isMoreShow;
        if (isMoreShow) {
            this.moreButtonText = this.languageObj.SHOW_LESS;
        }
        else {
            this.moreButtonText = this.languageObj.SHOW_MORE;
        }
    };
    NgxEditorToolbarComponent.prototype.initTablePopover = function () {
        this.tablePopoverData.tablePopoverRowsLength = this.config['table']['popoverRowsLength'];
        this.tablePopoverData.tablePopoverColumnsLength = this.config['table']['popoverColumnsLength'];
        for (var rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex] = [];
            for (var colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex] = {
                    isHighlight: false
                };
            }
        }
    };
    NgxEditorToolbarComponent.prototype.resetTablePopoverData = function () {
        this.tablePopoverData.selectedTablePopoverRowIndex = -1;
        this.tablePopoverData.selectedTablePopoverColumnIndex = -1;
        for (var rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            for (var colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = false;
            }
        }
    };
    NgxEditorToolbarComponent.prototype.onMouseEnterRowColumnBox = function (selectedRowIndex, selectedColIndex) {
        this.tablePopoverData.selectedTablePopoverRowIndex = selectedRowIndex;
        this.tablePopoverData.selectedTablePopoverColumnIndex = selectedColIndex;
        for (var rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            for (var colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                var isHighlight = false;
                if (rowIndex <= selectedRowIndex && colIndex <= selectedColIndex) {
                    isHighlight = true;
                }
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = isHighlight;
            }
        }
    };
    NgxEditorToolbarComponent.prototype.onMouseLeaveRowColumnBoxContainer = function () {
        this.resetTablePopoverData();
    };
    NgxEditorToolbarComponent.prototype.onClickRowColumnBox = function (selectedRowIndex, selectedColIndex) {
        this.tablePopover.hide();
        this.resetTablePopoverData();
        this.triggerInsertTable.emit({
            totalTableRows: selectedRowIndex + 1,
            totalTableColumns: selectedColIndex + 1
        });
    };
    return NgxEditorToolbarComponent;
}());
NgxEditorToolbarComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'app-ngx-editor-toolbar',
                template: "<div class=\"ngx-toolbar\" *ngIf=\"config['showToolbar']\">\n  <div class=\"ngx-toolbar-set\" [ngClass]=\"{'width-70': customButtonsArray && customButtonsArray.length}\">\n    <button [ngClass]=\"activeButtonArray['bold']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('bold')\" (click)=\"triggerCommand('bold')\"\n      title=\"{{languageObj.BOLD}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-bold\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['italic']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('italic')\" (click)=\"triggerCommand('italic')\"\n      title=\"{{languageObj.ITALIC}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-italic\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['underline']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('underline')\" (click)=\"triggerCommand('underline')\"\n      title=\"{{languageObj.UNDERLINE}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-underline\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['strikethrough']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('strikeThrough')\" (click)=\"triggerCommand('strikeThrough')\"\n      title=\"{{languageObj.STRIKETHROUGH}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-strikethrough\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['superscript']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('superscript')\" (click)=\"triggerCommand('superscript')\"\n      title=\"{{languageObj.SUPERSCRIPT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-superscript\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['subscript']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('subscript') && isMoreShow\" (click)=\"triggerCommand('subscript')\"\n      title=\"{{languageObj.SUBSCRIPT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-subscript\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('fontName') && isMoreShow\" (click)=\"fontName = ''\" title=\"{{languageObj.FONT_FAMILY}}\"\n      [popover]=\"fontNameTemplate\" #fontNamePopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-font\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('fontSize') && isMoreShow\" (click)=\"fontSize = ''\" title=\"{{languageObj.FONT_SIZE}}\"\n      [popover]=\"fontSizeTemplate\" #fontSizePopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-text-height\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('color') && isMoreShow\" (click)=\"hexColor = ''\" title=\"{{languageObj.COLOR_PICKER}}\"\n      [popover]=\"insertColorTemplate\" #colorPopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-tint\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('justifyLeft') && isMoreShow\" (click)=\"triggerCommand('justifyLeft')\"\n      title=\"{{languageObj.JUSTIFY_LEFT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-align-left\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('justifyCenter') && isMoreShow\" (click)=\"triggerCommand('justifyCenter')\"\n      title=\"{{languageObj.JUSTIFY_CENTER}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-align-center\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('justifyRight') && isMoreShow\" (click)=\"triggerCommand('justifyRight')\"\n      title=\"{{languageObj.JUSTIFY_RIGHT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-align-right\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('justifyFull') && isMoreShow\" (click)=\"triggerCommand('justifyFull')\"\n      title=\"{{languageObj.JUSTIFY}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-align-justify\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('indent') && isMoreShow\" (click)=\"triggerCommand('indent')\"\n      title=\"{{languageObj.INDENT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-indent\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('outdent') && isMoreShow\" (click)=\"triggerCommand('outdent')\"\n      title=\"{{languageObj.OUTDENT}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-outdent\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('cut') && isMoreShow\" (click)=\"triggerCommand('cut')\" title=\"{{languageObj.CUT}}\"\n      [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-scissors\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('copy') && isMoreShow\" (click)=\"triggerCommand('copy')\"\n      title=\"{{languageObj.COPY}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-files-o\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('delete')\" (click)=\"triggerCommand('delete')\"\n      title=\"{{languageObj.DELETE}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-trash\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('removeFormat') && isMoreShow\" (click)=\"triggerCommand('removeFormat')\"\n      title=\"{{languageObj.CLEAR_FORMATTING}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-eraser\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('undo') && isMoreShow\" (click)=\"triggerCommand('undo')\"\n      title=\"{{languageObj.UNDO}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-undo\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('redo') && isMoreShow\" (click)=\"triggerCommand('redo')\"\n      title=\"{{languageObj.REDO}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-repeat\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('paragraph') && isMoreShow\" (click)=\"triggerCommand('insertParagraph')\"\n      title=\"{{languageObj.PARAGRAPH}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-paragraph\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['blockquote']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('blockquote') && isMoreShow\" (click)=\"triggerCommand('blockquote')\"\n      title=\"{{languageObj.BLOCKQUOTE}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-quote-left\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['removeblockquote']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('removeBlockquote') && isMoreShow\" (click)=\"triggerCommand('removeBlockquote')\"\n      title=\"{{languageObj.REMOVE_BLOCKQUOTE}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-quote-right\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('horizontalLine') && isMoreShow\" (click)=\"triggerCommand('insertHorizontalRule')\"\n      title=\"{{languageObj.HORIZONTAL_LINE}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-minus\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['insertunorderedlist']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('unorderedList') && isMoreShow\" (click)=\"triggerCommand('insertUnorderedList')\"\n      title=\"{{languageObj.UNORDERED_LIST}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-list-ul\" aria-hidden=\"true\"></i>\n    </button>\n    <button [ngClass]=\"activeButtonArray['insertorderedlist']==true?'active':''\" type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('orderedList') && isMoreShow\" (click)=\"triggerCommand('insertOrderedList')\"\n      title=\"{{languageObj.ORDERED_LIST}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-list-ol\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('link') && isMoreShow\" (click)=\"buildUrlForm(true)\" [popover]=\"insertLinkTemplate\"\n      title=\"{{languageObj.INSERT_LINK}}\" #urlPopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-link\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('unlink') && isMoreShow\" (click)=\"triggerCommand('unlink')\"\n      title=\"{{languageObj.UNLINK}}\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-chain-broken\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('image') && isMoreShow\" (click)=\"buildImageForm()\" title=\"{{languageObj.INSERT_IMAGE}}\"\n      [popover]=\"insertImageTemplate\" #imagePopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\"\n      (onShown)=\"onShownImagePopOver()\" (onHidden)=\"onHideImagePopOver()\">\n      <i class=\"fa fa-picture-o\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('video') && isMoreShow\" (click)=\"buildVideoForm()\" title=\"{{languageObj.INSERT_VIDEO}}\"\n      [popover]=\"insertVideoTemplate\" #videoPopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\">\n      <i class=\"fa fa-youtube-play\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" *ngIf=\"canEnableToolbarOptions('table') && isMoreShow\" title=\"{{languageObj.INSERT_TABLE}}\"\n      [popover]=\"insertTableTemplate\" #tablePopover=\"bs-popover\" containerClass=\"ngxePopover\" [disabled]=\"!config['enableToolbar']\"\n      (onShown)=\"onShownTablePopOver()\" (onHidden)=\"onHideTablePopOver()\">\n      <i class=\"fa fa-table\" aria-hidden=\"true\"></i>\n    </button>\n    <button type=\"button\" class=\"ngx-editor-button\" [title]=\"moreButtonText\" (click)=\"toggleShowLessOrMore()\">\n      <i [ngClass]=\"isMoreShow ? 'fa fa-caret-up' : 'fa fa-caret-down'\" aria-hidden=\"true\"></i>\n    </button>\n  </div>\n  <!-- Custom buttons -->\n  <div class=\"custom-button-container\" *ngIf=\"customButtonsArray && customButtonsArray.length\">\n    <ng-container *ngFor=\"let customButton of customButtonsArray\">\n        <button *ngIf=\"customButton.icon\" type=\"button\" class=\"ngx-editor-button\" title=\"{{customButton.title || customButton.value}}\" (click)=\"!customButton.disabled && triggerCustomButtonClick(customButton.btnText)\" [disabled]=\"customButton.disabled\"><i class=\"{{customButton.icon}}\" aria-hidden=\"true\"></i>\n        </button>\n        <button *ngIf=\"!customButton.icon\" type=\"button\" class=\"ngx-editor-button\" title=\"{{customButton.title || customButton.value}}\" (click)=\"!customButton.disabled && triggerCustomButtonClick(customButton.btnText)\" [disabled]=\"customButton.disabled\">{{customButton.value}}\n        </button>\n    </ng-container>\n  </div>\n</div>\n\n<!-- URL Popover template -->\n<ng-template #insertLinkTemplate>\n  <div class=\"ngxe-popover extra-gt\">\n    <form [formGroup]=\"urlForm\" (ngSubmit)=\"urlForm.valid && insertLink()\" autocomplete=\"off\">\n      <div class=\"form-group\">\n        <label for=\"urlInput\" class=\"small\">URL</label>\n        <input type=\"text\" class=\"form-control-sm\" id=\"URLInput\" placeholder=\"URL\" formControlName=\"urlLink\" required [pattern]=\"urlPattern\">\n      </div>\n      <div class=\"form-group\">\n        <label for=\"urlTextInput\" class=\"small\">Text</label>\n        <input type=\"text\" class=\"form-control-sm\" id=\"urlTextInput\" placeholder=\"Text\" formControlName=\"urlText\" required>\n      </div>\n      <div class=\"form-check\">\n        <input type=\"checkbox\" class=\"form-check-input\" id=\"urlNewTab\" formControlName=\"urlNewTab\">\n        <label class=\"form-check-label\" for=\"urlNewTab\">Open in new tab</label>\n      </div>\n      <button type=\"submit\" class=\"btn-primary btn-sm btn\" [disabled]=\"!urlForm.valid\">{{languageObj.SUBMIT}}</button>\n    </form>\n  </div>\n</ng-template>\n\n<!-- Image Uploader Popover template -->\n<ng-template #insertImageTemplate>\n  <div class=\"ngxe-popover imgc-ctnr\">\n    <div class=\"imgc-topbar btn-ctnr\">\n      <button type=\"button\" class=\"btn\" [ngClass]=\"{active: isImageUploader}\" (click)=\"isImageUploader = true\">\n        <i class=\"fa fa-upload\"></i>\n      </button>\n      <button type=\"button\" class=\"btn\" [ngClass]=\"{active: !isImageUploader}\" (click)=\"isImageUploader = false\">\n        <i class=\"fa fa-link\"></i>\n      </button>\n    </div>\n    <div class=\"imgc-ctnt is-image\">\n      <div *ngIf=\"isImageUploader; else insertImageLink\"> </div>\n      <div *ngIf=\"!isImageUploader; else imageUploder\"> </div>\n      <ng-template #imageUploder>\n        <div class=\"ngx-insert-img-ph\">\n          <p *ngIf=\"uploadComplete\">{{languageObj.CHOOSE_IMAGE}}</p>\n          <p *ngIf=\"!uploadComplete\">\n            <span>{{languageObj.UPLOADING_IMAGE}}</span>\n            <br>\n            <span>{{ updloadPercentage }} %</span>\n          </p>\n          <div class=\"ngxe-img-upl-frm\">\n            <input type=\"file\" (change)=\"onFileChange($event)\" accept=\"image/*\" [disabled]=\"isUploading\" />\n          </div>\n        </div>\n      </ng-template>\n      <ng-template #insertImageLink>\n        <form class=\"extra-gt\" [formGroup]=\"imageForm\" (ngSubmit)=\"imageForm.valid && insertImage()\" autocomplete=\"off\">\n          <div class=\"form-group\">\n            <label for=\"imageURLInput\" class=\"small\">{{languageObj.URL}}</label>\n            <input type=\"text\" class=\"form-control-sm\" id=\"imageURLInput\" placeholder=\"{{languageObj.URL}}\" formControlName=\"imageUrl\" required>\n          </div>\n          <button type=\"submit\" class=\"btn-primary btn-sm btn\">{{languageObj.SUBMIT}}</button>\n        </form>\n      </ng-template>\n      <div class=\"progress\" *ngIf=\"!uploadComplete\">\n        <div class=\"progress-bar progress-bar-striped progress-bar-animated bg-success\" [ngClass]=\"{'bg-danger': updloadPercentage<20, 'bg-warning': updloadPercentage<50, 'bg-success': updloadPercentage>=100}\"\n          [style.width.%]=\"updloadPercentage\"></div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n\n<!-- Insert Video Popover template -->\n<ng-template #insertVideoTemplate>\n  <div class=\"ngxe-popover imgc-ctnr\">\n    <div class=\"imgc-topbar btn-ctnr\">\n      <button type=\"button\" class=\"btn active\">\n        <i class=\"fa fa-link\"></i>\n      </button>\n    </div>\n    <div class=\"imgc-ctnt is-image\">\n      <form class=\"extra-gt\" [formGroup]=\"videoForm\" (ngSubmit)=\"videoForm.valid && insertVideo()\" autocomplete=\"off\">\n        <div class=\"form-group\">\n          <label for=\"videoURLInput\" class=\"small\">{{languageObj.URL}}</label>\n          <input type=\"text\" class=\"form-control-sm\" id=\"videoURLInput\" placeholder=\"{{languageObj.URL}}\" formControlName=\"videoUrl\" required>\n        </div>\n        <div class=\"row form-group\">\n          <div class=\"col\">\n            <input type=\"text\" class=\"form-control-sm\" formControlName=\"height\" placeholder=\"{{languageObj.HEIGHT_PX}}\" (keypress)=\"onlyNumbers($event)\">\n          </div>\n          <div class=\"col\">\n            <input type=\"text\" class=\"form-control-sm\" formControlName=\"width\" placeholder=\"{{languageObj.WIDTH_PX}}\" (keypress)=\"onlyNumbers($event)\">\n          </div>\n          <label class=\"small\">{{languageObj.HEIGHT_WIDTH}}</label>\n        </div>\n        <button type=\"submit\" class=\"btn-primary btn-sm btn\">{{languageObj.SUBMIT}}</button>\n      </form>\n    </div>\n  </div>\n</ng-template>\n\n<!-- Insert color template -->\n<ng-template #insertColorTemplate>\n  <div class=\"ngxe-popover imgc-ctnr\">\n    <div class=\"imgc-topbar two-tabs\">\n      <span (click)=\"selectedColorTab ='textColor'\" [ngClass]=\"{active: selectedColorTab ==='textColor'}\">{{languageObj.TEXT}}</span>\n      <span (click)=\"selectedColorTab ='backgroundColor'\" [ngClass]=\"{active: selectedColorTab ==='backgroundColor'}\">{{languageObj.BACKGROUND}}</span>\n    </div>\n    <div class=\"imgc-ctnt is-color extra-gt1\">\n      <form autocomplete=\"off\">\n        <div class=\"form-group\">\n          <label for=\"hexInput\" class=\"small\">{{languageObj.HEX_COLOR}}</label>\n          <input type=\"text\" class=\"form-control-sm\" id=\"hexInput\" name=\"hexInput\" maxlength=\"7\" placeholder=\"{{languageObj.HEX_COLOR}}\" [(ngModel)]=\"hexColor\"\n            required>\n        </div>\n        <button type=\"button\" class=\"btn-primary btn-sm btn\" (click)=\"insertColor(hexColor, selectedColorTab)\">{{languageObj.SUBMIT}}</button>\n      </form>\n    </div>\n  </div>\n</ng-template>\n\n<!-- font size template -->\n<ng-template #fontSizeTemplate>\n  <div class=\"ngxe-popover extra-gt1\">\n    <form autocomplete=\"off\">\n      <div class=\"form-group\">\n        <label for=\"fontSize\" class=\"small\">{{languageObj.FONT_SIZE}}</label>\n        <input type=\"text\" class=\"form-control-sm\" id=\"fontSize\" name=\"fontSize\" placeholder=\"{{languageObj.FONT_SIZE_IN_PXREM}}\" [(ngModel)]=\"fontSize\"\n          required>\n      </div>\n      <button type=\"button\" class=\"btn-primary btn-sm btn\" (click)=\"setFontSize(fontSize)\">{{languageObj.SUBMIT}}</button>\n    </form>\n  </div>\n</ng-template>\n\n<!-- font family/name template -->\n<ng-template #fontNameTemplate>\n  <div class=\"ngxe-popover extra-gt1\">\n    <form autocomplete=\"off\">\n      <div class=\"form-group\">\n        <label for=\"fontSize\" class=\"small\">{{languageObj.FONT_SIZE}}</label>\n        <input type=\"text\" class=\"form-control-sm\" id=\"fontSize\" name=\"fontName\" placeholder=\"{{languageObj.EX_TIMES_NEW_ROMAN_TIMES_SERIF}}\"\n          [(ngModel)]=\"fontName\" required>\n      </div>\n      <button type=\"button\" class=\"btn-primary btn-sm btn\" (click)=\"setFontName(fontName)\">{{languageObj.SUBMIT}}</button>\n    </form>\n  </div>\n</ng-template>\n\n<!-- Table Popover template -->\n<ng-template #insertTableTemplate>\n  <div class=\"ngxe-popover tbl-popover-ctnr\">\n    <div class=\"row-column-box-ctnr\" (mouseleave)=\"onMouseLeaveRowColumnBoxContainer()\">\n      <div class=\"row-column-box-row\" *ngFor=\"let rowColumnBoxRow of tablePopoverData.tablePopoverRowColumnBoxArray; let rowIndex = index;\">\n        <span *ngFor=\"let rowColumnBox of rowColumnBoxRow; let colIndex = index;\" class=\"row-column-box\"\n          [ngClass]=\"{'highlight': rowColumnBox['isHighlight']}\"\n          (mouseenter)=\"onMouseEnterRowColumnBox(rowIndex, colIndex)\"\n          (click)=\"onClickRowColumnBox(rowIndex, colIndex)\"></span>\n      </div>\n    </div>\n\n    <div class=\"selected-row-column-count\">\n      {{tablePopoverData.selectedTablePopoverRowIndex + 1}} x {{tablePopoverData.selectedTablePopoverColumnIndex + 1}}\n    </div>\n  </div>\n</ng-template>\n",
                styles: ["::ng-deep .ngxePopover.popover{position:absolute;top:0;left:0;z-index:1060;display:block;max-width:276px;font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,\"Helvetica Neue\",Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",\"Segoe UI Symbol\";font-style:normal;font-weight:400;line-height:1.5;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;letter-spacing:normal;word-break:normal;word-spacing:normal;white-space:normal;line-break:auto;font-size:12.25px;word-wrap:break-word;background-color:#fff;background-clip:padding-box;border:1px solid rgba(0,0,0,.2);border-radius:4.2px}::ng-deep .ngxePopover.popover .arrow{position:absolute;display:block;width:14px;height:7px;margin:0 4.2px;border-width:0}::ng-deep .ngxePopover.popover .arrow::after,::ng-deep .ngxePopover.popover .arrow::before{position:absolute;display:block;content:\"\";border-color:transparent;border-style:solid}::ng-deep .ngxePopover.popover .popover-header{padding:7px 10.5px;margin-bottom:0;font-size:14px;color:inherit;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-top-left-radius:calc(4.2px - 1px);border-top-right-radius:calc(4.2px - 1px)}::ng-deep .ngxePopover.popover .popover-header:empty{display:none}::ng-deep .ngxePopover.popover .popover-body{padding:7px 10.5px!important;color:#212529}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top],::ng-deep .ngxePopover.popover.bs-popover-top{margin-bottom:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow,::ng-deep .ngxePopover.popover.bs-popover-top .arrow{bottom:calc((7px + 1px) * -1);margin-left:0!important}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::before{border-width:7px 7px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::before{bottom:0;border-top-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::after{bottom:1px;border-top-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right],::ng-deep .ngxePopover.popover.bs-popover-right{margin-left:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow,::ng-deep .ngxePopover.popover.bs-popover-right .arrow{left:calc((7px + 1px) * -1);width:7px;height:14px;margin:4.2px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::before{border-width:7px 7px 7px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::before{left:0;border-right-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::after{left:1px;border-right-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom],::ng-deep .ngxePopover.popover.bs-popover-bottom{margin-top:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow{left:45%!important;top:calc((7px + 1px) * -1);margin-left:0!important}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::before{border-width:0 7px 7px}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::before{top:0;border-bottom-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::after{top:1px;border-bottom-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .popover-header::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .popover-header::before{position:absolute;top:0;left:50%;display:block;width:1rem;margin-left:-7px;content:\"\";border-bottom:1px solid #f7f7f7}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left],::ng-deep .ngxePopover.popover.bs-popover-left{margin-right:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow,::ng-deep .ngxePopover.popover.bs-popover-left .arrow{right:calc((7px + 1px) * -1);width:7px;height:14px;margin:4.2px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::before{border-width:7px 0 7px 7px}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::before{right:0;border-left-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::after{right:1px;border-left-color:#fff;margin-left:0}::ng-deep .ngxePopover .btn{display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:5.25px 10.5px;font-size:14px;line-height:1.5;border-radius:3.5px;-webkit-transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-box-shadow .15s ease-in-out}::ng-deep .ngxePopover .btn.btn-sm{padding:3.5px 7px;font-size:12.25px;line-height:1.5;border-radius:2.8px}::ng-deep .ngxePopover .btn:active,::ng-deep .ngxePopover .btn:focus{outline:0;-webkit-box-shadow:none;box-shadow:none}::ng-deep .ngxePopover .btn.btn-primary{color:#fff;background-color:#007bff;border-color:#007bff}::ng-deep .ngxePopover .btn.btn-primary:hover{color:#fff;background-color:#0069d9;border-color:#0062cc}::ng-deep .ngxePopover .btn:not(:disabled):not(.disabled){cursor:pointer}::ng-deep .ngxePopover form .form-group{margin-bottom:14px}::ng-deep .ngxePopover form .form-group input{overflow:visible}::ng-deep .ngxePopover form .form-group .form-control-sm{width:100%;outline:0;border:none;border-bottom:1px solid #bdbdbd;border-radius:0;margin-bottom:1px;padding:3.5px 7px;font-size:12.25px;line-height:1.5}::ng-deep .ngxePopover form .form-group.row{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-left:0;margin-right:0}::ng-deep .ngxePopover form .form-group.row .col{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%;padding:0}::ng-deep .ngxePopover form .form-group.row .col:first-child{padding-right:15px}::ng-deep .ngxePopover form .form-check{position:relative;display:block;padding-left:17.5px}::ng-deep .ngxePopover form .form-check .form-check-input{position:absolute;margin-top:4.2px;margin-left:-17.5px}.ngx-toolbar{background-color:#f5f5f5;font-size:.8rem;padding:.2rem;border:1px solid #ddd}.ngx-toolbar .custom-button-container,.ngx-toolbar .ngx-toolbar-set{display:inline-block;border-radius:5px;background-color:transparent}.ngx-toolbar .custom-button-container .ngx-editor-button,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button{background-color:#fff;padding:.4rem;min-width:2.5rem;float:left;border:1px solid #ddd;border-right:transparent}.ngx-toolbar .custom-button-container .ngx-editor-button:hover,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:hover{cursor:pointer;background-color:#f1f1f1;-webkit-transition:.2s;transition:.2s}.ngx-toolbar .custom-button-container .ngx-editor-button.active,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button.active{color:#00f}.ngx-toolbar .custom-button-container .ngx-editor-button.focus,.ngx-toolbar .custom-button-container .ngx-editor-button:focus,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button.focus,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:focus{outline:0}.ngx-toolbar .custom-button-container .ngx-editor-button:last-child,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:last-child{border-right:1px solid #ddd;border-top-right-radius:5px;border-bottom-right-radius:5px}.ngx-toolbar .custom-button-container .ngx-editor-button:first-child,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:first-child{border-top-left-radius:5px;border-bottom-left-radius:5px}.ngx-toolbar .custom-button-container .ngx-editor-button:disabled,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:disabled{background-color:#f5f5f5;pointer-events:none;cursor:not-allowed}.ngx-toolbar .ngx-toolbar-set.width-70{width:70%}.custom-button-container{float:right}::ng-deep .popover{border-top-right-radius:0;border-top-left-radius:0}::ng-deep .ngxe-popover{min-width:210px;white-space:nowrap}::ng-deep .ngxe-popover .extra-gt,::ng-deep .ngxe-popover.extra-gt{padding-top:7px!important}::ng-deep .ngxe-popover .extra-gt1,::ng-deep .ngxe-popover.extra-gt1{padding-top:10.5px!important}::ng-deep .ngxe-popover .extra-gt2,::ng-deep .ngxe-popover.extra-gt2{padding-top:14px!important}::ng-deep .ngxe-popover .form-group label{display:none;margin:0}::ng-deep .ngxe-popover .form-group .form-control-sm{width:100%;outline:0;border:none;border-bottom:1px solid #bdbdbd;border-radius:0;margin-bottom:1px;padding-left:0;padding-right:0}::ng-deep .ngxe-popover .form-group .form-control-sm:active,::ng-deep .ngxe-popover .form-group .form-control-sm:focus{border-bottom:2px solid #1e88e5;-webkit-box-shadow:none;box-shadow:none;margin-bottom:0}::ng-deep .ngxe-popover .form-group .form-control-sm.ng-dirty.ng-invalid:not(.ng-pristine){border-bottom:2px solid red}::ng-deep .ngxe-popover .form-check{margin-bottom:14px}::ng-deep .ngxe-popover .btn:focus{-webkit-box-shadow:none!important;box-shadow:none!important}::ng-deep .ngxe-popover.imgc-ctnr{margin:-7px -10.5px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar{-webkit-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);border-bottom:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button{background-color:transparent;border-radius:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button:hover{cursor:pointer;background-color:#f1f1f1;-webkit-transition:.2s;transition:.2s}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button.active{color:#007bff;-webkit-transition:.2s;transition:.2s;-webkit-box-shadow:none;box-shadow:none}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span{width:50%;text-align:center;display:inline-block;padding:5.6px 0;margin:0 -1px 2px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span:hover{cursor:pointer}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span.active{margin-bottom:-2px;border-bottom:2px solid #007bff;color:#007bff}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt{padding:7px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .progress{height:7px;margin:7px -7px -8.4px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image p{margin:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph{border:2px dashed #bdbdbd;padding:25.2px 0;position:relative;letter-spacing:1px;text-align:center}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph:hover{background:#ebebeb}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm{opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;z-index:2147483640;overflow:hidden;margin:0;padding:0;width:100%}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm input{cursor:pointer;position:absolute;right:0;top:0;bottom:0;margin:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm input[disabled]{cursor:not-allowed!important}::ng-deep .ngxe-popover.tbl-popover-ctnr{min-width:initial}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row{height:14px}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row span.row-column-box{display:inline-block;width:10px;height:10px;border:1px solid rgba(0,0,0,.2);border-radius:1px;margin:1px 2px}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row span.row-column-box.highlight{border-color:#007bff}::ng-deep .ngxe-popover.tbl-popover-ctnr .selected-row-column-count{text-align:center}"],
                providers: [ngxBootstrap.PopoverConfig]
            },] },
];
NgxEditorToolbarComponent.ctorParameters = function () { return [
    { type: ngxBootstrap.PopoverConfig, },
    { type: forms.FormBuilder, },
    { type: MessageService, },
    { type: CommandExecutorService, },
]; };
NgxEditorToolbarComponent.propDecorators = {
    "config": [{ type: core.Input },],
    "languageCode": [{ type: core.Input },],
    "languageObj": [{ type: core.Input },],
    "customButtonsArray": [{ type: core.Input },],
    "execute": [{ type: core.Output },],
    "triggerCustomClick": [{ type: core.Output },],
    "focusTextArea": [{ type: core.Output },],
    "triggerInsertImage": [{ type: core.Output },],
    "triggerInsertHtml": [{ type: core.Output },],
    "triggerInsertTable": [{ type: core.Output },],
    "showPopOver": [{ type: core.Output },],
    "hidePopOver": [{ type: core.Output },],
    "urlPopover": [{ type: core.ViewChild, args: ['urlPopover',] },],
    "imagePopover": [{ type: core.ViewChild, args: ['imagePopover',] },],
    "videoPopover": [{ type: core.ViewChild, args: ['videoPopover',] },],
    "fontSizePopover": [{ type: core.ViewChild, args: ['fontSizePopover',] },],
    "colorPopover": [{ type: core.ViewChild, args: ['colorPopover',] },],
    "tablePopover": [{ type: core.ViewChild, args: ['tablePopover',] },],
};
var NgxEditorComponent =               (function () {
    function NgxEditorComponent(_messageService, _commandExecutor, _renderer) {
        this._messageService = _messageService;
        this._commandExecutor = _commandExecutor;
        this._renderer = _renderer;
        this.resizer = 'stack';
        this.config = ngxEditorConfig;
        this.customButtonsArray = [];
        this.setFocus = false;
        this.pasteAsPlainText = false;
        this.languageCode = 'en';
        this.blur = new core.EventEmitter();
        this.focus = new core.EventEmitter();
        this.triggerCustomClick = new core.EventEmitter();
        this.change = new core.EventEmitter();
        this.optionClicked = new core.EventEmitter();
        this.triggerMessage = new core.EventEmitter();
        this.showPopOver = new core.EventEmitter();
        this.hidePopOver = new core.EventEmitter();
        this.Utils = Utils;
        this.IS_IE = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
        this.savedSelection = undefined;
        this.languageObj = {};
        this.TABLE_CONTAINER_CLASS = 'ngx-editor-table-container';
        this.TABLE_TEMPLATES = {
            COLUMN: "<td></td>",
            ROW: "<tr>{tableRowCellsHtml}</tr>",
            TABLE: "<div id=\"{tableContainerId}\" class=\"" + this.TABLE_CONTAINER_CLASS + "\">\n      <table>\n        <tbody>{tableRowsHtml}</tbody>\n      </table>\n    </div>"
        };
        this.tableCellContextMenuData = {
            items: [],
            style: {
                left: 0,
                top: 0
            },
            rowIndex: -1,
            columnIndex: -1,
            tableContainerId: ''
        };
    }
    NgxEditorComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.languageObj = require('../i18n/' + this.languageCode + '.json');
        this.config = this.Utils.getEditorConfiguration(this.config, ngxEditorConfig, this.getCollectiveParams());
        this.height = this.height || this.textArea.nativeElement.offsetHeight;
        this.executeCommand('enableObjectResizing', false);
        this._messageService.getMessage().subscribe(function (message) {
            _this.triggerMessage.emit(message);
        });
        this.initializeNgxEditorTable();
    };
    NgxEditorComponent.prototype.ngOnChanges = function (changes) {
        if (changes && changes.setFocus && changes.setFocus.currentValue) {
            this.textArea.nativeElement.focus();
        }
    };
    NgxEditorComponent.prototype.ngAfterViewInit = function () {
        if (this.pasteAsPlainText) {
            this.pasteEventListener =
                this._renderer.listen(this.textArea.nativeElement, 'paste', this.executePasteAsPlainText.bind(this));
        }
    };
    NgxEditorComponent.prototype.ngOnDestroy = function () {
        if (this.pasteEventListener) {
            this.pasteEventListener();
        }
    };
    NgxEditorComponent.prototype.afterWriteNgxEditorValue = function () {
        this.bindNgxEditorTableContextMenuEvent();
    };
    NgxEditorComponent.prototype.onTextAreaFocus = function () {
        this.focus.emit('focus');
    };
    NgxEditorComponent.prototype.onEditorFocus = function () {
        this.textArea.nativeElement.focus();
    };
    NgxEditorComponent.prototype.onContentChange = function (html) {
        if (typeof this.onChange === 'function') {
            this.onChange(html);
            this.togglePlaceholder(html);
        }
        this.change.emit(html);
    };
    NgxEditorComponent.prototype.onTextAreaBlur = function (event) {
        this.saveSelection(saveSelection());
        if (typeof this.onTouched === 'function') {
            this.onTouched();
        }
        this.blur.emit(event);
    };
    NgxEditorComponent.prototype.onSelectionChange = function () {
        this.saveSelection(saveSelection());
        this.ngxToolbar.activeButtonArray = checkFormatting(window.getSelection());
    };
    NgxEditorComponent.prototype.resizeTextArea = function (offsetY) {
        var newHeight = parseInt(this.height, 10);
        newHeight += offsetY;
        this.height = newHeight + 'px';
        this.textArea.nativeElement.style.height = this.height;
    };
    NgxEditorComponent.prototype.executeCommand = function (commandName, emit) {
        if (emit === void 0) { emit = true; }
        try {
            this._commandExecutor.execute(commandName);
            if (emit) {
                this.optionClicked.emit();
            }
        }
        catch (error) {
            this._messageService.sendMessage(error.message);
        }
    };
    NgxEditorComponent.prototype.writeValue = function (value) {
        this.togglePlaceholder(value);
        if (value === null || value === undefined || value === '' || value === '<br>') {
            value = null;
        }
        this.refreshView(value);
        this.afterWriteNgxEditorValue();
    };
    NgxEditorComponent.prototype.registerOnChange = function (fn) {
        this.onChange = fn;
    };
    NgxEditorComponent.prototype.registerOnTouched = function (fn) {
        this.onTouched = fn;
    };
    NgxEditorComponent.prototype.refreshView = function (value) {
        var normalizedValue = value === null ? '' : value;
        this._renderer.setProperty(this.textArea.nativeElement, 'innerHTML', normalizedValue);
    };
    NgxEditorComponent.prototype.togglePlaceholder = function (value) {
        if (!value || value === '<br>' || value === '') {
            this._renderer.addClass(this.ngxWrapper.nativeElement, 'show-placeholder');
        }
        else {
            this._renderer.removeClass(this.ngxWrapper.nativeElement, 'show-placeholder');
        }
    };
    NgxEditorComponent.prototype.getCollectiveParams = function () {
        return {
            editable: this.editable,
            spellcheck: this.spellcheck,
            placeholder: this.placeholder,
            translate: this.translate,
            height: this.height,
            minHeight: this.minHeight,
            width: this.width,
            minWidth: this.minWidth,
            enableToolbar: this.enableToolbar,
            showToolbar: this.showToolbar,
            imageEndPoint: this.imageEndPoint,
            toolbar: this.toolbar
        };
    };
    NgxEditorComponent.prototype.onTriggerCustomClick = function (btnText) {
        this.triggerCustomClick.emit(btnText);
    };
    NgxEditorComponent.prototype.focusTextArea = function () {
        var _this = this;
        setTimeout(function () {
            _this.textArea.nativeElement.focus();
        }, 0);
    };
    NgxEditorComponent.prototype.executePasteAsPlainText = function (event) {
        event.preventDefault();
        var plainText = '';
        if (this.IS_IE) {
            if (window['clipboardData'] && window.getSelection) {
                plainText = window['clipboardData'].getData('Text').replace(/(?:\r\n|\r|\n)/g, '<br>');
                var element = document.createElement('span');
                element.innerHTML = plainText;
                var selectedRange = window.getSelection().getRangeAt(0);
                selectedRange.deleteContents();
                selectedRange.insertNode(element);
            }
        }
        else {
            var clipboardData = (event.originalEvent || event).clipboardData;
            var htmlContent = clipboardData.getData('text/html').trim();
            var imageListHtml = '';
            var divElement = document.createElement('div');
            divElement.innerHTML = htmlContent;
            var imageCollection = divElement.getElementsByTagName('img');
            for (var index = 0, length = imageCollection.length; index < length; index++) {
                var imageElement = imageCollection[index];
                imageListHtml += '<img alt="' + imageElement.alt + '" src="' + imageElement.src + '">' + '&nbsp;<br>';
            }
            if (htmlContent === '') {
                var itemList = clipboardData.items;
                for (var index = 0, length = itemList.length; index < length; index++) {
                    var item = itemList[index];
                    if (item.kind === 'file') {
                        var file = item.getAsFile();
                        var reader = new FileReader();
                        reader.onload = function ($event) {
                            var imageHtml = '<img src="' + $event.target.result + '">' + '&nbsp;<br>';
                            document.execCommand('insertHTML', false, imageHtml);
                        };
                        reader.readAsDataURL(file);
                    }
                }
            }
            plainText = (event.originalEvent || event).clipboardData.getData('text/plain');
            plainText = plainText.replace(/(?:\r\n|\r|\n)/g, '<br>');
            document.execCommand('insertHTML', false, imageListHtml + plainText);
        }
    };
    NgxEditorComponent.prototype.insertImage = function (imageURI) {
        if (!this.savedSelection) {
            this.saveSelection(this.getEditorElementRange());
        }
        this._commandExecutor.insertImage(imageURI);
    };
    NgxEditorComponent.prototype.onShowPopOver = function () {
        this.showPopOver.emit();
    };
    NgxEditorComponent.prototype.onHidePopOver = function () {
        this.hidePopOver.emit();
    };
    NgxEditorComponent.prototype.insertHtml = function (html) {
        if (!this.savedSelection) {
            this.saveSelection(this.getEditorElementRange());
        }
        this._commandExecutor.restoreSelectionAndInsertHtml(html, this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype.insertTable = function (tableData) {
        var generateTableResponse = this.generateTableHtml(tableData.totalTableRows, tableData.totalTableColumns);
        this.insertHtml(generateTableResponse.templateHtml.replace(/\n/g, ''));
        this.focusElementInsideEditor(this._tblSelector(generateTableResponse.tableContainerId)
            + ' > tbody > tr:first-child > td:first-child');
        this.bindNgxEditorTableContextMenuEvent(generateTableResponse.tableContainerId);
    };
    NgxEditorComponent.prototype.initializeNgxEditorTable = function () {
        this.tableCellContextMenuData.items = [
            {
                label: this.languageObj.INSERT,
                items: [
                    {
                        label: this.languageObj.INSERT_ABOVE,
                        command: this.onInsertTableRowAbove.bind(this)
                    }, {
                        label: this.languageObj.INSERT_BELOW,
                        command: this.onInsertTableRowBelow.bind(this)
                    }, {
                        label: this.languageObj.INSERT_LEFT,
                        command: this.onInsertTableColumnBefore.bind(this)
                    }, {
                        label: this.languageObj.INSERT_RIGHT,
                        command: this.onInsertTableColumnAfter.bind(this)
                    }
                ]
            }, {
                label: this.languageObj.DELETE,
                items: [
                    {
                        label: this.languageObj.DELETE_ROW,
                        command: this.onDeleteTableRow.bind(this)
                    }, {
                        label: this.languageObj.DELETE_COLUMN,
                        command: this.onDeleteTableColumn.bind(this)
                    }, {
                        label: this.languageObj.DELETE_TABLE,
                        command: this.onDeleteTable.bind(this)
                    }
                ]
            }
        ];
    };
    NgxEditorComponent.prototype.bindNgxEditorTableContextMenuEvent = function (tableContainerId) {
        var _this = this;
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td')).forEach(function (tableCellElement) {
            tableCellElement.addEventListener('contextmenu', _this.onContextMenuTableCell.bind(_this));
        });
    };
    NgxEditorComponent.prototype.bindNgxEditorTableRowContextMenuEvent = function (tableContainerId, rowNumber) {
        var _this = this;
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + rowNumber + ') > td'))
            .forEach(function (tableCellElement) {
            tableCellElement.addEventListener('contextmenu', _this.onContextMenuTableCell.bind(_this));
        });
    };
    NgxEditorComponent.prototype.bindNgxEditorTableColumnContextMenuEvent = function (tableContainerId, columnNumber) {
        var _this = this;
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + columnNumber + ')'))
            .forEach(function (tableCellElement) {
            tableCellElement.addEventListener('contextmenu', _this.onContextMenuTableCell.bind(_this));
        });
    };
    NgxEditorComponent.prototype.onContextMenuTableCell = function (event) {
        event.preventDefault();
        event.stopPropagation();
        this.tableCellContextMenuData.style.left = event.pageX;
        this.tableCellContextMenuData.style.top = event.pageY;
        var tableCellElement = event.currentTarget;
        var tableContainerElement = getClosest(tableCellElement, '.' + this.TABLE_CONTAINER_CLASS);
        this.tableCellContextMenuData.columnIndex = getIndex(tableCellElement);
        this.tableCellContextMenuData.rowIndex = getIndex(tableCellElement.parentElement);
        this.tableCellContextMenuData.tableContainerId = tableContainerElement.id;
        this.tableCellContextMenu.show();
        return false;
    };
    NgxEditorComponent.prototype.onInsertTableRowAbove = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var rowNumber = this.tableCellContextMenuData.rowIndex + 1;
        this.insertTableRow(tableContainerId, rowNumber);
        this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
    };
    NgxEditorComponent.prototype.onInsertTableRowBelow = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var rowNumber = this.tableCellContextMenuData.rowIndex + 2;
        this.insertTableRow(tableContainerId, rowNumber);
        this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
    };
    NgxEditorComponent.prototype.onInsertTableColumnBefore = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var columnNumber = this.tableCellContextMenuData.columnIndex + 1;
        this.insertTableColumn(tableContainerId, columnNumber);
        this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
    };
    NgxEditorComponent.prototype.onInsertTableColumnAfter = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var columnNumber = this.tableCellContextMenuData.columnIndex + 2;
        this.insertTableColumn(tableContainerId, columnNumber);
        this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
    };
    NgxEditorComponent.prototype.onDeleteTableRow = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var rowNumber = this.tableCellContextMenuData.rowIndex + 1;
        this.deleteTableRow(tableContainerId, rowNumber);
    };
    NgxEditorComponent.prototype.onDeleteTableColumn = function (event) {
        var tableContainerId = this.tableCellContextMenuData.tableContainerId;
        var columnNumber = this.tableCellContextMenuData.columnIndex + 1;
        this.deleteTableColumn(tableContainerId, columnNumber);
    };
    NgxEditorComponent.prototype.onDeleteTable = function (event) {
        var tableContainerElement = this.textArea.nativeElement.querySelector('#' + this.tableCellContextMenuData.tableContainerId);
        tableContainerElement.querySelector('table').remove();
        if (tableContainerElement.innerHTML.trim() === '') {
            tableContainerElement.remove();
        }
        else {
            tableContainerElement.removeAttribute('id');
            tableContainerElement.removeAttribute('class');
        }
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype.saveSelection = function (savedSelection) {
        this.savedSelection = savedSelection;
        this._commandExecutor.savedSelection = savedSelection;
    };
    NgxEditorComponent.prototype.focusElementInsideEditor = function (elementCssSelector) {
        var range = this.getEditorElementRange(elementCssSelector);
        this.saveSelection(range);
        return restoreSelection(range);
    };
    NgxEditorComponent.prototype.getEditorElementRange = function (elementCssSelector) {
        var element = elementCssSelector ?
            this.textArea.nativeElement.querySelector(elementCssSelector) : this.textArea.nativeElement;
        var range = document.createRange();
        range.setStart(element, element.childNodes.length);
        return range;
    };
    NgxEditorComponent.prototype.generateTableHtml = function (totalTableRows, totalTableColumns) {
        var tableContainerId = 'table-container-' + Date.now().toString();
        var templateHtml = '', tableRowsHtml = '';
        for (var rowIndex = 0; rowIndex < totalTableRows; rowIndex++) {
            tableRowsHtml += this.TABLE_TEMPLATES.ROW.replace('{tableRowCellsHtml}', this.generateTableRowHtml(totalTableColumns));
        }
        templateHtml = this.TABLE_TEMPLATES.TABLE.replace('{tableRowsHtml}', tableRowsHtml)
            .replace(/{tableContainerId}/g, tableContainerId);
        return {
            templateHtml: templateHtml,
            tableContainerId: tableContainerId
        };
    };
    NgxEditorComponent.prototype.generateTableRowHtml = function (totalCells) {
        var tableRowHtml = '';
        for (var index = 0; index < totalCells; index++) {
            tableRowHtml += this.TABLE_TEMPLATES.COLUMN;
        }
        return tableRowHtml;
    };
    NgxEditorComponent.prototype.insertTableRow = function (tableContainerId, position) {
        var tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + position + ')');
        var whereToInsert = 'beforebegin';
        if (!tableRow) {
            tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
                + ' > tbody > tr:nth-child(' + (position - 1) + ')');
            whereToInsert = 'afterend';
        }
        var totalColumn = getImmediateChildrenUsingTagName(tableRow, 'td').length;
        tableRow.insertAdjacentHTML(whereToInsert, this.generateTableRowHtml(totalColumn).replace(/\n/g, ''));
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype.insertTableColumn = function (tableContainerId, position) {
        var _this = this;
        var tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + position + ')');
        var whereToInsert = 'beforebegin';
        if (tableColumnCellList.length === 0) {
            tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
                + ' > tbody > tr > td:nth-child(' + (position - 1) + ')');
            whereToInsert = 'afterend';
        }
        tableColumnCellList.forEach(function (tableColumnCell) {
            tableColumnCell.insertAdjacentHTML(whereToInsert, _this.TABLE_TEMPLATES.COLUMN.replace(/\n/g, ''));
        });
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype.deleteTableRow = function (tableContainerId, position) {
        var tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + position + ')');
        tableRow.remove();
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype.deleteTableColumn = function (tableContainerId, position) {
        var tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + position + ')');
        tableColumnCellList.forEach(function (tableColumnCell) {
            tableColumnCell.remove();
        });
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    };
    NgxEditorComponent.prototype._tblSelector = function (tableContainerId) {
        return 'div.' + this.TABLE_CONTAINER_CLASS
            + (tableContainerId ? '#' + tableContainerId : '')
            + ' > table';
    };
    return NgxEditorComponent;
}());
NgxEditorComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'app-ngx-editor',
                template: "<div class=\"ngx-editor\" id=\"ngxEditor\" [style.width]=\"config['width']\" [style.minWidth]=\"config['minWidth']\" tabindex=\"0\"\n  (focus)=\"onEditorFocus()\">\n\n  <app-ngx-editor-toolbar #ngxToolbar [languageCode]=\"languageCode\" [languageObj]=\"languageObj\" [config]=\"config\" [customButtonsArray]=\"customButtonsArray\" \n    (execute)=\"executeCommand($event)\" (triggerCustomClick)=\"onTriggerCustomClick($event)\" (focusTextArea)=\"focusTextArea()\"\n    (triggerInsertImage)=\"insertImage($event)\" (triggerInsertHtml)=\"insertHtml($event)\" (showPopOver)=\"onShowPopOver()\" \n    (hidePopOver)=\"onHidePopOver()\" (triggerInsertTable)=\"insertTable($event)\"></app-ngx-editor-toolbar>\n\n  <!-- text area -->\n  <div class=\"ngx-wrapper\" #ngxWrapper>\n    <div #ngxTextArea id=\"ngxEditorTextarea\" class=\"ngx-editor-textarea\" [attr.contenteditable]=\"config['editable']\" \n      [attr.translate]=\"config['translate']\" [attr.spellcheck]=\"config['spellcheck']\" [style.height]=\"config['height']\" \n      [style.minHeight]=\"config['minHeight']\" [style.resize]=\"Utils?.canResize(resizer)\" (input)=\"onContentChange($event.target.innerHTML)\"\n      (focus)=\"onTextAreaFocus()\" (blur)=\"onTextAreaBlur($event)\" (click)=\"onSelectionChange()\" (keyup)=\"onSelectionChange()\">\n    </div>\n\n    <span class=\"ngx-editor-placeholder\">{{ placeholder || config['placeholder'] }}</span>\n  </div>\n</div>\n\n<p-contextMenu #tableCellContextMenu [model]=\"tableCellContextMenuData.items\" appendTo=\"body\"\n  styleClass=\"table-cell-context-menu\"\n  [style]=\"{'left': tableCellContextMenuData.style.left + 'px', 'top': tableCellContextMenuData.style.top + 'px'}\">\n</p-contextMenu>\n",
                styles: [".ngx-editor{position:relative}.ngx-editor ::ng-deep [contenteditable=true]:empty:before{content:normal;display:block;color:#868e96;opacity:1}.ngx-editor .ngx-wrapper{position:relative}.ngx-editor .ngx-wrapper .ngx-editor-textarea{min-height:5rem;padding:.5rem .8rem 1rem;border:1px solid #ddd;background-color:#fff;overflow-x:auto;overflow-y:auto;z-index:2;position:relative}.ngx-editor .ngx-wrapper .ngx-editor-textarea.focus,.ngx-editor .ngx-wrapper .ngx-editor-textarea:focus{outline:0}.ngx-editor .ngx-wrapper .ngx-editor-textarea ::ng-deep blockquote{margin-left:1rem;border-left:.2em solid #dfe2e5;padding-left:.5rem}.ngx-editor .ngx-wrapper ::ng-deep p{margin-bottom:0}.ngx-editor .ngx-wrapper .ngx-editor-placeholder{display:none;position:absolute;top:0;padding:.5rem .8rem 1rem .9rem;z-index:1;color:#6c757d;opacity:1}.ngx-editor .ngx-wrapper.show-placeholder .ngx-editor-placeholder{display:block}::ng-deep .ui-widget.ui-contextmenu{font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,\"Helvetica Neue\",Arial,sans-serif;text-decoration:none;font-size:13px;background:#fff;width:200px}::ng-deep .ui-widget.ui-contextmenu.table-cell-context-menu{width:100px}::ng-deep .ui-widget.ui-contextmenu .ui-menuitem-link{color:#676a6c}::ng-deep .ui-widget.ui-contextmenu .ui-menuitem-link:hover{text-decoration:none}::ng-deep .ui-widget.ui-contextmenu .ui-submenu-list{background-color:#fff}"],
                providers: [
                    {
                        provide: forms.NG_VALUE_ACCESSOR,
                        useExisting: core.forwardRef(function () { return NgxEditorComponent; }),
                        multi: true
                    }
                ]
            },] },
];
NgxEditorComponent.ctorParameters = function () { return [
    { type: MessageService, },
    { type: CommandExecutorService, },
    { type: core.Renderer2, },
]; };
NgxEditorComponent.propDecorators = {
    "editable": [{ type: core.Input },],
    "spellcheck": [{ type: core.Input },],
    "placeholder": [{ type: core.Input },],
    "translate": [{ type: core.Input },],
    "height": [{ type: core.Input },],
    "minHeight": [{ type: core.Input },],
    "width": [{ type: core.Input },],
    "minWidth": [{ type: core.Input },],
    "toolbar": [{ type: core.Input },],
    "resizer": [{ type: core.Input },],
    "config": [{ type: core.Input },],
    "showToolbar": [{ type: core.Input },],
    "enableToolbar": [{ type: core.Input },],
    "imageEndPoint": [{ type: core.Input },],
    "customButtonsArray": [{ type: core.Input },],
    "setFocus": [{ type: core.Input },],
    "pasteAsPlainText": [{ type: core.Input },],
    "languageCode": [{ type: core.Input },],
    "blur": [{ type: core.Output },],
    "focus": [{ type: core.Output },],
    "triggerCustomClick": [{ type: core.Output },],
    "change": [{ type: core.Output },],
    "optionClicked": [{ type: core.Output },],
    "triggerMessage": [{ type: core.Output },],
    "showPopOver": [{ type: core.Output },],
    "hidePopOver": [{ type: core.Output },],
    "textArea": [{ type: core.ViewChild, args: ['ngxTextArea',] },],
    "ngxWrapper": [{ type: core.ViewChild, args: ['ngxWrapper',] },],
    "ngxToolbar": [{ type: core.ViewChild, args: ['ngxToolbar',] },],
    "tableCellContextMenu": [{ type: core.ViewChild, args: ['tableCellContextMenu',] },],
};
var NgxEditorModule =               (function () {
    function NgxEditorModule() {
    }
    return NgxEditorModule;
}());
NgxEditorModule.decorators = [
    { type: core.NgModule, args: [{
                imports: [common.CommonModule, forms.FormsModule, forms.ReactiveFormsModule, ngxBootstrap.PopoverModule.forRoot(), primeng.ContextMenuModule],
                declarations: [NgxEditorComponent, NgxEditorToolbarComponent],
                exports: [NgxEditorComponent, ngxBootstrap.PopoverModule],
                providers: [CommandExecutorService, MessageService]
            },] },
];

exports.NgxEditorModule = NgxEditorModule;
exports.ɵc = CommandExecutorService;
exports.ɵb = MessageService;
exports.ɵd = NgxEditorToolbarComponent;
exports.ɵa = NgxEditorComponent;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-editor.umd.js.map
