export class Constants {
    public static SUPPORTED_IMAGE_TYPES: string[] = ['image/png', 'image/jpeg', 'image/gif'];

    public static MAXIMUM_IMAGE_SIZE: number = 1024 * 1024; // 1MB = 1KB * 1KB = 1024B * 1024B;
}
