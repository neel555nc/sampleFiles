import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from './app.service';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [AppService]
})

export class AppComponent implements OnInit, OnDestroy {

  title = 'ngx-editor';
  latestRelease: any = [];
  private subscription: Subject<any> = new Subject();
  editorConfig = {
    editable: true,
    spellcheck: false,
    height: '10rem',
    minHeight: '5rem',
    placeholder: 'Type something. Test the Editor... ヽ(^。^)丿',
    translate: 'no'
  };
  customButtonsArray = [
    {
      icon: 'fa fa-edit',
      value: 'Edit Source',
      btnText: 'editSource',
    //  disabled: true
    }
  ];
  setFocus = false;
  htmlContent = '';
  //htmlContent ='<div id="table-container-1622253818590" class="ngx-editor-table-container"> <table> <tbody><tr><td>1</td><td></td><td></td></tr><tr><td>2</td><td><div id="table-container-1622253842954" class="ngx-editor-table-container"> <table> <tbody><tr><td>11</td><td></td></tr><tr><td>22</td><td></td></tr></tbody> </table></div></td><td>2</td></tr><tr><td>3</td><td></td><td></td></tr></tbody> </table><br></div><div id="table-container-1622253818590" class="ngx-editor-table-container"><div id="table-container-1622255893030" class="ngx-editor-table-container"> <table> <tbody><tr><td>1</td><td></td><td></td><td></td><td></td></tr><tr><td></td><td>2</td><td></td><td></td><td></td></tr><tr><td></td><td></td><td>3</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td>4</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td>5</td></tr></tbody> </table></div></div><style> #table-container-1622253719219 table { } #table-container-1622253719219 table > tbody > tr { } #table-container-1622253719219 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253725586 table { } #table-container-1622253725586 table > tbody > tr { } #table-container-1622253725586 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253791836 table { } #table-container-1622253791836 table > tbody > tr { } #table-container-1622253791836 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253798173 table { } #table-container-1622253798173 table > tbody > tr { } #table-container-1622253798173 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253818590 table { } #table-container-1622253818590 table > tbody > tr { } #table-container-1622253818590 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253824148 table { } #table-container-1622253824148 table > tbody > tr { } #table-container-1622253824148 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622253842954 table { } #table-container-1622253842954 table > tbody > tr { } #table-container-1622253842954 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style><style> #table-container-1622255893030 table { } #table-container-1622255893030 table > tbody > tr { } #table-container-1622255893030 table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style>';
  //htmlContent = '<div id="table-container-1622270671498" class="ngx-editor-table-container"> <table> <tbody><tr><td><b>Entity Key</b></td><td><b>Description</b></td><td><b>Priority</b></td><td></td></tr><tr><td>QTM-DMO-1</td><td>check login is working or not.</td><td>Medium</td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td>asas</td><td>as</td><td>asa</td><td>as</td></tr><tr><td></td><td>as</td><td>asa</td><td>as</td></tr></tbody> </table></div><style id="style-table-container-1622270671498"> #table-container-1622270671498 > table { } #table-container-1622270671498 > table > tbody > tr { } #table-container-1622270671498 > table > tbody > tr > td { border: 1px solid rgba(0, 0, 0, 0.2); border-collapse: collapse; padding: 5px; min-width: 100px; } </style>'

  /**
   * @param _appService service for app component
   */
  constructor(private _appService: AppService) {}

  ngOnInit() {
    this.getLatestRelease();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getLatestRelease(): void {
    this.subscription = this._appService.getLatestRelease().subscribe(
      (data) => {
        this.latestRelease = data[0];
      },
      (error) => {
        console.log(error);
      },
      () => {
        console.log('latest release: ' + this.latestRelease['name']);
      }
    );
  }

  onTriggerCustomClick(btnText: string): void {
    console.log('triggerer custom click, button text \'' + btnText + '\'');
    this.setFocus = true;
  }

  onChange(value: string): void {
    console.log('onChange fired with value \'' + value + '\'');
  }

  onFocusOut(value: string): void {
    console.log('onFocusOut called with value \'' + value + '\'');
    this.setFocus = false;
  }

  optionClicked(): void {
    console.log('optionClicked called!');
  }

  triggerMessage(message: string): void {
    console.log('message triggered with text \'' + message + '\'');
  }

  onClickPopOverSection(): void {
    console.log('clicked popover section');
  }

  onShowPopOver(): void {
    document.getElementsByClassName('popover')[0].addEventListener('click', this.onClickPopOverSection);
  }

}
