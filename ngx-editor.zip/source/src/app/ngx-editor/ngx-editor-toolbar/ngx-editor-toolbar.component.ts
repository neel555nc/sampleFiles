import { Component, Input, Output, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { PopoverConfig } from 'ngx-bootstrap';
import { CommandExecutorService } from '../common/services/command-executor.service';
import { MessageService } from '../common/services/message.service';
import * as Utils from '../common/utils/ngx-editor.utils';
import { FileUtils } from '../common/utils/file.utils';
import { ImageConfig } from '../common/models/image-config.type';
import { Constants } from '../../app.constant';

/**
 * es5 does not support dynamic import
 * require is used to get translated files for current language code
 */
declare var require: any;

@Component({
  selector: 'app-ngx-editor-toolbar',
  templateUrl: './ngx-editor-toolbar.component.html',
  styleUrls: ['./ngx-editor-toolbar.component.scss'],
  providers: [PopoverConfig]
})

export class NgxEditorToolbarComponent implements OnInit {

  /** Editor configuration */
  @Input() config: any;
  @Input() languageCode: string;
  @Input() languageObj: any;
   /** List of custom buttons if any */
  @Input() customButtonsArray: any = [];

  @Output() execute: EventEmitter<string> = new EventEmitter<string>();
  /** emits `triggerCustomClick` event when custombutton is clicked -> returns btntext to identify which button clicked */
  @Output() triggerCustomClick: EventEmitter<any> = new EventEmitter<any>();
  @Output() focusTextArea: EventEmitter<any> = new EventEmitter<any>();
  @Output() triggerInsertImage: EventEmitter<string> = new EventEmitter<string>();
  @Output() triggerInsertHtml: EventEmitter<string> = new EventEmitter<string>();
  /** when user inserts table. */
  @Output() triggerInsertTable: EventEmitter<any> = new EventEmitter<any>();
  /** when popover is show/hide. */
  @Output() showPopOver: EventEmitter<any> = new EventEmitter<any>();
  @Output() hidePopOver: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('urlPopover') urlPopover;
  @ViewChild('imagePopover') imagePopover;
  @ViewChild('videoPopover') videoPopover;
  @ViewChild('fontSizePopover') fontSizePopover;
  @ViewChild('colorPopover') colorPopover;
  @ViewChild('tablePopover') tablePopover;

  /** holds values of the insert link form */
  urlForm: FormGroup;
  /** holds values of the insert image form */
  imageForm: FormGroup;
  /** holds values of the insert video form */
  videoForm: FormGroup;
  /** set to false when image is being uploaded */
  uploadComplete = true;
  /** upload percentage */
  updloadPercentage = 0;
  /** set to true when the image is being uploaded */
  isUploading = false;
  /** which tab to active for color insetion */
  selectedColorTab = 'textColor';
  /** font family name */
  fontName = '';
  /** font size */
  fontSize = '';
  /** hex color code */
  hexColor = '';
  /** show/hide image uploader */
  isImageUploader = true;
  urlPattern: any = /https?:\/\/.+/;
  activeButtonArray = {
    bold : false,
    italic : false,
    underline : false,
    superscript : false,
    subscript : false,
    orderedlist : false,
    unorderedlist : false,
    blockquote : false,
    removeblockquote : false,
    strikethrough : false
  };
  isMoreShow = false;
  moreButtonText = '';
  tablePopoverData: any = {
    tablePopoverRowColumnBoxArray: [],
    popoverRowsLength: 0,
    popoverColumnsLength: 0,
    selectedTablePopoverRowIndex: -1,
    selectedTablePopoverColumnIndex: -1
  };

  constructor(private _popOverConfig: PopoverConfig,
    private _formBuilder: FormBuilder,
    private _messageService: MessageService,
    private _commandExecutorService: CommandExecutorService) {
    this._popOverConfig.outsideClick = true;
    this._popOverConfig.placement = 'bottom';
    this._popOverConfig.container = 'body';
  }

  ngOnInit() {
    this.isMoreShow = this.config['isMoreShow'] || false;
    this.showLessOrMore(this.isMoreShow);
    this.buildUrlForm();
    this.buildImageForm();
    this.buildVideoForm();
    this.initTablePopover();
  }

  /**
   * enable or diable toolbar based on configuration
   *
   * @param value name of the toolbar buttons
   */
  canEnableToolbarOptions(value): boolean {
    return Utils.canEnableToolbarOptions(value, this.config['toolbar']);
  }

  /**
   * triggers command from the toolbar to be executed and emits an event
   *
   * @param command name of the command to be executed
   */
  triggerCommand(command: string): void {
    if (!this._commandExecutorService.savedSelection) {
      this.focusTextArea.emit();
    }
    if (command === 'removeFormat') {
      this.clearActiveButtonWhileErase();
    } else {
      this.activeButtonArray[command.toLowerCase()] = !this.activeButtonArray[command.toLowerCase()];
    }
    this.execute.emit(command);
  }

  /**
   * clears active buttons while erase.
   */
  clearActiveButtonWhileErase(): void {
    const formattedButton = ['bold', 'italic', 'underline', 'superscript', 'subscript', 'strikethrough'];
    formattedButton.forEach(btn => {
      this.activeButtonArray[btn] = false;
    });
  }

  /**
   * create URL insert form
   */
  buildUrlForm(setFocus = false): void {
    if (setFocus) {
      this.focusTextArea.emit();
    }
    this.urlForm = this._formBuilder.group({
      urlLink: ['', [Validators.required]],
      urlText: ['', [Validators.required]],
      urlNewTab: [true]
    });
  }

  /**
   * inserts link in the editor
   */
  insertLink(): void {
    try {
      this._commandExecutorService.createLink(this.urlForm.value);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    /** reset form to default */
    this.buildUrlForm();
    /** close inset URL pop up */
    this.urlPopover.hide();
  }

  /**
   * create insert image form
   */
  buildImageForm(): void {
    this.imageForm = this._formBuilder.group({
      imageUrl: ['', [Validators.required]]
    });
  }

  /**
   * create insert image form
   */
  buildVideoForm(): void {
    this.videoForm = this._formBuilder.group({
      videoUrl: ['', [Validators.required]],
      height: [''],
      width: ['']
    });
  }

  /**
   * Executed when file is selected
   *
   * @param e- onChange event.
   */
  onFileChange(e: any): void {
    if (e.target.files.length > 0) {
      const file: File = e.target.files[0];

      const imageConfig: ImageConfig = this.config.image;
      const fileUtilsObj = new FileUtils(file.name, file.type, file.size);
      fileUtilsObj.supportedFileTypes = imageConfig.supportedFileTypes || Constants.SUPPORTED_IMAGE_TYPES;
      fileUtilsObj.maximumFileSize = imageConfig.maximumFileSize || Constants.MAXIMUM_IMAGE_SIZE;

      // validate file type
      if (!fileUtilsObj.isValidFileType()) {
        this._messageService.sendMessage('FILE_TYPE_INVALID');
        this.buildImageForm(); // reset form to default
        this.imagePopover.hide(); // close inset URL pop up
        return;
      }

      // validate file size
      if (!fileUtilsObj.isValidFileSize()) {
        this._messageService.sendMessage('FILE_SIZE_INVALID');
        this.buildImageForm(); // reset form to default
        this.imagePopover.hide(); // close inset URL pop up
        return;
      }

      this.uploadComplete = false;
      this.isUploading = true;
      try {
        this._commandExecutorService.uploadImage(file, imageConfig.apiDetail).subscribe(event => {

          if (event instanceof HttpResponse) {
            try {
              this.triggerInsertImage.emit(event.body.url);
            } catch (error) {
              this._messageService.sendMessage(error.message);
            }
            this.buildImageForm(); // reset form to default
            this.imagePopover.hide(); // close inset URL pop up

            this.updloadPercentage = 100;
            this.uploadComplete = true;
            this.isUploading = false;
          }
        }, error => {
          if (error instanceof HttpErrorResponse) {
            this.buildImageForm(); // reset form to default
            this.imagePopover.hide(); // close inset URL pop up

            this._messageService.sendMessage('SERVICE_FAILED');
            this.uploadComplete = true;
            this.isUploading = false;
          }
        });
      } catch (error) {
        this._messageService.sendMessage(error.message);
        this.uploadComplete = true;
        this.isUploading = false;
      }

    }
  }

  /**
   * insert image in the editor
   */
  insertImage(): void {
    try {
      this.triggerInsertImage.emit(this.imageForm.value.imageUrl);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    /** reset form to default */
    this.buildImageForm();
    /** close inset URL pop up */
    this.imagePopover.hide();
  }

  /**
   * insert image in the editor
   */
  insertVideo(): void {
    try {
      this._commandExecutorService.insertVideo(this.videoForm.value);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    /** reset form to default */
    this.buildVideoForm();
    /** close inset URL pop up */
    this.videoPopover.hide();
  }

  /**
   * inser text/background color
   */
  insertColor(color: string, where: string): void {
    try {
      this._commandExecutorService.insertColor(color, where);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    this.colorPopover.hide();
  }

  /**
   * set font size
   */
  setFontSize(fontSize: string): void {
    try {
      this._commandExecutorService.setFontSize(fontSize);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    this.fontSizePopover.hide();
  }

  /**
   * set font Name/family
   */
  setFontName(fontName: string): void {
    try {
      this._commandExecutorService.setFontName(fontName);
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }

    this.fontSizePopover.hide();
  }

  /**
   * allow only numbers
   *
   * @param event keypress event
   */
  onlyNumbers(event: KeyboardEvent): boolean {
    return !isNaN(event.key as any);
  }

  /**
   * when user clicks on 'Custom Button'.
   *
   * @param event- text of clicked button.
   */
  triggerCustomButtonClick(btnText: string): void {
    this.triggerCustomClick.emit(btnText);
  }

  /**
   * when 'Image Popover' is being shown.
   */
  onShownImagePopOver(): void {
    this.showPopOver.emit();
  }

  /**
   * when 'Image Popover' is being hidden.
   */
  onHideImagePopOver(): void {
    this.hidePopOver.emit();
  }

  /**
   * when 'Table Popover' is being shown.
   */
  onShownTablePopOver(): void {
    this.showPopOver.emit();
  }

  /**
   * when 'Table Popover' is being hidden.
   */
  onHideTablePopOver(): void {
    this.hidePopOver.emit();
  }

  /**
   * toggles show less/more toolbar icons.
   */
   toggleShowLessOrMore(): void {
    this.showLessOrMore(!this.isMoreShow);
  }

  /**
   * show less/more based on input.
   *
   * @param isMoreShow- if true, show more and false then show less.
   */
  showLessOrMore(isMoreShow: boolean): void {
    this.isMoreShow = isMoreShow;
    if (isMoreShow) {
      this.moreButtonText = this.languageObj.SHOW_LESS;
    } else {
      this.moreButtonText = this.languageObj.SHOW_MORE;
    }
  }

  /**
   * initializes table popover.
   */
  initTablePopover(): void {
    this.tablePopoverData.tablePopoverRowsLength = this.config['table']['popoverRowsLength'];
    this.tablePopoverData.tablePopoverColumnsLength = this.config['table']['popoverColumnsLength'];

    // initialize 'Row Column Box' array.
    for (let rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {

      this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex] = [];
      for (let colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
        this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex] = {
          isHighlight: false
        };
      }

    }
  }

  /**
   * reset table popover data.
   */
  resetTablePopoverData(): void {
    this.tablePopoverData.selectedTablePopoverRowIndex = -1;
    this.tablePopoverData.selectedTablePopoverColumnIndex = -1;

    for (let rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {

      for (let colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
        this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = false;
      }

    }
  }

  /**
   * when user enters mouse on 'Row Column Box' area.
   *
   * @param selectedRowIndex- selected row index of row column box.
   * @param selectedColIndex- selected column index of row column box.
   */
  onMouseEnterRowColumnBox(selectedRowIndex: number, selectedColIndex: number): void {
    this.tablePopoverData.selectedTablePopoverRowIndex = selectedRowIndex;
    this.tablePopoverData.selectedTablePopoverColumnIndex = selectedColIndex;

    for (let rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {

      for (let colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
        let isHighlight = false;
        if (rowIndex <= selectedRowIndex && colIndex <= selectedColIndex) {
          isHighlight = true;
        }
        this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = isHighlight;
      }

    }
  }

  /**
   * when mouse leaves from 'Row Column Box' container.
   */
  onMouseLeaveRowColumnBoxContainer(): void {
    this.resetTablePopoverData();
  }

  /**
   * when user clicks on row column box.
   *
   * @param selectedRowIndex- selected row index of row column box.
   * @param selectedColIndex- selected column index of row column box.
   */
  onClickRowColumnBox(selectedRowIndex: number, selectedColIndex: number): void {
    this.tablePopover.hide();
    this.resetTablePopoverData();
    this.triggerInsertTable.emit({
      totalTableRows: selectedRowIndex + 1,
      totalTableColumns: selectedColIndex + 1
    });
  }

}
