/**
 * toolbar default configuration
 */
export const ngxEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    isMoreShow: true,
    placeholder: 'Enter text here...',
    image: {
        apiDetail: {
            endPoint: 'http://localhost:8080/rest/attachments/uploadImage',
            method: 'POST',
            headers: {
                scope: '1',
                get orgCode() {
                    return 'QMETRY';
                },
                get usertoken() {
                    return 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGZheixMbVhOa256ZGprIiwiYXVkIjoiaHR0cDovL3FtZXRyeXNhYXMucW1ldHJ5LmNvbSIsImNsaWVudElkIjoxLCJpc3MiOiJRTWV0cnkiLCJleHAiOjE2MTk1Mjg4NTcsInVzZXJJZCI6MywiaWF0IjoxNjE5NTI3OTU3LCJqdGkiOiItMTk3NDg5OTcyMyJ9.uKrH5gDFpYLRAtvxeTuGsu9P3JjXDfqBdU7betMW6ac';
                }
            }
        }
    },
    table: {
        popoverRowsLength: 10,
        popoverColumnsLength: 10
    },
    toolbar: [
        ['bold', 'italic', 'underline', 'strikeThrough', 'superscript', 'subscript'],
        ['fontName', 'fontSize', 'color'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
        ['cut', 'copy', 'delete', 'removeFormat', 'undo', 'redo'],
        ['paragraph', 'blockquote', 'removeBlockquote', 'horizontalLine', 'orderedList', 'unorderedList'],
        ['link', 'unlink', 'image', 'video', 'table']
    ]
};
