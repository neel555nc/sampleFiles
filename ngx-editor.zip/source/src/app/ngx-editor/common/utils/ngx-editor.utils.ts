/**
 * enable or disable toolbar based on configuration
 *
 * @param value toolbar item
 * @param toolbar toolbar configuration object
 */
export function canEnableToolbarOptions(value: string, toolbar: any): boolean {

    if (value) {

        if (toolbar['length'] === 0) {
            return true;
        } else {

            const found = toolbar.filter(array => {
                return array.indexOf(value) !== -1;
            });

            return found.length ? true : false;
        }
    } else {
        return false;
    }
}

/**
 * set editor configuration
 *
 * @param value configuration via [config] property
 * @param ngxEditorConfig default editor configuration
 * @param input direct configuration inputs via directives
 */
export function getEditorConfiguration(value: any, ngxEditorConfig: any, input: any): any {

    for (const i in ngxEditorConfig) {
        if (i) {

            if (input[i] !== undefined) {
                value[i] = input[i];
            }

            if (!value.hasOwnProperty(i)) {
                value[i] = ngxEditorConfig[i];
            }
        }
    }

    return value;
}

/**
 * return vertical if the element is the resizer property is set to basic
 *
 * @param resizer type of resizer, either basic or stack
 */
export function canResize(resizer: string): any {
    if (resizer === 'basic') {
        return 'vertical';
    }
    return false;
}

/**
 * save selection when the editor is focussed out
 */
export function saveSelection(): any {
    if (window.getSelection) {
        const sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            return sel.getRangeAt(0);
        }
    } else if (document.getSelection && document.createRange) {
        return document.createRange();
    }
    return null;
}

/**
 * restore selection when the editor is focussed in
 *
 * @param range saved selection when the editor is focussed out
 */
export function restoreSelection(range): boolean {
    if (range) {
        if (window.getSelection) {
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            return true;
        } else if (document.getSelection && range.select) {
            range.select();
            return true;
        }
    } else {
        return false;
    }
}


/**
 * restore toolbar formatting when the user moves the cursor
 *
 * @param selection current selection when the user moves the cursor
 */
export function checkFormatting(selection): any {
    let obj : any = {
        bold : false,
        italic : false,
        underline : false,
        superscript : false,
        subscript : false,
        orderedlist : false,
        unorderedlist : false,
        blockquote : false,
        removeblockquote : false,
        strikethrough : false
      };
    if(selection && selection.focusNode){
        if(selection.focusNode.className == 'ngx-editor-textarea' || (selection.focusNode.parentNode && selection.focusNode.parentNode.className == 'ngx-editor-textarea')){
            return obj;
        }else{
            var node = selection.focusNode.parentNode;
            if(node && node.tagName){
                do{
                    switch(node.tagName.toLowerCase()){
                        case 'b'          : obj.bold = true ; break;
                        case 'i'          : obj.italic = true ; break;
                        case 'u'          : obj.underline = true ; break;
                        case 'strike'     : obj.strikethrough = true ; break;
                        case 'sup'        : obj.superscript = true ; break;
                        case 'sub'        : obj.subscript = true ; break;
                        case 'ol'         : obj.orderedlist = true ; break;
                        case 'ul'         : obj.underline = true ; break;
                        case 'blockquote' : obj.blockquote = true ; break;
                    }
                    if(node && node.parentNode){
                        node = node.parentNode;
                    }
                }while(node.className != 'ngx-editor-textarea');
            }   
            return obj;
        }
    }
}

/**
 * find index of element inside parent.
 *
 * @returns- index number.
 */
export function getIndex(element: HTMLElement): number {
    return Array.from(element.parentElement.children).indexOf(element);
}

/**
 * get closest parent element as per given input selector.
 *
 * @param element- base element.
 * @param selector- css selector to find in parent tree.
 * @returns- html element with match.
 */
export function getClosest(element: any, selector: string): HTMLElement {
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype['matchesSelector'] ||
            Element.prototype['mozMatchesSelector'] ||
            Element.prototype['msMatchesSelector'] ||
            Element.prototype['oMatchesSelector'] ||
            Element.prototype.webkitMatchesSelector ||
            function(s) {
                const matches = (this.document || this.ownerDocument).querySelectorAll(s);
                let index = matches.length;
                while (--index >= 0 && matches.item(index) !== this) {}
                return index > -1;
            };
    }

    // Get the closest matching element
    for (; element && element !== document; element = element.parentNode) {
        if (element.matches( selector )) {
            return element;
        }
    }

    return null;
}

/**
 * get immediate children element list using tag name.
 *
 * @param element- parent element.
 * @param tagName- children element tag name.
 * @returns- get immediate children.
 */
export function getImmediateChildrenUsingTagName(element: HTMLElement, tagName: string): HTMLElement[] {
    let childList: any[] = [];
    childList = Array.from(element.children).filter((childElementItem: HTMLElement) => {
        return childElementItem.tagName.toLowerCase() === tagName.toLowerCase();
    });
    return childList;
}

/**
 * manually trigger 'input' event on given 'contenteditable' element.
 *
 * @param element - reference HTML element.
 */
export function triggerContentEditableInputEvent(element: HTMLElement): void {
    element.dispatchEvent(new Event('input'));
}
