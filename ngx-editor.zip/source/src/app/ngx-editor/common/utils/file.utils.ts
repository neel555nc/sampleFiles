export class FileUtils {
    private _fileName: string;
    private _fileType: string;
    private _fileSize: number;
    private _supportedFileTypes: string[];
    private _maximumFileSize: number;

    constructor(_fileName?: string, _fileType?: string, _fileSize?: number) {
        this._fileName = _fileName;
        this._fileType = _fileType;
        this._fileSize = _fileSize;
    }

    get fileName() {
        return this._fileName;
    }

    set fileName(_fileName: string) {
        this._fileName = _fileName;
    }

    get fileType() {
        return this._fileType;
    }

    set fileType(_fileType: string) {
        this._fileType = _fileType;
    }

    get supportedFileTypes() {
        return this._supportedFileTypes;
    }

    set supportedFileTypes(_supportedFileTypes: string[]) {
        this._supportedFileTypes = _supportedFileTypes;
    }

    get maximumFileSize() {
        return this._maximumFileSize;
    }

    set maximumFileSize(_maximumFileSize: number) {
        this._maximumFileSize = _maximumFileSize;
    }

    isValidFileType(): boolean {
        return this._supportedFileTypes.indexOf(this._fileType) !== -1;
    }

    isValidFileSize(): boolean {
        return this._fileSize <= this._maximumFileSize;
    }
}
