export interface ImageApiDetail {
    endPoint: string;
    method: string;
    headers: object;
}

export interface ImageConfig {
    supportedFileTypes?: string[];
    maximumFileSize?: number;
    apiDetail: ImageApiDetail;
}
