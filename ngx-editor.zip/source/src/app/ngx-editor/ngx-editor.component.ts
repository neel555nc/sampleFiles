import {
  Component, OnInit, Input, Output, ViewChild,
  EventEmitter, Renderer2, forwardRef, OnChanges,
  AfterViewInit, OnDestroy
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { ContextMenu } from 'primeng/primeng';

import { CommandExecutorService } from './common/services/command-executor.service';
import { MessageService } from './common/services/message.service';

import { ngxEditorConfig } from './common/ngx-editor.defaults';
import * as Utils from './common/utils/ngx-editor.utils';
import { NgxEditorToolbarComponent } from './ngx-editor-toolbar/ngx-editor-toolbar.component';

/**
 * es5 does not support dynamic import
 * require is used to get translated files for current language code
 */
 declare var require: any;
@Component({
  selector: 'app-ngx-editor',
  templateUrl: './ngx-editor.component.html',
  styleUrls: ['./ngx-editor.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => NgxEditorComponent),
      multi: true
    }
  ]
})

export class NgxEditorComponent implements OnInit, ControlValueAccessor, OnChanges, AfterViewInit, OnDestroy {

  /** Specifies weather the textarea to be editable or not */
  @Input() editable: boolean;
  /** The spellcheck property specifies whether the element is to have its spelling and grammar checked or not. */
  @Input() spellcheck: boolean;
  /** Placeholder for the textArea */
  @Input() placeholder: string;
  /**
   * The translate property specifies whether the content of an element should be translated or not.
   *
   * Check https://www.w3schools.com/tags/att_global_translate.asp for more information and browser support
   */
  @Input() translate: string;
  /** Sets height of the editor */
  @Input() height: string;
  /** Sets minimum height for the editor */
  @Input() minHeight: string;
  /** Sets Width of the editor */
  @Input() width: string;
  /** Sets minimum width of the editor */
  @Input() minWidth: string;
  /**
   * Toolbar accepts an array which specifies the options to be enabled for the toolbar
   *
   * Check ngxEditorConfig for toolbar configuration
   *
   * Passing an empty array will enable all toolbar
   */
  @Input() toolbar: Object;
  /**
   * The editor can be resized vertically.
   *
   * `basic` resizer enables the html5 reszier. Check here https://www.w3schools.com/cssref/css3_pr_resize.asp
   *
   * `stack` resizer enable a resizer that looks like as if in https://stackoverflow.com
   */
  @Input() resizer = 'stack';
  /**
   * The config property is a JSON object
   *
   * All avaibale inputs inputs can be provided in the configuration as JSON
   * inputs provided directly are considered as top priority
   */
  @Input() config = ngxEditorConfig;
  /** Weather to show or hide toolbar */
  @Input() showToolbar: boolean;
  /** Weather to enable or disable the toolbar */
  @Input() enableToolbar: boolean;
  /** Endpoint for which the image to be uploaded */
  @Input() imageEndPoint: string;
  /** List of custom buttons if any */
  @Input() customButtonsArray: any = [];
  @Input() setFocus = false;
  /**
   * If this flag is 'true', pasted text will be converted to 'plain' 
   * and no styles will be imported from copied text.
   */
  @Input() pasteAsPlainText = false;
  @Input() languageCode = 'en';

  /** emits `blur` event when focused out from the textarea */
  @Output() blur: EventEmitter<string> = new EventEmitter<string>();
  /** emits `focus` event when focused in to the textarea */
  @Output() focus: EventEmitter<string> = new EventEmitter<string>();
 /** emits `triggerCustomClick` event when custombutton is clicked -> returns btntext to identify which button clicked */
  @Output() triggerCustomClick: EventEmitter<any> = new EventEmitter<any>();
  @Output() change: EventEmitter<any> = new EventEmitter();
  @Output() optionClicked: EventEmitter<any> = new EventEmitter<any>();
  /** emits message to parent component. */
  @Output() triggerMessage: EventEmitter<string> = new EventEmitter<string>();
  /** when popover is show/hide. */
  @Output() showPopOver: EventEmitter<any> = new EventEmitter<any>();
  @Output() hidePopOver: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('ngxTextArea') textArea: any;
  @ViewChild('ngxWrapper') ngxWrapper: any;
  @ViewChild('ngxToolbar') ngxToolbar: NgxEditorToolbarComponent;

  Utils: any = Utils;
  private onChange: (value: string) => void;
  private onTouched: () => void;
  private pasteEventListener: any;
  IS_IE: boolean = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
  /** saves the selection from the editor when focussed out */
  savedSelection: any = undefined;
  languageObj: any = {};
  /** 'ngx-editor-table-container' class is used to bind event. */
  TABLE_CONTAINER_CLASS = 'ngx-editor-table-container';
  /**
   * table html template.
   * template change will impact 'CSS Selector' used in code.
   */
  TABLE_TEMPLATES: any = {
    COLUMN: `<td></td>`,
    ROW: `<tr>{tableRowCellsHtml}</tr>`,
    TABLE:
    `<div id="{tableContainerId}" class="${this.TABLE_CONTAINER_CLASS}">
      <table>
        <tbody>{tableRowsHtml}</tbody>
      </table>
    </div>`
  };
  @ViewChild('tableCellContextMenu') tableCellContextMenu: ContextMenu;
  tableCellContextMenuData: any = {
    items: [],
    style: {
      left: 0,
      top: 0
    },
    rowIndex: -1,
    columnIndex: -1,
    tableContainerId: ''
  };

  /**
   * @param _messageService service to send message to the editor message component
   * @param _commandExecutor executes command from the toolbar
   * @param _renderer access and manipulate the dom element
   */
  constructor(
    private _messageService: MessageService,
    private _commandExecutor: CommandExecutorService,
    private _renderer: Renderer2) { }

  ngOnInit() {
    this.languageObj = require('../i18n/' + this.languageCode + '.json');

    /**
     * set configuartion
     */
    this.config = this.Utils.getEditorConfiguration(this.config, ngxEditorConfig, this.getCollectiveParams());

    this.height = this.height || this.textArea.nativeElement.offsetHeight;

    this.executeCommand('enableObjectResizing', false);

    this._messageService.getMessage().subscribe((message: string) => {
      this.triggerMessage.emit(message);
    });

    /** initialize table cell context menu items. */
    this.initializeNgxEditorTable();
  }

  ngOnChanges(changes) {
    if (changes && changes.setFocus && changes.setFocus.currentValue) {
      this.textArea.nativeElement.focus();
    }
  }

  ngAfterViewInit() {
    if (this.pasteAsPlainText) {
      this.pasteEventListener =
        this._renderer.listen(this.textArea.nativeElement, 'paste', this.executePasteAsPlainText.bind(this));
    }
  }

  ngOnDestroy() {
    if (this.pasteEventListener) {
      this.pasteEventListener();
    }
  }

  /**
   * this method will be called after editor value is being written via 'ngModel'.
   */
  afterWriteNgxEditorValue(): void {
    this.bindNgxEditorTableContextMenuEvent();
  }

  /**
   * events
   */
  onTextAreaFocus(): void {
    this.focus.emit('focus');
  }

  /** focus the text area when the editor is focussed */
  onEditorFocus() {
    this.textArea.nativeElement.focus();
  }

  /**
   * Executed from the contenteditable section while the input property changes
   * @param html html string from contenteditable
   */
  onContentChange(html: string): void {
    if (typeof this.onChange === 'function') {
      this.onChange(html);
      this.togglePlaceholder(html);
    }
    this.change.emit(html);
  }

  onTextAreaBlur(event): void {
    /** save selection if focussed out */
    this.saveSelection(Utils.saveSelection());

    if (typeof this.onTouched === 'function') {
      this.onTouched();
    }
    this.blur.emit(event);
  }

  onSelectionChange(): void {
    /** save selection if focussed out */
    this.saveSelection(Utils.saveSelection());
    this.ngxToolbar.activeButtonArray = Utils.checkFormatting(window.getSelection());
  }

  /**
   * resizing text area
   *
   * @param offsetY vertical height of the eidtable portion of the editor
   */
  resizeTextArea(offsetY: number): void {
    let newHeight = parseInt(this.height, 10);
    newHeight += offsetY;
    this.height = newHeight + 'px';
    this.textArea.nativeElement.style.height = this.height;
  }

  /**
   * editor actions, i.e., executes command from toolbar
   *
   * @param commandName name of the command to be executed
   */
  executeCommand(commandName: string, emit = true): void {
    try {
      this._commandExecutor.execute(commandName);
      if (emit) {
        this.optionClicked.emit();
      }
    } catch (error) {
      this._messageService.sendMessage(error.message);
    }
  }

  /**
   * Write a new value to the element.
   *
   * @param value value to be executed when there is a change in contenteditable
   */
  writeValue(value: any): void {
    this.togglePlaceholder(value);

    if (value === null || value === undefined || value === '' || value === '<br>') {
      value = null;
    }

    this.refreshView(value);
    this.afterWriteNgxEditorValue();
  }

  /**
   * Set the function to be called
   * when the control receives a change event.
   *
   * @param fn a function
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Set the function to be called
   * when the control receives a touch event.
   *
   * @param fn a function
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * refresh view/HTML of the editor
   *
   * @param value html string from the editor
   */
  refreshView(value: string): void {
    const normalizedValue = value === null ? '' : value;
    this._renderer.setProperty(this.textArea.nativeElement, 'innerHTML', normalizedValue);
  }

  /**
   * toggles placeholder based on input string
   *
   * @param value A HTML string from the editor
   */
  togglePlaceholder(value: any): void {
    if (!value || value === '<br>' || value === '') {
      this._renderer.addClass(this.ngxWrapper.nativeElement, 'show-placeholder');
    } else {
      this._renderer.removeClass(this.ngxWrapper.nativeElement, 'show-placeholder');
    }
  }

  /**
   * returns a json containing input params
   */
  getCollectiveParams(): any {
    return {
      editable: this.editable,
      spellcheck: this.spellcheck,
      placeholder: this.placeholder,
      translate: this.translate,
      height: this.height,
      minHeight: this.minHeight,
      width: this.width,
      minWidth: this.minWidth,
      enableToolbar: this.enableToolbar,
      showToolbar: this.showToolbar,
      imageEndPoint: this.imageEndPoint,
      toolbar: this.toolbar
    };
  }

  /**
   * when user clicks on 'Custom Button'.
   *
   * @param event- text of clicked button.
   */
  onTriggerCustomClick(btnText: string): void {
    this.triggerCustomClick.emit(btnText);
  }

  /**
   * focuses on editable area of editor.
   */
  focusTextArea(): void {
    setTimeout(() => {
      this.textArea.nativeElement.focus();
    }, 0);
  }

  /**
   * executed when user paste content inside editor.
   *
   * @param event- paste event object.
   */
  executePasteAsPlainText(event: any): void {
    // prevent default paste event
    event.preventDefault();

    let plainText = '';
    if (this.IS_IE) {
      if (window['clipboardData'] && window.getSelection) {
        plainText = window['clipboardData'].getData('Text').replace(/(?:\r\n|\r|\n)/g, '<br>');
        const element: HTMLElement = document.createElement('span');
        element.innerHTML = plainText;
        const selectedRange: Range = window.getSelection().getRangeAt(0);
        selectedRange.deleteContents();
        selectedRange.insertNode(element);
      }
    } else {
      const clipboardData: DataTransfer = (event.originalEvent || event).clipboardData;
      const htmlContent: string = clipboardData.getData('text/html').trim();

      // iterate images from pasted html content
      let imageListHtml = '';
      const divElement: HTMLElement = document.createElement('div');
      divElement.innerHTML = htmlContent;
      const imageCollection = divElement.getElementsByTagName('img');
      for (let index = 0, length = imageCollection.length; index < length; index++) {
        const imageElement: HTMLImageElement = imageCollection[index];
        imageListHtml += '<img alt="' + imageElement.alt + '" src="' + imageElement.src + '">' + '&nbsp;<br>';
      }

      // iterate images from pasting image (ex. snipping tool)
      // if image isn't available inside 'htmlContent'
      if (htmlContent === '') {
        const itemList: DataTransferItemList = clipboardData.items;
        for (let index = 0, length = itemList.length; index < length; index++) {
          const item: DataTransferItem = itemList[index];

          if (item.kind === 'file') {
            const file: File = item.getAsFile();
            const reader: FileReader = new FileReader();
            reader.onload = ($event: any) => {
              const imageHtml: string = '<img src="' + $event.target.result + '">' + '&nbsp;<br>';
              document.execCommand('insertHTML', false, imageHtml);
            };
            reader.readAsDataURL(file);
          }
        }
      }

      plainText = (event.originalEvent || event).clipboardData.getData('text/plain');
      plainText = plainText.replace(/(?:\r\n|\r|\n)/g, '<br>');

      // insert text manually.
      document.execCommand('insertHTML', false, imageListHtml + plainText);
    }
  }

  /**
   * inserts image inside editor on last saved selection.
   *
   * @param imageURI - URL of image.
   */
  insertImage(imageURI: string): void {
    if (!this.savedSelection) {
      this.saveSelection(this.getEditorElementRange());
    }
    this._commandExecutor.insertImage(imageURI);
  }

  /**
   * when 'Popover' is being shown.
   */
  onShowPopOver(): void {
    this.showPopOver.emit();
  }

  /**
   * when 'Popover' is being hidden.
   */
  onHidePopOver(): void {
    this.hidePopOver.emit();
  }

  /**
   * inserts html inside editor on last saved selection.
   *
   * @param html - html content to be inserted.
   */
  insertHtml(html: string): void {
    if (!this.savedSelection) {
      this.saveSelection(this.getEditorElementRange());
    }
    this._commandExecutor.restoreSelectionAndInsertHtml(html, this.textArea.nativeElement);
  }

  /**
   * inserts table inside editor.
   *
   * @param tableData - ex. {totalTableRows: 5, totalTableColumns: 5}
   */
  insertTable(tableData: any): void {
    const generateTableResponse: any =
      this.generateTableHtml(tableData.totalTableRows, tableData.totalTableColumns);
    this.insertHtml(
      generateTableResponse.templateHtml.replace(/\n/g, '')
    );
    this.focusElementInsideEditor(
      this._tblSelector(generateTableResponse.tableContainerId)
      + ' > tbody > tr:first-child > td:first-child'
    );
    this.bindNgxEditorTableContextMenuEvent(generateTableResponse.tableContainerId);
  }

  /**
   * initialized editor tables such as context menu items, events etc.
   */
  initializeNgxEditorTable(): void {
    this.tableCellContextMenuData.items = [
      {
        label: this.languageObj.INSERT,
        items: [
          {
            label: this.languageObj.INSERT_ABOVE,
            command: this.onInsertTableRowAbove.bind(this)
          }, {
            label: this.languageObj.INSERT_BELOW,
            command: this.onInsertTableRowBelow.bind(this)
          }, {
            label: this.languageObj.INSERT_LEFT,
            command: this.onInsertTableColumnBefore.bind(this)
          }, {
            label: this.languageObj.INSERT_RIGHT,
            command: this.onInsertTableColumnAfter.bind(this)
          }
        ]
      }, {
        label: this.languageObj.DELETE,
        items: [
          {
            label: this.languageObj.DELETE_ROW,
            command: this.onDeleteTableRow.bind(this)
          }, {
            label: this.languageObj.DELETE_COLUMN,
            command: this.onDeleteTableColumn.bind(this)
          }, {
            label: this.languageObj.DELETE_TABLE,
            command: this.onDeleteTable.bind(this)
          }
        ]
      }
    ];
  }

  /**
   * binds table cell context menu event.
   *
   * @param tableContainerId- id of table container.
   */
  bindNgxEditorTableContextMenuEvent(tableContainerId?: string): void {
    Array.from(this.textArea.nativeElement.querySelectorAll(
        this._tblSelector(tableContainerId)
        + ' > tbody > tr > td'
      )
    ).forEach((tableCellElement: HTMLElement) => {
        tableCellElement.addEventListener(
          'contextmenu',
          this.onContextMenuTableCell.bind(this)
        );
      });
  }

  /**
   * binds table row cells context menu event.
   *
   * @param tableContainerId- id of table container.
   * @param rowNumber- row number of table.
   */
   bindNgxEditorTableRowContextMenuEvent(tableContainerId: string, rowNumber: number): void {
    Array.from(
        this.textArea.nativeElement.querySelectorAll(
          this._tblSelector(tableContainerId)
          + ' > tbody > tr:nth-child(' + rowNumber + ') > td'
        )
      )
      .forEach((tableCellElement: HTMLElement) => {
        tableCellElement.addEventListener(
          'contextmenu',
          this.onContextMenuTableCell.bind(this)
        );
      });
  }

  /**
   * binds table column cells context menu event.
   *
   * @param tableContainerId- id of table container.
   * @param columnNumber- column number of table.
   */
   bindNgxEditorTableColumnContextMenuEvent(tableContainerId: string, columnNumber: number): void {
    Array.from(
        this.textArea.nativeElement.querySelectorAll(
          this._tblSelector(tableContainerId)
          + ' > tbody > tr > td:nth-child(' + columnNumber + ')'
        )
      )
      .forEach((tableCellElement: HTMLElement) => {
        tableCellElement.addEventListener(
          'contextmenu',
          this.onContextMenuTableCell.bind(this)
        );
      });
  }

  /**
   * when context menu event of table cell executes.
   *
   * @returns boolean- prevent default context menu event.
   */
  onContextMenuTableCell(event: any): boolean {
    // prevent default event
    event.preventDefault();
    event.stopPropagation();

    this.tableCellContextMenuData.style.left = event.pageX;
    this.tableCellContextMenuData.style.top = event.pageY;

    const tableCellElement: HTMLElement = event.currentTarget;
    const tableContainerElement: HTMLElement = Utils.getClosest(tableCellElement, '.' + this.TABLE_CONTAINER_CLASS);
    this.tableCellContextMenuData.columnIndex = Utils.getIndex(tableCellElement);
    this.tableCellContextMenuData.rowIndex = Utils.getIndex(tableCellElement.parentElement);
    this.tableCellContextMenuData.tableContainerId = tableContainerElement.id;

    this.tableCellContextMenu.show();
    return false;
  }

  /**
   * when table row inserted above selected row.
   *
   * @param event - event object
   */
  onInsertTableRowAbove(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const rowNumber: number = this.tableCellContextMenuData.rowIndex + 1;
    this.insertTableRow(tableContainerId, rowNumber);
    this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
  }

  /**
   * when table row inserted below selected row.
   *
   * @param event - event object
   */
   onInsertTableRowBelow(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const rowNumber: number = this.tableCellContextMenuData.rowIndex + 2;
    this.insertTableRow(tableContainerId, rowNumber);
    this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
  }

  /**
   * when table column inserted before selected column.
   *
   * @param event- event object
   */
  onInsertTableColumnBefore(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const columnNumber: number = this.tableCellContextMenuData.columnIndex + 1;
    this.insertTableColumn(tableContainerId, columnNumber);
    this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
  }

  /**
   * when table column inserted after selected column.
   *
   * @param event- event object
   */
  onInsertTableColumnAfter(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const columnNumber: number = this.tableCellContextMenuData.columnIndex + 2;
    this.insertTableColumn(tableContainerId, columnNumber);
    this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
  }

  /**
   * delete table row.
   *
   * @param event- event object
   */
  onDeleteTableRow(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const rowNumber: number = this.tableCellContextMenuData.rowIndex + 1;
    this.deleteTableRow(tableContainerId, rowNumber);
  }

  /**
   * delete table column.
   *
   * @param event- event object
   */
   onDeleteTableColumn(event: any): void {
    const tableContainerId: string = this.tableCellContextMenuData.tableContainerId;
    const columnNumber: number = this.tableCellContextMenuData.columnIndex + 1;
    this.deleteTableColumn(tableContainerId, columnNumber);
  }

  /**
   * delete table and related elements.
   *
   * @param event- event object
   */
  onDeleteTable(event: any): void {
    // removing table inside container and related attributes.
    const tableContainerElement: HTMLElement =
      this.textArea.nativeElement.querySelector(
        '#' + this.tableCellContextMenuData.tableContainerId
      );
    tableContainerElement.querySelector('table').remove();

    if (tableContainerElement.innerHTML.trim() === '') {
      tableContainerElement.remove();
    } else {
      tableContainerElement.removeAttribute('id');
      tableContainerElement.removeAttribute('class');
    }
    Utils.triggerContentEditableInputEvent(this.textArea.nativeElement);
  }

  /**
   * save selection.
   */
  private saveSelection(savedSelection: any): void {
    this.savedSelection = savedSelection;
    this._commandExecutor.savedSelection = savedSelection;
  }

  /**
   * focus on element inside editor.
   *
   * @param elementCssSelector- css selector of element.
   * @returns boolean- whether element focused or not successfully.
   */
  private focusElementInsideEditor(elementCssSelector?: string): boolean {
    const range: Range = this.getEditorElementRange(elementCssSelector);
    this.saveSelection(range);
    return Utils.restoreSelection(range);
  }

  /**
   * get range object of element inside editor.
   *
   * @param elementCssSelector- css selector of element.
   * @returns Range- range object of element.
   */
  private getEditorElementRange(elementCssSelector?: string): Range {
    const element: HTMLElement = elementCssSelector ?
      this.textArea.nativeElement.querySelector(elementCssSelector) : this.textArea.nativeElement;
    const range: Range = document.createRange();
    range.setStart(element, element.childNodes.length);
    return range;
  }

  /**
   * generate table html from total rows and columns.
   *
   * @param totalTableRows- total table rows.
   * @param totalTableColumns- total table columns.
   */
  private generateTableHtml(totalTableRows: number, totalTableColumns: number): any {
    const tableContainerId: string = 'table-container-' + Date.now().toString();
    let templateHtml = '', tableRowsHtml = '';
    for (let rowIndex = 0; rowIndex < totalTableRows; rowIndex++) {
      tableRowsHtml += this.TABLE_TEMPLATES.ROW.replace('{tableRowCellsHtml}',
        this.generateTableRowHtml(totalTableColumns));
    }
    templateHtml = this.TABLE_TEMPLATES.TABLE.replace('{tableRowsHtml}', tableRowsHtml)
      .replace(/{tableContainerId}/g, tableContainerId);

    return {
      templateHtml: templateHtml,
      tableContainerId: tableContainerId
    };
  }

  /**
   * generates html of table row for given number of cells.
   *
   * @param totalCells - total cell in given row.
   * @returns- returns html string.
   */
  private generateTableRowHtml(totalCells: number): string {
    let tableRowHtml = '';
    for (let index = 0; index < totalCells; index++) {
      tableRowHtml += this.TABLE_TEMPLATES.COLUMN;
    }
    return tableRowHtml;
  }

  /**
   * inserts row at specified position inside table.
   *
   * @param tableContainerId - id of table container.
   * @param position - insert row position.
   */
  private insertTableRow(tableContainerId: string, position: number): void {
    let tableRow: HTMLElement = this.textArea.nativeElement.querySelector(
      this._tblSelector(tableContainerId)
      + ' > tbody > tr:nth-child(' + position + ')'
    ); // select table row and insert above that row.
    let whereToInsert: InsertPosition = 'beforebegin'; // default insert above selected table row element.

    /**
     * if table row doesn't exist ex. insert last row,
     * select last row and insert new row after that.
     */
    if (!tableRow) {
      tableRow = this.textArea.nativeElement.querySelector(
        this._tblSelector(tableContainerId)
        + ' > tbody > tr:nth-child(' + (position - 1) + ')'
      );
      whereToInsert = 'afterend';
    }
    const totalColumn: number = Utils.getImmediateChildrenUsingTagName(
      tableRow, 'td'
    ).length;

    tableRow.insertAdjacentHTML(whereToInsert, this.generateTableRowHtml(totalColumn).replace(/\n/g, ''));
    Utils.triggerContentEditableInputEvent(this.textArea.nativeElement);
  }

  /**
   * inserts column at specified position inside table.
   *
   * @param tableContainerId - id of table container.
   * @param position - insert column position.
   */
  private insertTableColumn(tableContainerId: string, position: number): void {
    let tableColumnCellList: HTMLElement[] = this.textArea.nativeElement.querySelectorAll(
      this._tblSelector(tableContainerId)
      + ' > tbody > tr > td:nth-child(' + position + ')'
    ); // select table column and insert before that column.
    let whereToInsert: InsertPosition = 'beforebegin'; // default insert before selected table column element.

    /**
     * if table column doesn't exist ex. insert last column,
     * select last column and insert new column after that.
     */
     if (tableColumnCellList.length === 0) {
      tableColumnCellList = this.textArea.nativeElement.querySelectorAll(
        this._tblSelector(tableContainerId)
        + ' > tbody > tr > td:nth-child(' + (position - 1) + ')'
      );
      whereToInsert = 'afterend';
    }

    // loop table column cells and insert cells before respective cell.
    tableColumnCellList.forEach((tableColumnCell: HTMLElement) => {
      tableColumnCell.insertAdjacentHTML(whereToInsert, this.TABLE_TEMPLATES.COLUMN.replace(/\n/g, ''));
    });
    Utils.triggerContentEditableInputEvent(this.textArea.nativeElement);
  }

  /**
   * delete table row.
   *
   * @param tableContainerId- id of table container.
   * @param position- delete row position.
   */
  private deleteTableRow(tableContainerId: string, position: number): void {
    const tableRow: HTMLElement = this.textArea.nativeElement.querySelector(
      this._tblSelector(tableContainerId)
       + ' > tbody > tr:nth-child(' + position + ')'
    );
    tableRow.remove();
    Utils.triggerContentEditableInputEvent(this.textArea.nativeElement);
  }

  /**
   * delete table column.
   *
   * @param tableContainerId- id of table container.
   * @param position- delete column position.
   */
   private deleteTableColumn(tableContainerId: string, position: number): void {
    const tableColumnCellList: HTMLElement[] = this.textArea.nativeElement.querySelectorAll(
      this._tblSelector(tableContainerId)
      + ' > tbody > tr > td:nth-child(' + position + ')'
    );

    // loop table column cells and remove.
    tableColumnCellList.forEach((tableColumnCell: HTMLElement) => {
      tableColumnCell.remove();
    });
    Utils.triggerContentEditableInputEvent(this.textArea.nativeElement);
  }

  /**
   * get table selector.
   *
   * @param tableContainerId- id of table container.
   * @returns- CSS selector of table.
   */
  private _tblSelector(tableContainerId?: string): string {
    return 'div.' + this.TABLE_CONTAINER_CLASS
      + (tableContainerId ? '#' + tableContainerId : '')
      + ' > table';
  }

}
