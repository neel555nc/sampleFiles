import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PopoverModule } from 'ngx-bootstrap';
import { ContextMenuModule } from 'primeng/primeng';
import { NgxEditorComponent } from './ngx-editor.component';
import { NgxEditorToolbarComponent } from './ngx-editor-toolbar/ngx-editor-toolbar.component';
import { MessageService } from './common/services/message.service';
import { CommandExecutorService } from './common/services/command-executor.service';

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, PopoverModule.forRoot(), ContextMenuModule],
  declarations: [NgxEditorComponent, NgxEditorToolbarComponent],
  exports: [NgxEditorComponent, PopoverModule],
  providers: [CommandExecutorService, MessageService]
})

export class NgxEditorModule { }
