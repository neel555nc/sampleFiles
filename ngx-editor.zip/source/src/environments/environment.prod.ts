/** environment variables for production */
export const environment = {
  production: true
};
