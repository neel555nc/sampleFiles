#!/bin/bash

# remove existing builds
rm -rf build/
rm -rf dist/

# build
node_modules/.bin/ng-packagr -p ng-package.json

# delete unwanted folders
rm -rf .ng_build
rm -rf .ng_pkg_build

#Copy Build data to root level
cp -R build/. ../

# copy i18n folder to root level
cp -R src/app/i18n/ ../

# copy styles.scss file to root scss folder
cp src/styles.scss ../bundles