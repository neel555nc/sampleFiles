#!/bin/bash

# publish to npm
npm publish build/
