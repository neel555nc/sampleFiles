import { Injectable, Component, Input, Output, EventEmitter, ViewChild, Renderer2, forwardRef, NgModule } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { FormBuilder, Validators, NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PopoverConfig, PopoverModule } from 'ngx-bootstrap';
import { ContextMenuModule } from 'primeng/primeng';
import { CommonModule } from '@angular/common';

function canEnableToolbarOptions(value, toolbar) {
    if (value) {
        if (toolbar['length'] === 0) {
            return true;
        }
        else {
            const                  found = toolbar.filter(array => {
                return array.indexOf(value) !== -1;
            });
            return found.length ? true : false;
        }
    }
    else {
        return false;
    }
}
function getEditorConfiguration(value, ngxEditorConfig, input) {
    for (const                  i in ngxEditorConfig) {
        if (i) {
            if (input[i] !== undefined) {
                value[i] = input[i];
            }
            if (!value.hasOwnProperty(i)) {
                value[i] = ngxEditorConfig[i];
            }
        }
    }
    return value;
}
function canResize(resizer) {
    if (resizer === 'basic') {
        return 'vertical';
    }
    return false;
}
function saveSelection() {
    if (window.getSelection) {
        const                  sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            return sel.getRangeAt(0);
        }
    }
    else if (document.getSelection && document.createRange) {
        return document.createRange();
    }
    return null;
}
function restoreSelection(range) {
    if (range) {
        if (window.getSelection) {
            const                  sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            return true;
        }
        else if (document.getSelection && range.select) {
            range.select();
            return true;
        }
    }
    else {
        return false;
    }
}
function checkFormatting(selection) {
    let                  obj = {
        bold: false,
        italic: false,
        underline: false,
        superscript: false,
        subscript: false,
        orderedlist: false,
        unorderedlist: false,
        blockquote: false,
        removeblockquote: false,
        strikethrough: false
    };
    if (selection && selection.focusNode) {
        if (selection.focusNode.className == 'ngx-editor-textarea' || (selection.focusNode.parentNode && selection.focusNode.parentNode.className == 'ngx-editor-textarea')) {
            return obj;
        }
        else {
            var                  node = selection.focusNode.parentNode;
            if (node && node.tagName) {
                do {
                    switch (node.tagName.toLowerCase()) {
                        case 'b':
                            obj.bold = true;
                            break;
                        case 'i':
                            obj.italic = true;
                            break;
                        case 'u':
                            obj.underline = true;
                            break;
                        case 'strike':
                            obj.strikethrough = true;
                            break;
                        case 'sup':
                            obj.superscript = true;
                            break;
                        case 'sub':
                            obj.subscript = true;
                            break;
                        case 'ol':
                            obj.orderedlist = true;
                            break;
                        case 'ul':
                            obj.underline = true;
                            break;
                        case 'blockquote':
                            obj.blockquote = true;
                            break;
                    }
                    if (node && node.parentNode) {
                        node = node.parentNode;
                    }
                } while (node.className != 'ngx-editor-textarea');
            }
            return obj;
        }
    }
}
function getIndex(element) {
    return Array.from(element.parentElement.children).indexOf(element);
}
function getClosest(element, selector) {
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype['matchesSelector'] ||
                Element.prototype['mozMatchesSelector'] ||
                Element.prototype['msMatchesSelector'] ||
                Element.prototype['oMatchesSelector'] ||
                Element.prototype.webkitMatchesSelector ||
                function (s) {
                    const                  matches = (this.document || this.ownerDocument).querySelectorAll(s);
                    let                  index = matches.length;
                    while (--index >= 0 && matches.item(index) !== this) { }
                    return index > -1;
                };
    }
    for (; element && element !== document; element = element.parentNode) {
        if (element.matches(selector)) {
            return element;
        }
    }
    return null;
}
function getImmediateChildrenUsingTagName(element, tagName) {
    let                  childList = [];
    childList = Array.from(element.children).filter((childElementItem) => {
        return childElementItem.tagName.toLowerCase() === tagName.toLowerCase();
    });
    return childList;
}
function triggerContentEditableInputEvent(element) {
    element.dispatchEvent(new Event('input'));
}


var Utils = Object.freeze({
	canEnableToolbarOptions: canEnableToolbarOptions,
	getEditorConfiguration: getEditorConfiguration,
	canResize: canResize,
	saveSelection: saveSelection,
	restoreSelection: restoreSelection,
	checkFormatting: checkFormatting,
	getIndex: getIndex,
	getClosest: getClosest,
	getImmediateChildrenUsingTagName: getImmediateChildrenUsingTagName,
	triggerContentEditableInputEvent: triggerContentEditableInputEvent
});

class CommandExecutorService {
    constructor(_http) {
        this._http = _http;
        this.savedSelection = undefined;
    }
    execute(command) {
        if (!this.savedSelection && command !== 'enableObjectResizing') {
            throw new Error('Range out of Editor');
        }
        if (command === 'enableObjectResizing') {
            document.execCommand('enableObjectResizing', true, 'true');
            return;
        }
        if (command === 'blockquote') {
            document.execCommand('formatBlock', false, 'blockquote');
            return;
        }
        if (command === 'removeBlockquote') {
            document.execCommand('outdent', false, undefined);
            return;
        }
        document.execCommand(command, false, null);
        return;
    }
    insertImage(imageURI) {
        if (imageURI) {
            const                  restored = restoreSelection(this.savedSelection);
            if (restored) {
                const                  inserted = document.execCommand('insertImage', false, imageURI);
                if (!inserted) {
                    throw new Error('Invalid URL');
                }
            }
        }
    }
    insertVideo(videParams) {
        if (this.savedSelection) {
            if (videParams) {
                const                  restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isYoutubeLink(videParams.videoUrl)) {
                        const                  youtubeURL = '<iframe width="' + videParams.width + '" height="' + videParams.height + '"'
                            + 'src="' + videParams.videoUrl + '"></iframe>';
                        this.insertHtml(youtubeURL);
                    }
                    else if (this.checkTagSupportInBrowser('video')) {
                        if (this.isValidURL(videParams.videoUrl)) {
                            const                  videoSrc = '<video width="' + videParams.width + '" height="' + videParams.height + '"'
                                + ' controls="true"><source src="' + videParams.videoUrl + '"></video>';
                            this.insertHtml(videoSrc);
                        }
                        else {
                            throw new Error('Invalid video URL');
                        }
                    }
                    else {
                        throw new Error('Unable to insert video');
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    }
    isYoutubeLink(url) {
        const                  ytRegExp = /^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+/;
        return ytRegExp.test(url);
    }
    isValidURL(url) {
        const                  urlRegExp = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
        return urlRegExp.test(url);
    }
    uploadImage(file, imageApiDetail) {
        const                  endPoint = imageApiDetail.endPoint;
        if (!endPoint) {
            throw new Error('Image Api Endpoint isn`t provided or invalid');
        }
        const                  formData = new FormData();
        if (file) {
            const                  method = imageApiDetail.method || 'POST';
            const                  headers = imageApiDetail.headers;
            if (!headers || Object.keys(headers).length === 0) {
                throw new Error('Image Api Headers aren`t provided');
            }
            formData.append('file', file);
            const                  req = new HttpRequest(method, endPoint, formData, {
                reportProgress: true,
                headers: new HttpHeaders(headers)
            });
            return this._http.request(req);
        }
        else {
            throw new Error('Invalid Image');
        }
    }
    createLink(params) {
        if (this.savedSelection) {
            if (params.urlNewTab) {
                const                  newUrl = '<a href="' + params.urlLink + '" target="_blank">' + params.urlText + '</a>';
                if (document.getSelection().type !== 'Range') {
                    const                  restored = restoreSelection(this.savedSelection);
                    if (restored) {
                        this.insertHtml(newUrl);
                    }
                }
                else {
                    throw new Error('Only new links can be inserted. You cannot edit URL`s');
                }
            }
            else {
                const                  newUrl = '<a href="' + params.urlLink + '">' + params.urlText + '</a>';
                const                  restored = restoreSelection(this.savedSelection);
                if (restored) {
                    this.insertHtml(newUrl);
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    }
    insertColor(color, where) {
        if (this.savedSelection) {
            const                  restored = restoreSelection(this.savedSelection);
            if (restored && this.checkSelection()) {
                if (where === 'textColor') {
                    document.execCommand('foreColor', false, color);
                }
                else {
                    document.execCommand('hiliteColor', false, color);
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    }
    setFontSize(fontSize) {
        if (this.savedSelection && this.checkSelection()) {
            const                  deletedValue = this.deleteAndGetElement();
            if (deletedValue) {
                const                  restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isNumeric(fontSize)) {
                        const                  fontPx = '<span style="font-size: ' + fontSize + 'px;">' + deletedValue + '</span>';
                        this.insertHtml(fontPx);
                    }
                    else {
                        const                  fontPx = '<span style="font-size: ' + fontSize + ';">' + deletedValue + '</span>';
                        this.insertHtml(fontPx);
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    }
    setFontName(fontName) {
        if (this.savedSelection && this.checkSelection()) {
            const                  deletedValue = this.deleteAndGetElement();
            if (deletedValue) {
                const                  restored = restoreSelection(this.savedSelection);
                if (restored) {
                    if (this.isNumeric(fontName)) {
                        const                  fontFamily = '<span style="font-family: ' + fontName + 'px;">' + deletedValue + '</span>';
                        this.insertHtml(fontFamily);
                    }
                    else {
                        const                  fontFamily = '<span style="font-family: ' + fontName + ';">' + deletedValue + '</span>';
                        this.insertHtml(fontFamily);
                    }
                }
            }
        }
        else {
            throw new Error('Range out of the editor');
        }
    }
    insertHtml(html, rootElement) {
        const                  isHTMLInserted = document.execCommand('insertHTML', false, html);
        if (!isHTMLInserted) {
            throw new Error('Unable to perform the operation');
        }
        const                  styles = html.match(/<style(.*)>(.|\n)+<\/style>/ig);
        if (styles && styles.length) {
            styles.forEach((style) => {
                rootElement.insertAdjacentHTML('beforeend', style);
            });
        }
    }
    restoreSelectionAndInsertHtml(html, rootElement) {
        const                  restored = restoreSelection(this.savedSelection);
        if (restored) {
            this.insertHtml(html, rootElement);
        }
    }
    isNumeric(value) {
        return /^-{0,1}\d+$/.test(value);
    }
    deleteAndGetElement() {
        let                  selectedText;
        if (this.savedSelection) {
            selectedText = this.savedSelection.toString();
            this.savedSelection.deleteContents();
            return selectedText;
        }
        return false;
    }
    checkSelection() {
        const                  slectedText = this.savedSelection.toString();
        if (slectedText.length === 0) {
            throw new Error('No Selection Made');
        }
        return true;
    }
    checkTagSupportInBrowser(tag) {
        return !(document.createElement(tag) instanceof HTMLUnknownElement);
    }
}
CommandExecutorService.decorators = [
    { type: Injectable },
];
CommandExecutorService.ctorParameters = () => [
    { type: HttpClient, },
];

const DURATION = 7000;
class MessageService {
    constructor() {
        this.message = new Subject();
    }
    getMessage() {
        return this.message.asObservable();
    }
    sendMessage(message) {
        this.message.next(message);
        this.clearMessageIn(DURATION);
        return;
    }
    clearMessageIn(milliseconds) {
        setTimeout(() => {
            this.message.next(undefined);
        }, milliseconds);
        return;
    }
}
MessageService.decorators = [
    { type: Injectable },
];
MessageService.ctorParameters = () => [];

const ngxEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    isMoreShow: true,
    placeholder: 'Enter text here...',
    image: {
        apiDetail: {
            endPoint: 'http://localhost:8080/rest/attachments/uploadImage',
            method: 'POST',
            headers: {
                scope: '1',
                get orgCode() {
                    return 'QMETRY';
                },
                get usertoken() {
                    return 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGZheixMbVhOa256ZGprIiwiYXVkIjoiaHR0cDovL3FtZXRyeXNhYXMucW1ldHJ5LmNvbSIsImNsaWVudElkIjoxLCJpc3MiOiJRTWV0cnkiLCJleHAiOjE2MTk1Mjg4NTcsInVzZXJJZCI6MywiaWF0IjoxNjE5NTI3OTU3LCJqdGkiOiItMTk3NDg5OTcyMyJ9.uKrH5gDFpYLRAtvxeTuGsu9P3JjXDfqBdU7betMW6ac';
                }
            }
        }
    },
    table: {
        popoverRowsLength: 10,
        popoverColumnsLength: 10
    },
    toolbar: [
        ['bold', 'italic', 'underline', 'strikeThrough', 'superscript', 'subscript'],
        ['fontName', 'fontSize', 'color'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
        ['cut', 'copy', 'delete', 'removeFormat', 'undo', 'redo'],
        ['paragraph', 'blockquote', 'removeBlockquote', 'horizontalLine', 'orderedList', 'unorderedList'],
        ['link', 'unlink', 'image', 'video', 'table']
    ]
};

class FileUtils {
    constructor(_fileName, _fileType, _fileSize) {
        this._fileName = _fileName;
        this._fileType = _fileType;
        this._fileSize = _fileSize;
    }
    get fileName() {
        return this._fileName;
    }
    set fileName(_fileName) {
        this._fileName = _fileName;
    }
    get fileType() {
        return this._fileType;
    }
    set fileType(_fileType) {
        this._fileType = _fileType;
    }
    get supportedFileTypes() {
        return this._supportedFileTypes;
    }
    set supportedFileTypes(_supportedFileTypes) {
        this._supportedFileTypes = _supportedFileTypes;
    }
    get maximumFileSize() {
        return this._maximumFileSize;
    }
    set maximumFileSize(_maximumFileSize) {
        this._maximumFileSize = _maximumFileSize;
    }
    isValidFileType() {
        return this._supportedFileTypes.indexOf(this._fileType) !== -1;
    }
    isValidFileSize() {
        return this._fileSize <= this._maximumFileSize;
    }
}

class Constants {
}
Constants.SUPPORTED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/gif'];
Constants.MAXIMUM_IMAGE_SIZE = 1024 * 1024;

class NgxEditorToolbarComponent {
    constructor(_popOverConfig, _formBuilder, _messageService, _commandExecutorService) {
        this._popOverConfig = _popOverConfig;
        this._formBuilder = _formBuilder;
        this._messageService = _messageService;
        this._commandExecutorService = _commandExecutorService;
        this.customButtonsArray = [];
        this.execute = new EventEmitter();
        this.triggerCustomClick = new EventEmitter();
        this.focusTextArea = new EventEmitter();
        this.triggerInsertImage = new EventEmitter();
        this.triggerInsertHtml = new EventEmitter();
        this.triggerInsertTable = new EventEmitter();
        this.showPopOver = new EventEmitter();
        this.hidePopOver = new EventEmitter();
        this.uploadComplete = true;
        this.updloadPercentage = 0;
        this.isUploading = false;
        this.selectedColorTab = 'textColor';
        this.fontName = '';
        this.fontSize = '';
        this.hexColor = '';
        this.isImageUploader = true;
        this.urlPattern = /https?:\/\/.+/;
        this.activeButtonArray = {
            bold: false,
            italic: false,
            underline: false,
            superscript: false,
            subscript: false,
            orderedlist: false,
            unorderedlist: false,
            blockquote: false,
            removeblockquote: false,
            strikethrough: false
        };
        this.isMoreShow = false;
        this.moreButtonText = '';
        this.tablePopoverData = {
            tablePopoverRowColumnBoxArray: [],
            popoverRowsLength: 0,
            popoverColumnsLength: 0,
            selectedTablePopoverRowIndex: -1,
            selectedTablePopoverColumnIndex: -1
        };
        this._popOverConfig.outsideClick = true;
        this._popOverConfig.placement = 'bottom';
        this._popOverConfig.container = 'body';
    }
    ngOnInit() {
        this.isMoreShow = this.config['isMoreShow'] || false;
        this.showLessOrMore(this.isMoreShow);
        this.buildUrlForm();
        this.buildImageForm();
        this.buildVideoForm();
        this.initTablePopover();
    }
    canEnableToolbarOptions(value) {
        return canEnableToolbarOptions(value, this.config['toolbar']);
    }
    triggerCommand(command) {
        if (!this._commandExecutorService.savedSelection) {
            this.focusTextArea.emit();
        }
        if (command === 'removeFormat') {
            this.clearActiveButtonWhileErase();
        }
        else {
            this.activeButtonArray[command.toLowerCase()] = !this.activeButtonArray[command.toLowerCase()];
        }
        this.execute.emit(command);
    }
    clearActiveButtonWhileErase() {
        const                  formattedButton = ['bold', 'italic', 'underline', 'superscript', 'subscript', 'strikethrough'];
        formattedButton.forEach(btn => {
            this.activeButtonArray[btn] = false;
        });
    }
    buildUrlForm(setFocus = false) {
        if (setFocus) {
            this.focusTextArea.emit();
        }
        this.urlForm = this._formBuilder.group({
            urlLink: ['', [Validators.required]],
            urlText: ['', [Validators.required]],
            urlNewTab: [true]
        });
    }
    insertLink() {
        try {
            this._commandExecutorService.createLink(this.urlForm.value);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildUrlForm();
        this.urlPopover.hide();
    }
    buildImageForm() {
        this.imageForm = this._formBuilder.group({
            imageUrl: ['', [Validators.required]]
        });
    }
    buildVideoForm() {
        this.videoForm = this._formBuilder.group({
            videoUrl: ['', [Validators.required]],
            height: [''],
            width: ['']
        });
    }
    onFileChange(e) {
        if (e.target.files.length > 0) {
            const                  file = e.target.files[0];
            const                  imageConfig = this.config.image;
            const                  fileUtilsObj = new FileUtils(file.name, file.type, file.size);
            fileUtilsObj.supportedFileTypes = imageConfig.supportedFileTypes || Constants.SUPPORTED_IMAGE_TYPES;
            fileUtilsObj.maximumFileSize = imageConfig.maximumFileSize || Constants.MAXIMUM_IMAGE_SIZE;
            if (!fileUtilsObj.isValidFileType()) {
                this._messageService.sendMessage('FILE_TYPE_INVALID');
                this.buildImageForm();
                this.imagePopover.hide();
                return;
            }
            if (!fileUtilsObj.isValidFileSize()) {
                this._messageService.sendMessage('FILE_SIZE_INVALID');
                this.buildImageForm();
                this.imagePopover.hide();
                return;
            }
            this.uploadComplete = false;
            this.isUploading = true;
            try {
                this._commandExecutorService.uploadImage(file, imageConfig.apiDetail).subscribe(event => {
                    if (event instanceof HttpResponse) {
                        try {
                            this.triggerInsertImage.emit(event.body.url);
                        }
                        catch (                 error) {
                            this._messageService.sendMessage(error.message);
                        }
                        this.buildImageForm();
                        this.imagePopover.hide();
                        this.updloadPercentage = 100;
                        this.uploadComplete = true;
                        this.isUploading = false;
                    }
                }, error => {
                    if (error instanceof HttpErrorResponse) {
                        this.buildImageForm();
                        this.imagePopover.hide();
                        this._messageService.sendMessage('SERVICE_FAILED');
                        this.uploadComplete = true;
                        this.isUploading = false;
                    }
                });
            }
            catch (                 error) {
                this._messageService.sendMessage(error.message);
                this.uploadComplete = true;
                this.isUploading = false;
            }
        }
    }
    insertImage() {
        try {
            this.triggerInsertImage.emit(this.imageForm.value.imageUrl);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildImageForm();
        this.imagePopover.hide();
    }
    insertVideo() {
        try {
            this._commandExecutorService.insertVideo(this.videoForm.value);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.buildVideoForm();
        this.videoPopover.hide();
    }
    insertColor(color, where) {
        try {
            this._commandExecutorService.insertColor(color, where);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.colorPopover.hide();
    }
    setFontSize(fontSize) {
        try {
            this._commandExecutorService.setFontSize(fontSize);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.fontSizePopover.hide();
    }
    setFontName(fontName) {
        try {
            this._commandExecutorService.setFontName(fontName);
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
        this.fontSizePopover.hide();
    }
    onlyNumbers(event) {
        return !isNaN(                 (event.key));
    }
    triggerCustomButtonClick(btnText) {
        this.triggerCustomClick.emit(btnText);
    }
    onShownImagePopOver() {
        this.showPopOver.emit();
    }
    onHideImagePopOver() {
        this.hidePopOver.emit();
    }
    onShownTablePopOver() {
        this.showPopOver.emit();
    }
    onHideTablePopOver() {
        this.hidePopOver.emit();
    }
    toggleShowLessOrMore() {
        this.showLessOrMore(!this.isMoreShow);
    }
    showLessOrMore(isMoreShow) {
        this.isMoreShow = isMoreShow;
        if (isMoreShow) {
            this.moreButtonText = this.languageObj.SHOW_LESS;
        }
        else {
            this.moreButtonText = this.languageObj.SHOW_MORE;
        }
    }
    initTablePopover() {
        this.tablePopoverData.tablePopoverRowsLength = this.config['table']['popoverRowsLength'];
        this.tablePopoverData.tablePopoverColumnsLength = this.config['table']['popoverColumnsLength'];
        for (let                  rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex] = [];
            for (let                  colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex] = {
                    isHighlight: false
                };
            }
        }
    }
    resetTablePopoverData() {
        this.tablePopoverData.selectedTablePopoverRowIndex = -1;
        this.tablePopoverData.selectedTablePopoverColumnIndex = -1;
        for (let                  rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            for (let                  colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = false;
            }
        }
    }
    onMouseEnterRowColumnBox(selectedRowIndex, selectedColIndex) {
        this.tablePopoverData.selectedTablePopoverRowIndex = selectedRowIndex;
        this.tablePopoverData.selectedTablePopoverColumnIndex = selectedColIndex;
        for (let                  rowIndex = 0; rowIndex < this.tablePopoverData.tablePopoverRowsLength; rowIndex++) {
            for (let                  colIndex = 0; colIndex < this.tablePopoverData.tablePopoverColumnsLength; colIndex++) {
                let                  isHighlight = false;
                if (rowIndex <= selectedRowIndex && colIndex <= selectedColIndex) {
                    isHighlight = true;
                }
                this.tablePopoverData.tablePopoverRowColumnBoxArray[rowIndex][colIndex]['isHighlight'] = isHighlight;
            }
        }
    }
    onMouseLeaveRowColumnBoxContainer() {
        this.resetTablePopoverData();
    }
    onClickRowColumnBox(selectedRowIndex, selectedColIndex) {
        this.tablePopover.hide();
        this.resetTablePopoverData();
        this.triggerInsertTable.emit({
            totalTableRows: selectedRowIndex + 1,
            totalTableColumns: selectedColIndex + 1
        });
    }
}
NgxEditorToolbarComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-ngx-editor-toolbar',
                template: `<div class="ngx-toolbar" *ngIf="config['showToolbar']">
  <div class="ngx-toolbar-set" [ngClass]="{'width-70': customButtonsArray && customButtonsArray.length}">
    <button [ngClass]="activeButtonArray['bold']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('bold')" (click)="triggerCommand('bold')"
      title="{{languageObj.BOLD}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-bold" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['italic']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('italic')" (click)="triggerCommand('italic')"
      title="{{languageObj.ITALIC}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-italic" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['underline']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('underline')" (click)="triggerCommand('underline')"
      title="{{languageObj.UNDERLINE}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-underline" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['strikethrough']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('strikeThrough')" (click)="triggerCommand('strikeThrough')"
      title="{{languageObj.STRIKETHROUGH}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-strikethrough" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['superscript']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('superscript')" (click)="triggerCommand('superscript')"
      title="{{languageObj.SUPERSCRIPT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-superscript" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['subscript']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('subscript') && isMoreShow" (click)="triggerCommand('subscript')"
      title="{{languageObj.SUBSCRIPT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-subscript" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('fontName') && isMoreShow" (click)="fontName = ''" title="{{languageObj.FONT_FAMILY}}"
      [popover]="fontNameTemplate" #fontNamePopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']">
      <i class="fa fa-font" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('fontSize') && isMoreShow" (click)="fontSize = ''" title="{{languageObj.FONT_SIZE}}"
      [popover]="fontSizeTemplate" #fontSizePopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']">
      <i class="fa fa-text-height" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('color') && isMoreShow" (click)="hexColor = ''" title="{{languageObj.COLOR_PICKER}}"
      [popover]="insertColorTemplate" #colorPopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']">
      <i class="fa fa-tint" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('justifyLeft') && isMoreShow" (click)="triggerCommand('justifyLeft')"
      title="{{languageObj.JUSTIFY_LEFT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-align-left" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('justifyCenter') && isMoreShow" (click)="triggerCommand('justifyCenter')"
      title="{{languageObj.JUSTIFY_CENTER}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-align-center" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('justifyRight') && isMoreShow" (click)="triggerCommand('justifyRight')"
      title="{{languageObj.JUSTIFY_RIGHT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-align-right" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('justifyFull') && isMoreShow" (click)="triggerCommand('justifyFull')"
      title="{{languageObj.JUSTIFY}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-align-justify" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('indent') && isMoreShow" (click)="triggerCommand('indent')"
      title="{{languageObj.INDENT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-indent" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('outdent') && isMoreShow" (click)="triggerCommand('outdent')"
      title="{{languageObj.OUTDENT}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-outdent" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('cut') && isMoreShow" (click)="triggerCommand('cut')" title="{{languageObj.CUT}}"
      [disabled]="!config['enableToolbar']">
      <i class="fa fa-scissors" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('copy') && isMoreShow" (click)="triggerCommand('copy')"
      title="{{languageObj.COPY}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-files-o" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('delete')" (click)="triggerCommand('delete')"
      title="{{languageObj.DELETE}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-trash" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('removeFormat') && isMoreShow" (click)="triggerCommand('removeFormat')"
      title="{{languageObj.CLEAR_FORMATTING}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-eraser" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('undo') && isMoreShow" (click)="triggerCommand('undo')"
      title="{{languageObj.UNDO}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-undo" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('redo') && isMoreShow" (click)="triggerCommand('redo')"
      title="{{languageObj.REDO}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-repeat" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('paragraph') && isMoreShow" (click)="triggerCommand('insertParagraph')"
      title="{{languageObj.PARAGRAPH}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-paragraph" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['blockquote']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('blockquote') && isMoreShow" (click)="triggerCommand('blockquote')"
      title="{{languageObj.BLOCKQUOTE}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-quote-left" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['removeblockquote']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('removeBlockquote') && isMoreShow" (click)="triggerCommand('removeBlockquote')"
      title="{{languageObj.REMOVE_BLOCKQUOTE}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-quote-right" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('horizontalLine') && isMoreShow" (click)="triggerCommand('insertHorizontalRule')"
      title="{{languageObj.HORIZONTAL_LINE}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-minus" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['insertunorderedlist']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('unorderedList') && isMoreShow" (click)="triggerCommand('insertUnorderedList')"
      title="{{languageObj.UNORDERED_LIST}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-list-ul" aria-hidden="true"></i>
    </button>
    <button [ngClass]="activeButtonArray['insertorderedlist']==true?'active':''" type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('orderedList') && isMoreShow" (click)="triggerCommand('insertOrderedList')"
      title="{{languageObj.ORDERED_LIST}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-list-ol" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('link') && isMoreShow" (click)="buildUrlForm(true)" [popover]="insertLinkTemplate"
      title="{{languageObj.INSERT_LINK}}" #urlPopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']">
      <i class="fa fa-link" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('unlink') && isMoreShow" (click)="triggerCommand('unlink')"
      title="{{languageObj.UNLINK}}" [disabled]="!config['enableToolbar']">
      <i class="fa fa-chain-broken" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('image') && isMoreShow" (click)="buildImageForm()" title="{{languageObj.INSERT_IMAGE}}"
      [popover]="insertImageTemplate" #imagePopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']"
      (onShown)="onShownImagePopOver()" (onHidden)="onHideImagePopOver()">
      <i class="fa fa-picture-o" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('video') && isMoreShow" (click)="buildVideoForm()" title="{{languageObj.INSERT_VIDEO}}"
      [popover]="insertVideoTemplate" #videoPopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']">
      <i class="fa fa-youtube-play" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" *ngIf="canEnableToolbarOptions('table') && isMoreShow" title="{{languageObj.INSERT_TABLE}}"
      [popover]="insertTableTemplate" #tablePopover="bs-popover" containerClass="ngxePopover" [disabled]="!config['enableToolbar']"
      (onShown)="onShownTablePopOver()" (onHidden)="onHideTablePopOver()">
      <i class="fa fa-table" aria-hidden="true"></i>
    </button>
    <button type="button" class="ngx-editor-button" [title]="moreButtonText" (click)="toggleShowLessOrMore()">
      <i [ngClass]="isMoreShow ? 'fa fa-caret-up' : 'fa fa-caret-down'" aria-hidden="true"></i>
    </button>
  </div>
  <!-- Custom buttons -->
  <div class="custom-button-container" *ngIf="customButtonsArray && customButtonsArray.length">
    <ng-container *ngFor="let customButton of customButtonsArray">
        <button *ngIf="customButton.icon" type="button" class="ngx-editor-button" title="{{customButton.title || customButton.value}}" (click)="!customButton.disabled && triggerCustomButtonClick(customButton.btnText)" [disabled]="customButton.disabled"><i class="{{customButton.icon}}" aria-hidden="true"></i>
        </button>
        <button *ngIf="!customButton.icon" type="button" class="ngx-editor-button" title="{{customButton.title || customButton.value}}" (click)="!customButton.disabled && triggerCustomButtonClick(customButton.btnText)" [disabled]="customButton.disabled">{{customButton.value}}
        </button>
    </ng-container>
  </div>
</div>

<!-- URL Popover template -->
<ng-template #insertLinkTemplate>
  <div class="ngxe-popover extra-gt">
    <form [formGroup]="urlForm" (ngSubmit)="urlForm.valid && insertLink()" autocomplete="off">
      <div class="form-group">
        <label for="urlInput" class="small">URL</label>
        <input type="text" class="form-control-sm" id="URLInput" placeholder="URL" formControlName="urlLink" required [pattern]="urlPattern">
      </div>
      <div class="form-group">
        <label for="urlTextInput" class="small">Text</label>
        <input type="text" class="form-control-sm" id="urlTextInput" placeholder="Text" formControlName="urlText" required>
      </div>
      <div class="form-check">
        <input type="checkbox" class="form-check-input" id="urlNewTab" formControlName="urlNewTab">
        <label class="form-check-label" for="urlNewTab">Open in new tab</label>
      </div>
      <button type="submit" class="btn-primary btn-sm btn" [disabled]="!urlForm.valid">{{languageObj.SUBMIT}}</button>
    </form>
  </div>
</ng-template>

<!-- Image Uploader Popover template -->
<ng-template #insertImageTemplate>
  <div class="ngxe-popover imgc-ctnr">
    <div class="imgc-topbar btn-ctnr">
      <button type="button" class="btn" [ngClass]="{active: isImageUploader}" (click)="isImageUploader = true">
        <i class="fa fa-upload"></i>
      </button>
      <button type="button" class="btn" [ngClass]="{active: !isImageUploader}" (click)="isImageUploader = false">
        <i class="fa fa-link"></i>
      </button>
    </div>
    <div class="imgc-ctnt is-image">
      <div *ngIf="isImageUploader; else insertImageLink"> </div>
      <div *ngIf="!isImageUploader; else imageUploder"> </div>
      <ng-template #imageUploder>
        <div class="ngx-insert-img-ph">
          <p *ngIf="uploadComplete">{{languageObj.CHOOSE_IMAGE}}</p>
          <p *ngIf="!uploadComplete">
            <span>{{languageObj.UPLOADING_IMAGE}}</span>
            <br>
            <span>{{ updloadPercentage }} %</span>
          </p>
          <div class="ngxe-img-upl-frm">
            <input type="file" (change)="onFileChange($event)" accept="image/*" [disabled]="isUploading" />
          </div>
        </div>
      </ng-template>
      <ng-template #insertImageLink>
        <form class="extra-gt" [formGroup]="imageForm" (ngSubmit)="imageForm.valid && insertImage()" autocomplete="off">
          <div class="form-group">
            <label for="imageURLInput" class="small">{{languageObj.URL}}</label>
            <input type="text" class="form-control-sm" id="imageURLInput" placeholder="{{languageObj.URL}}" formControlName="imageUrl" required>
          </div>
          <button type="submit" class="btn-primary btn-sm btn">{{languageObj.SUBMIT}}</button>
        </form>
      </ng-template>
      <div class="progress" *ngIf="!uploadComplete">
        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" [ngClass]="{'bg-danger': updloadPercentage<20, 'bg-warning': updloadPercentage<50, 'bg-success': updloadPercentage>=100}"
          [style.width.%]="updloadPercentage"></div>
      </div>
    </div>
  </div>
</ng-template>


<!-- Insert Video Popover template -->
<ng-template #insertVideoTemplate>
  <div class="ngxe-popover imgc-ctnr">
    <div class="imgc-topbar btn-ctnr">
      <button type="button" class="btn active">
        <i class="fa fa-link"></i>
      </button>
    </div>
    <div class="imgc-ctnt is-image">
      <form class="extra-gt" [formGroup]="videoForm" (ngSubmit)="videoForm.valid && insertVideo()" autocomplete="off">
        <div class="form-group">
          <label for="videoURLInput" class="small">{{languageObj.URL}}</label>
          <input type="text" class="form-control-sm" id="videoURLInput" placeholder="{{languageObj.URL}}" formControlName="videoUrl" required>
        </div>
        <div class="row form-group">
          <div class="col">
            <input type="text" class="form-control-sm" formControlName="height" placeholder="{{languageObj.HEIGHT_PX}}" (keypress)="onlyNumbers($event)">
          </div>
          <div class="col">
            <input type="text" class="form-control-sm" formControlName="width" placeholder="{{languageObj.WIDTH_PX}}" (keypress)="onlyNumbers($event)">
          </div>
          <label class="small">{{languageObj.HEIGHT_WIDTH}}</label>
        </div>
        <button type="submit" class="btn-primary btn-sm btn">{{languageObj.SUBMIT}}</button>
      </form>
    </div>
  </div>
</ng-template>

<!-- Insert color template -->
<ng-template #insertColorTemplate>
  <div class="ngxe-popover imgc-ctnr">
    <div class="imgc-topbar two-tabs">
      <span (click)="selectedColorTab ='textColor'" [ngClass]="{active: selectedColorTab ==='textColor'}">{{languageObj.TEXT}}</span>
      <span (click)="selectedColorTab ='backgroundColor'" [ngClass]="{active: selectedColorTab ==='backgroundColor'}">{{languageObj.BACKGROUND}}</span>
    </div>
    <div class="imgc-ctnt is-color extra-gt1">
      <form autocomplete="off">
        <div class="form-group">
          <label for="hexInput" class="small">{{languageObj.HEX_COLOR}}</label>
          <input type="text" class="form-control-sm" id="hexInput" name="hexInput" maxlength="7" placeholder="{{languageObj.HEX_COLOR}}" [(ngModel)]="hexColor"
            required>
        </div>
        <button type="button" class="btn-primary btn-sm btn" (click)="insertColor(hexColor, selectedColorTab)">{{languageObj.SUBMIT}}</button>
      </form>
    </div>
  </div>
</ng-template>

<!-- font size template -->
<ng-template #fontSizeTemplate>
  <div class="ngxe-popover extra-gt1">
    <form autocomplete="off">
      <div class="form-group">
        <label for="fontSize" class="small">{{languageObj.FONT_SIZE}}</label>
        <input type="text" class="form-control-sm" id="fontSize" name="fontSize" placeholder="{{languageObj.FONT_SIZE_IN_PXREM}}" [(ngModel)]="fontSize"
          required>
      </div>
      <button type="button" class="btn-primary btn-sm btn" (click)="setFontSize(fontSize)">{{languageObj.SUBMIT}}</button>
    </form>
  </div>
</ng-template>

<!-- font family/name template -->
<ng-template #fontNameTemplate>
  <div class="ngxe-popover extra-gt1">
    <form autocomplete="off">
      <div class="form-group">
        <label for="fontSize" class="small">{{languageObj.FONT_SIZE}}</label>
        <input type="text" class="form-control-sm" id="fontSize" name="fontName" placeholder="{{languageObj.EX_TIMES_NEW_ROMAN_TIMES_SERIF}}"
          [(ngModel)]="fontName" required>
      </div>
      <button type="button" class="btn-primary btn-sm btn" (click)="setFontName(fontName)">{{languageObj.SUBMIT}}</button>
    </form>
  </div>
</ng-template>

<!-- Table Popover template -->
<ng-template #insertTableTemplate>
  <div class="ngxe-popover tbl-popover-ctnr">
    <div class="row-column-box-ctnr" (mouseleave)="onMouseLeaveRowColumnBoxContainer()">
      <div class="row-column-box-row" *ngFor="let rowColumnBoxRow of tablePopoverData.tablePopoverRowColumnBoxArray; let rowIndex = index;">
        <span *ngFor="let rowColumnBox of rowColumnBoxRow; let colIndex = index;" class="row-column-box"
          [ngClass]="{'highlight': rowColumnBox['isHighlight']}"
          (mouseenter)="onMouseEnterRowColumnBox(rowIndex, colIndex)"
          (click)="onClickRowColumnBox(rowIndex, colIndex)"></span>
      </div>
    </div>

    <div class="selected-row-column-count">
      {{tablePopoverData.selectedTablePopoverRowIndex + 1}} x {{tablePopoverData.selectedTablePopoverColumnIndex + 1}}
    </div>
  </div>
</ng-template>
`,
                styles: [`::ng-deep .ngxePopover.popover{position:absolute;top:0;left:0;z-index:1060;display:block;max-width:276px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";font-style:normal;font-weight:400;line-height:1.5;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;letter-spacing:normal;word-break:normal;word-spacing:normal;white-space:normal;line-break:auto;font-size:12.25px;word-wrap:break-word;background-color:#fff;background-clip:padding-box;border:1px solid rgba(0,0,0,.2);border-radius:4.2px}::ng-deep .ngxePopover.popover .arrow{position:absolute;display:block;width:14px;height:7px;margin:0 4.2px;border-width:0}::ng-deep .ngxePopover.popover .arrow::after,::ng-deep .ngxePopover.popover .arrow::before{position:absolute;display:block;content:"";border-color:transparent;border-style:solid}::ng-deep .ngxePopover.popover .popover-header{padding:7px 10.5px;margin-bottom:0;font-size:14px;color:inherit;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-top-left-radius:calc(4.2px - 1px);border-top-right-radius:calc(4.2px - 1px)}::ng-deep .ngxePopover.popover .popover-header:empty{display:none}::ng-deep .ngxePopover.popover .popover-body{padding:7px 10.5px!important;color:#212529}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top],::ng-deep .ngxePopover.popover.bs-popover-top{margin-bottom:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow,::ng-deep .ngxePopover.popover.bs-popover-top .arrow{bottom:calc((7px + 1px) * -1);margin-left:0!important}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::before{border-width:7px 7px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::before{bottom:0;border-top-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=top] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-top .arrow::after{bottom:1px;border-top-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right],::ng-deep .ngxePopover.popover.bs-popover-right{margin-left:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow,::ng-deep .ngxePopover.popover.bs-popover-right .arrow{left:calc((7px + 1px) * -1);width:7px;height:14px;margin:4.2px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::before{border-width:7px 7px 7px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::before{left:0;border-right-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=right] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-right .arrow::after{left:1px;border-right-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom],::ng-deep .ngxePopover.popover.bs-popover-bottom{margin-top:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow{left:45%!important;top:calc((7px + 1px) * -1);margin-left:0!important}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::before{border-width:0 7px 7px}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::before{top:0;border-bottom-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-bottom .arrow::after{top:1px;border-bottom-color:#fff;margin-left:0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=bottom] .popover-header::before,::ng-deep .ngxePopover.popover.bs-popover-bottom .popover-header::before{position:absolute;top:0;left:50%;display:block;width:1rem;margin-left:-7px;content:"";border-bottom:1px solid #f7f7f7}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left],::ng-deep .ngxePopover.popover.bs-popover-left{margin-right:.4rem}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow,::ng-deep .ngxePopover.popover.bs-popover-left .arrow{right:calc((7px + 1px) * -1);width:7px;height:14px;margin:4.2px 0}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::before{border-width:7px 0 7px 7px}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::before,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::before{right:0;border-left-color:rgba(0,0,0,.25)}::ng-deep .ngxePopover.popover.bs-popover-auto[x-placement^=left] .arrow::after,::ng-deep .ngxePopover.popover.bs-popover-left .arrow::after{right:1px;border-left-color:#fff;margin-left:0}::ng-deep .ngxePopover .btn{display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:5.25px 10.5px;font-size:14px;line-height:1.5;border-radius:3.5px;-webkit-transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-box-shadow .15s ease-in-out}::ng-deep .ngxePopover .btn.btn-sm{padding:3.5px 7px;font-size:12.25px;line-height:1.5;border-radius:2.8px}::ng-deep .ngxePopover .btn:active,::ng-deep .ngxePopover .btn:focus{outline:0;-webkit-box-shadow:none;box-shadow:none}::ng-deep .ngxePopover .btn.btn-primary{color:#fff;background-color:#007bff;border-color:#007bff}::ng-deep .ngxePopover .btn.btn-primary:hover{color:#fff;background-color:#0069d9;border-color:#0062cc}::ng-deep .ngxePopover .btn:not(:disabled):not(.disabled){cursor:pointer}::ng-deep .ngxePopover form .form-group{margin-bottom:14px}::ng-deep .ngxePopover form .form-group input{overflow:visible}::ng-deep .ngxePopover form .form-group .form-control-sm{width:100%;outline:0;border:none;border-bottom:1px solid #bdbdbd;border-radius:0;margin-bottom:1px;padding:3.5px 7px;font-size:12.25px;line-height:1.5}::ng-deep .ngxePopover form .form-group.row{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-left:0;margin-right:0}::ng-deep .ngxePopover form .form-group.row .col{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;max-width:100%;padding:0}::ng-deep .ngxePopover form .form-group.row .col:first-child{padding-right:15px}::ng-deep .ngxePopover form .form-check{position:relative;display:block;padding-left:17.5px}::ng-deep .ngxePopover form .form-check .form-check-input{position:absolute;margin-top:4.2px;margin-left:-17.5px}.ngx-toolbar{background-color:#f5f5f5;font-size:.8rem;padding:.2rem;border:1px solid #ddd}.ngx-toolbar .custom-button-container,.ngx-toolbar .ngx-toolbar-set{display:inline-block;border-radius:5px;background-color:transparent}.ngx-toolbar .custom-button-container .ngx-editor-button,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button{background-color:#fff;padding:.4rem;min-width:2.5rem;float:left;border:1px solid #ddd;border-right:transparent}.ngx-toolbar .custom-button-container .ngx-editor-button:hover,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:hover{cursor:pointer;background-color:#f1f1f1;-webkit-transition:.2s;transition:.2s}.ngx-toolbar .custom-button-container .ngx-editor-button.active,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button.active{color:#00f}.ngx-toolbar .custom-button-container .ngx-editor-button.focus,.ngx-toolbar .custom-button-container .ngx-editor-button:focus,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button.focus,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:focus{outline:0}.ngx-toolbar .custom-button-container .ngx-editor-button:last-child,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:last-child{border-right:1px solid #ddd;border-top-right-radius:5px;border-bottom-right-radius:5px}.ngx-toolbar .custom-button-container .ngx-editor-button:first-child,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:first-child{border-top-left-radius:5px;border-bottom-left-radius:5px}.ngx-toolbar .custom-button-container .ngx-editor-button:disabled,.ngx-toolbar .ngx-toolbar-set .ngx-editor-button:disabled{background-color:#f5f5f5;pointer-events:none;cursor:not-allowed}.ngx-toolbar .ngx-toolbar-set.width-70{width:70%}.custom-button-container{float:right}::ng-deep .popover{border-top-right-radius:0;border-top-left-radius:0}::ng-deep .ngxe-popover{min-width:210px;white-space:nowrap}::ng-deep .ngxe-popover .extra-gt,::ng-deep .ngxe-popover.extra-gt{padding-top:7px!important}::ng-deep .ngxe-popover .extra-gt1,::ng-deep .ngxe-popover.extra-gt1{padding-top:10.5px!important}::ng-deep .ngxe-popover .extra-gt2,::ng-deep .ngxe-popover.extra-gt2{padding-top:14px!important}::ng-deep .ngxe-popover .form-group label{display:none;margin:0}::ng-deep .ngxe-popover .form-group .form-control-sm{width:100%;outline:0;border:none;border-bottom:1px solid #bdbdbd;border-radius:0;margin-bottom:1px;padding-left:0;padding-right:0}::ng-deep .ngxe-popover .form-group .form-control-sm:active,::ng-deep .ngxe-popover .form-group .form-control-sm:focus{border-bottom:2px solid #1e88e5;-webkit-box-shadow:none;box-shadow:none;margin-bottom:0}::ng-deep .ngxe-popover .form-group .form-control-sm.ng-dirty.ng-invalid:not(.ng-pristine){border-bottom:2px solid red}::ng-deep .ngxe-popover .form-check{margin-bottom:14px}::ng-deep .ngxe-popover .btn:focus{-webkit-box-shadow:none!important;box-shadow:none!important}::ng-deep .ngxe-popover.imgc-ctnr{margin:-7px -10.5px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar{-webkit-box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);box-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 1px 1px rgba(0,0,0,.16);border-bottom:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button{background-color:transparent;border-radius:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button:hover{cursor:pointer;background-color:#f1f1f1;-webkit-transition:.2s;transition:.2s}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.btn-ctnr button.active{color:#007bff;-webkit-transition:.2s;transition:.2s;-webkit-box-shadow:none;box-shadow:none}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span{width:50%;text-align:center;display:inline-block;padding:5.6px 0;margin:0 -1px 2px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span:hover{cursor:pointer}::ng-deep .ngxe-popover.imgc-ctnr .imgc-topbar.two-tabs span.active{margin-bottom:-2px;border-bottom:2px solid #007bff;color:#007bff}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt{padding:7px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .progress{height:7px;margin:7px -7px -8.4px}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image p{margin:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph{border:2px dashed #bdbdbd;padding:25.2px 0;position:relative;letter-spacing:1px;text-align:center}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph:hover{background:#ebebeb}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm{opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;z-index:2147483640;overflow:hidden;margin:0;padding:0;width:100%}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm input{cursor:pointer;position:absolute;right:0;top:0;bottom:0;margin:0}::ng-deep .ngxe-popover.imgc-ctnr .imgc-ctnt.is-image .ngx-insert-img-ph .ngxe-img-upl-frm input[disabled]{cursor:not-allowed!important}::ng-deep .ngxe-popover.tbl-popover-ctnr{min-width:initial}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row{height:14px}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row span.row-column-box{display:inline-block;width:10px;height:10px;border:1px solid rgba(0,0,0,.2);border-radius:1px;margin:1px 2px}::ng-deep .ngxe-popover.tbl-popover-ctnr .row-column-box-ctnr .row-column-box-row span.row-column-box.highlight{border-color:#007bff}::ng-deep .ngxe-popover.tbl-popover-ctnr .selected-row-column-count{text-align:center}`],
                providers: [PopoverConfig]
            },] },
];
NgxEditorToolbarComponent.ctorParameters = () => [
    { type: PopoverConfig, },
    { type: FormBuilder, },
    { type: MessageService, },
    { type: CommandExecutorService, },
];
NgxEditorToolbarComponent.propDecorators = {
    "config": [{ type: Input },],
    "languageCode": [{ type: Input },],
    "languageObj": [{ type: Input },],
    "customButtonsArray": [{ type: Input },],
    "execute": [{ type: Output },],
    "triggerCustomClick": [{ type: Output },],
    "focusTextArea": [{ type: Output },],
    "triggerInsertImage": [{ type: Output },],
    "triggerInsertHtml": [{ type: Output },],
    "triggerInsertTable": [{ type: Output },],
    "showPopOver": [{ type: Output },],
    "hidePopOver": [{ type: Output },],
    "urlPopover": [{ type: ViewChild, args: ['urlPopover',] },],
    "imagePopover": [{ type: ViewChild, args: ['imagePopover',] },],
    "videoPopover": [{ type: ViewChild, args: ['videoPopover',] },],
    "fontSizePopover": [{ type: ViewChild, args: ['fontSizePopover',] },],
    "colorPopover": [{ type: ViewChild, args: ['colorPopover',] },],
    "tablePopover": [{ type: ViewChild, args: ['tablePopover',] },],
};

class NgxEditorComponent {
    constructor(_messageService, _commandExecutor, _renderer) {
        this._messageService = _messageService;
        this._commandExecutor = _commandExecutor;
        this._renderer = _renderer;
        this.resizer = 'stack';
        this.config = ngxEditorConfig;
        this.customButtonsArray = [];
        this.setFocus = false;
        this.pasteAsPlainText = false;
        this.languageCode = 'en';
        this.blur = new EventEmitter();
        this.focus = new EventEmitter();
        this.triggerCustomClick = new EventEmitter();
        this.change = new EventEmitter();
        this.optionClicked = new EventEmitter();
        this.triggerMessage = new EventEmitter();
        this.showPopOver = new EventEmitter();
        this.hidePopOver = new EventEmitter();
        this.Utils = Utils;
        this.IS_IE = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
        this.savedSelection = undefined;
        this.languageObj = {};
        this.TABLE_CONTAINER_CLASS = 'ngx-editor-table-container';
        this.TABLE_TEMPLATES = {
            COLUMN: `<td></td>`,
            ROW: `<tr>{tableRowCellsHtml}</tr>`,
            TABLE: `<div id="{tableContainerId}" class="${this.TABLE_CONTAINER_CLASS}">
      <table>
        <tbody>{tableRowsHtml}</tbody>
      </table>
    </div>`
        };
        this.tableCellContextMenuData = {
            items: [],
            style: {
                left: 0,
                top: 0
            },
            rowIndex: -1,
            columnIndex: -1,
            tableContainerId: ''
        };
    }
    ngOnInit() {
        this.languageObj = require('../i18n/' + this.languageCode + '.json');
        this.config = this.Utils.getEditorConfiguration(this.config, ngxEditorConfig, this.getCollectiveParams());
        this.height = this.height || this.textArea.nativeElement.offsetHeight;
        this.executeCommand('enableObjectResizing', false);
        this._messageService.getMessage().subscribe((message) => {
            this.triggerMessage.emit(message);
        });
        this.initializeNgxEditorTable();
    }
    ngOnChanges(changes) {
        if (changes && changes.setFocus && changes.setFocus.currentValue) {
            this.textArea.nativeElement.focus();
        }
    }
    ngAfterViewInit() {
        if (this.pasteAsPlainText) {
            this.pasteEventListener =
                this._renderer.listen(this.textArea.nativeElement, 'paste', this.executePasteAsPlainText.bind(this));
        }
    }
    ngOnDestroy() {
        if (this.pasteEventListener) {
            this.pasteEventListener();
        }
    }
    afterWriteNgxEditorValue() {
        this.bindNgxEditorTableContextMenuEvent();
    }
    onTextAreaFocus() {
        this.focus.emit('focus');
    }
    onEditorFocus() {
        this.textArea.nativeElement.focus();
    }
    onContentChange(html) {
        if (typeof this.onChange === 'function') {
            this.onChange(html);
            this.togglePlaceholder(html);
        }
        this.change.emit(html);
    }
    onTextAreaBlur(event) {
        this.saveSelection(saveSelection());
        if (typeof this.onTouched === 'function') {
            this.onTouched();
        }
        this.blur.emit(event);
    }
    onSelectionChange() {
        this.saveSelection(saveSelection());
        this.ngxToolbar.activeButtonArray = checkFormatting(window.getSelection());
    }
    resizeTextArea(offsetY) {
        let                  newHeight = parseInt(this.height, 10);
        newHeight += offsetY;
        this.height = newHeight + 'px';
        this.textArea.nativeElement.style.height = this.height;
    }
    executeCommand(commandName, emit = true) {
        try {
            this._commandExecutor.execute(commandName);
            if (emit) {
                this.optionClicked.emit();
            }
        }
        catch (                 error) {
            this._messageService.sendMessage(error.message);
        }
    }
    writeValue(value) {
        this.togglePlaceholder(value);
        if (value === null || value === undefined || value === '' || value === '<br>') {
            value = null;
        }
        this.refreshView(value);
        this.afterWriteNgxEditorValue();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    refreshView(value) {
        const                  normalizedValue = value === null ? '' : value;
        this._renderer.setProperty(this.textArea.nativeElement, 'innerHTML', normalizedValue);
    }
    togglePlaceholder(value) {
        if (!value || value === '<br>' || value === '') {
            this._renderer.addClass(this.ngxWrapper.nativeElement, 'show-placeholder');
        }
        else {
            this._renderer.removeClass(this.ngxWrapper.nativeElement, 'show-placeholder');
        }
    }
    getCollectiveParams() {
        return {
            editable: this.editable,
            spellcheck: this.spellcheck,
            placeholder: this.placeholder,
            translate: this.translate,
            height: this.height,
            minHeight: this.minHeight,
            width: this.width,
            minWidth: this.minWidth,
            enableToolbar: this.enableToolbar,
            showToolbar: this.showToolbar,
            imageEndPoint: this.imageEndPoint,
            toolbar: this.toolbar
        };
    }
    onTriggerCustomClick(btnText) {
        this.triggerCustomClick.emit(btnText);
    }
    focusTextArea() {
        setTimeout(() => {
            this.textArea.nativeElement.focus();
        }, 0);
    }
    executePasteAsPlainText(event) {
        event.preventDefault();
        let                  plainText = '';
        if (this.IS_IE) {
            if (window['clipboardData'] && window.getSelection) {
                plainText = window['clipboardData'].getData('Text').replace(/(?:\r\n|\r|\n)/g, '<br>');
                const                  element = document.createElement('span');
                element.innerHTML = plainText;
                const                  selectedRange = window.getSelection().getRangeAt(0);
                selectedRange.deleteContents();
                selectedRange.insertNode(element);
            }
        }
        else {
            const                  clipboardData = (event.originalEvent || event).clipboardData;
            const                  htmlContent = clipboardData.getData('text/html').trim();
            let                  imageListHtml = '';
            const                  divElement = document.createElement('div');
            divElement.innerHTML = htmlContent;
            const                  imageCollection = divElement.getElementsByTagName('img');
            for (let                  index = 0,                  length = imageCollection.length; index < length; index++) {
                const                  imageElement = imageCollection[index];
                imageListHtml += '<img alt="' + imageElement.alt + '" src="' + imageElement.src + '">' + '&nbsp;<br>';
            }
            if (htmlContent === '') {
                const                  itemList = clipboardData.items;
                for (let                  index = 0,                  length = itemList.length; index < length; index++) {
                    const                  item = itemList[index];
                    if (item.kind === 'file') {
                        const                  file = item.getAsFile();
                        const                  reader = new FileReader();
                        reader.onload = ($event) => {
                            const                  imageHtml = '<img src="' + $event.target.result + '">' + '&nbsp;<br>';
                            document.execCommand('insertHTML', false, imageHtml);
                        };
                        reader.readAsDataURL(file);
                    }
                }
            }
            plainText = (event.originalEvent || event).clipboardData.getData('text/plain');
            plainText = plainText.replace(/(?:\r\n|\r|\n)/g, '<br>');
            document.execCommand('insertHTML', false, imageListHtml + plainText);
        }
    }
    insertImage(imageURI) {
        if (!this.savedSelection) {
            this.saveSelection(this.getEditorElementRange());
        }
        this._commandExecutor.insertImage(imageURI);
    }
    onShowPopOver() {
        this.showPopOver.emit();
    }
    onHidePopOver() {
        this.hidePopOver.emit();
    }
    insertHtml(html) {
        if (!this.savedSelection) {
            this.saveSelection(this.getEditorElementRange());
        }
        this._commandExecutor.restoreSelectionAndInsertHtml(html, this.textArea.nativeElement);
    }
    insertTable(tableData) {
        const                  generateTableResponse = this.generateTableHtml(tableData.totalTableRows, tableData.totalTableColumns);
        this.insertHtml(generateTableResponse.templateHtml.replace(/\n/g, ''));
        this.focusElementInsideEditor(this._tblSelector(generateTableResponse.tableContainerId)
            + ' > tbody > tr:first-child > td:first-child');
        this.bindNgxEditorTableContextMenuEvent(generateTableResponse.tableContainerId);
    }
    initializeNgxEditorTable() {
        this.tableCellContextMenuData.items = [
            {
                label: this.languageObj.INSERT,
                items: [
                    {
                        label: this.languageObj.INSERT_ABOVE,
                        command: this.onInsertTableRowAbove.bind(this)
                    }, {
                        label: this.languageObj.INSERT_BELOW,
                        command: this.onInsertTableRowBelow.bind(this)
                    }, {
                        label: this.languageObj.INSERT_LEFT,
                        command: this.onInsertTableColumnBefore.bind(this)
                    }, {
                        label: this.languageObj.INSERT_RIGHT,
                        command: this.onInsertTableColumnAfter.bind(this)
                    }
                ]
            }, {
                label: this.languageObj.DELETE,
                items: [
                    {
                        label: this.languageObj.DELETE_ROW,
                        command: this.onDeleteTableRow.bind(this)
                    }, {
                        label: this.languageObj.DELETE_COLUMN,
                        command: this.onDeleteTableColumn.bind(this)
                    }, {
                        label: this.languageObj.DELETE_TABLE,
                        command: this.onDeleteTable.bind(this)
                    }
                ]
            }
        ];
    }
    bindNgxEditorTableContextMenuEvent(tableContainerId) {
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td')).forEach((tableCellElement) => {
            tableCellElement.addEventListener('contextmenu', this.onContextMenuTableCell.bind(this));
        });
    }
    bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber) {
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + rowNumber + ') > td'))
            .forEach((tableCellElement) => {
            tableCellElement.addEventListener('contextmenu', this.onContextMenuTableCell.bind(this));
        });
    }
    bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber) {
        Array.from(this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + columnNumber + ')'))
            .forEach((tableCellElement) => {
            tableCellElement.addEventListener('contextmenu', this.onContextMenuTableCell.bind(this));
        });
    }
    onContextMenuTableCell(event) {
        event.preventDefault();
        event.stopPropagation();
        this.tableCellContextMenuData.style.left = event.pageX;
        this.tableCellContextMenuData.style.top = event.pageY;
        const                  tableCellElement = event.currentTarget;
        const                  tableContainerElement = getClosest(tableCellElement, '.' + this.TABLE_CONTAINER_CLASS);
        this.tableCellContextMenuData.columnIndex = getIndex(tableCellElement);
        this.tableCellContextMenuData.rowIndex = getIndex(tableCellElement.parentElement);
        this.tableCellContextMenuData.tableContainerId = tableContainerElement.id;
        this.tableCellContextMenu.show();
        return false;
    }
    onInsertTableRowAbove(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  rowNumber = this.tableCellContextMenuData.rowIndex + 1;
        this.insertTableRow(tableContainerId, rowNumber);
        this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
    }
    onInsertTableRowBelow(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  rowNumber = this.tableCellContextMenuData.rowIndex + 2;
        this.insertTableRow(tableContainerId, rowNumber);
        this.bindNgxEditorTableRowContextMenuEvent(tableContainerId, rowNumber);
    }
    onInsertTableColumnBefore(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  columnNumber = this.tableCellContextMenuData.columnIndex + 1;
        this.insertTableColumn(tableContainerId, columnNumber);
        this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
    }
    onInsertTableColumnAfter(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  columnNumber = this.tableCellContextMenuData.columnIndex + 2;
        this.insertTableColumn(tableContainerId, columnNumber);
        this.bindNgxEditorTableColumnContextMenuEvent(tableContainerId, columnNumber);
    }
    onDeleteTableRow(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  rowNumber = this.tableCellContextMenuData.rowIndex + 1;
        this.deleteTableRow(tableContainerId, rowNumber);
    }
    onDeleteTableColumn(event) {
        const                  tableContainerId = this.tableCellContextMenuData.tableContainerId;
        const                  columnNumber = this.tableCellContextMenuData.columnIndex + 1;
        this.deleteTableColumn(tableContainerId, columnNumber);
    }
    onDeleteTable(event) {
        const                  tableContainerElement = this.textArea.nativeElement.querySelector('#' + this.tableCellContextMenuData.tableContainerId);
        tableContainerElement.querySelector('table').remove();
        if (tableContainerElement.innerHTML.trim() === '') {
            tableContainerElement.remove();
        }
        else {
            tableContainerElement.removeAttribute('id');
            tableContainerElement.removeAttribute('class');
        }
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    }
    saveSelection(savedSelection) {
        this.savedSelection = savedSelection;
        this._commandExecutor.savedSelection = savedSelection;
    }
    focusElementInsideEditor(elementCssSelector) {
        const                  range = this.getEditorElementRange(elementCssSelector);
        this.saveSelection(range);
        return restoreSelection(range);
    }
    getEditorElementRange(elementCssSelector) {
        const                  element = elementCssSelector ?
            this.textArea.nativeElement.querySelector(elementCssSelector) : this.textArea.nativeElement;
        const                  range = document.createRange();
        range.setStart(element, element.childNodes.length);
        return range;
    }
    generateTableHtml(totalTableRows, totalTableColumns) {
        const                  tableContainerId = 'table-container-' + Date.now().toString();
        let                  templateHtml = '',                  tableRowsHtml = '';
        for (let                  rowIndex = 0; rowIndex < totalTableRows; rowIndex++) {
            tableRowsHtml += this.TABLE_TEMPLATES.ROW.replace('{tableRowCellsHtml}', this.generateTableRowHtml(totalTableColumns));
        }
        templateHtml = this.TABLE_TEMPLATES.TABLE.replace('{tableRowsHtml}', tableRowsHtml)
            .replace(/{tableContainerId}/g, tableContainerId);
        return {
            templateHtml: templateHtml,
            tableContainerId: tableContainerId
        };
    }
    generateTableRowHtml(totalCells) {
        let                  tableRowHtml = '';
        for (let                  index = 0; index < totalCells; index++) {
            tableRowHtml += this.TABLE_TEMPLATES.COLUMN;
        }
        return tableRowHtml;
    }
    insertTableRow(tableContainerId, position) {
        let                  tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + position + ')');
        let                  whereToInsert = 'beforebegin';
        if (!tableRow) {
            tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
                + ' > tbody > tr:nth-child(' + (position - 1) + ')');
            whereToInsert = 'afterend';
        }
        const                  totalColumn = getImmediateChildrenUsingTagName(tableRow, 'td').length;
        tableRow.insertAdjacentHTML(whereToInsert, this.generateTableRowHtml(totalColumn).replace(/\n/g, ''));
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    }
    insertTableColumn(tableContainerId, position) {
        let                  tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + position + ')');
        let                  whereToInsert = 'beforebegin';
        if (tableColumnCellList.length === 0) {
            tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
                + ' > tbody > tr > td:nth-child(' + (position - 1) + ')');
            whereToInsert = 'afterend';
        }
        tableColumnCellList.forEach((tableColumnCell) => {
            tableColumnCell.insertAdjacentHTML(whereToInsert, this.TABLE_TEMPLATES.COLUMN.replace(/\n/g, ''));
        });
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    }
    deleteTableRow(tableContainerId, position) {
        const                  tableRow = this.textArea.nativeElement.querySelector(this._tblSelector(tableContainerId)
            + ' > tbody > tr:nth-child(' + position + ')');
        tableRow.remove();
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    }
    deleteTableColumn(tableContainerId, position) {
        const                  tableColumnCellList = this.textArea.nativeElement.querySelectorAll(this._tblSelector(tableContainerId)
            + ' > tbody > tr > td:nth-child(' + position + ')');
        tableColumnCellList.forEach((tableColumnCell) => {
            tableColumnCell.remove();
        });
        triggerContentEditableInputEvent(this.textArea.nativeElement);
    }
    _tblSelector(tableContainerId) {
        return 'div.' + this.TABLE_CONTAINER_CLASS
            + (tableContainerId ? '#' + tableContainerId : '')
            + ' > table';
    }
}
NgxEditorComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-ngx-editor',
                template: `<div class="ngx-editor" id="ngxEditor" [style.width]="config['width']" [style.minWidth]="config['minWidth']" tabindex="0"
  (focus)="onEditorFocus()">

  <app-ngx-editor-toolbar #ngxToolbar [languageCode]="languageCode" [languageObj]="languageObj" [config]="config" [customButtonsArray]="customButtonsArray" 
    (execute)="executeCommand($event)" (triggerCustomClick)="onTriggerCustomClick($event)" (focusTextArea)="focusTextArea()"
    (triggerInsertImage)="insertImage($event)" (triggerInsertHtml)="insertHtml($event)" (showPopOver)="onShowPopOver()" 
    (hidePopOver)="onHidePopOver()" (triggerInsertTable)="insertTable($event)"></app-ngx-editor-toolbar>

  <!-- text area -->
  <div class="ngx-wrapper" #ngxWrapper>
    <div #ngxTextArea id="ngxEditorTextarea" class="ngx-editor-textarea" [attr.contenteditable]="config['editable']" 
      [attr.translate]="config['translate']" [attr.spellcheck]="config['spellcheck']" [style.height]="config['height']" 
      [style.minHeight]="config['minHeight']" [style.resize]="Utils?.canResize(resizer)" (input)="onContentChange($event.target.innerHTML)"
      (focus)="onTextAreaFocus()" (blur)="onTextAreaBlur($event)" (click)="onSelectionChange()" (keyup)="onSelectionChange()">
    </div>

    <span class="ngx-editor-placeholder">{{ placeholder || config['placeholder'] }}</span>
  </div>
</div>

<p-contextMenu #tableCellContextMenu [model]="tableCellContextMenuData.items" appendTo="body"
  styleClass="table-cell-context-menu"
  [style]="{'left': tableCellContextMenuData.style.left + 'px', 'top': tableCellContextMenuData.style.top + 'px'}">
</p-contextMenu>
`,
                styles: [`.ngx-editor{position:relative}.ngx-editor ::ng-deep [contenteditable=true]:empty:before{content:normal;display:block;color:#868e96;opacity:1}.ngx-editor .ngx-wrapper{position:relative}.ngx-editor .ngx-wrapper .ngx-editor-textarea{min-height:5rem;padding:.5rem .8rem 1rem;border:1px solid #ddd;background-color:#fff;overflow-x:auto;overflow-y:auto;z-index:2;position:relative}.ngx-editor .ngx-wrapper .ngx-editor-textarea.focus,.ngx-editor .ngx-wrapper .ngx-editor-textarea:focus{outline:0}.ngx-editor .ngx-wrapper .ngx-editor-textarea ::ng-deep blockquote{margin-left:1rem;border-left:.2em solid #dfe2e5;padding-left:.5rem}.ngx-editor .ngx-wrapper ::ng-deep p{margin-bottom:0}.ngx-editor .ngx-wrapper .ngx-editor-placeholder{display:none;position:absolute;top:0;padding:.5rem .8rem 1rem .9rem;z-index:1;color:#6c757d;opacity:1}.ngx-editor .ngx-wrapper.show-placeholder .ngx-editor-placeholder{display:block}::ng-deep .ui-widget.ui-contextmenu{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;text-decoration:none;font-size:13px;background:#fff;width:200px}::ng-deep .ui-widget.ui-contextmenu.table-cell-context-menu{width:100px}::ng-deep .ui-widget.ui-contextmenu .ui-menuitem-link{color:#676a6c}::ng-deep .ui-widget.ui-contextmenu .ui-menuitem-link:hover{text-decoration:none}::ng-deep .ui-widget.ui-contextmenu .ui-submenu-list{background-color:#fff}`],
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => NgxEditorComponent),
                        multi: true
                    }
                ]
            },] },
];
NgxEditorComponent.ctorParameters = () => [
    { type: MessageService, },
    { type: CommandExecutorService, },
    { type: Renderer2, },
];
NgxEditorComponent.propDecorators = {
    "editable": [{ type: Input },],
    "spellcheck": [{ type: Input },],
    "placeholder": [{ type: Input },],
    "translate": [{ type: Input },],
    "height": [{ type: Input },],
    "minHeight": [{ type: Input },],
    "width": [{ type: Input },],
    "minWidth": [{ type: Input },],
    "toolbar": [{ type: Input },],
    "resizer": [{ type: Input },],
    "config": [{ type: Input },],
    "showToolbar": [{ type: Input },],
    "enableToolbar": [{ type: Input },],
    "imageEndPoint": [{ type: Input },],
    "customButtonsArray": [{ type: Input },],
    "setFocus": [{ type: Input },],
    "pasteAsPlainText": [{ type: Input },],
    "languageCode": [{ type: Input },],
    "blur": [{ type: Output },],
    "focus": [{ type: Output },],
    "triggerCustomClick": [{ type: Output },],
    "change": [{ type: Output },],
    "optionClicked": [{ type: Output },],
    "triggerMessage": [{ type: Output },],
    "showPopOver": [{ type: Output },],
    "hidePopOver": [{ type: Output },],
    "textArea": [{ type: ViewChild, args: ['ngxTextArea',] },],
    "ngxWrapper": [{ type: ViewChild, args: ['ngxWrapper',] },],
    "ngxToolbar": [{ type: ViewChild, args: ['ngxToolbar',] },],
    "tableCellContextMenu": [{ type: ViewChild, args: ['tableCellContextMenu',] },],
};

class NgxEditorModule {
}
NgxEditorModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule, FormsModule, ReactiveFormsModule, PopoverModule.forRoot(), ContextMenuModule],
                declarations: [NgxEditorComponent, NgxEditorToolbarComponent],
                exports: [NgxEditorComponent, PopoverModule],
                providers: [CommandExecutorService, MessageService]
            },] },
];

export { NgxEditorModule, CommandExecutorService as ɵc, MessageService as ɵb, NgxEditorToolbarComponent as ɵd, NgxEditorComponent as ɵa };
//# sourceMappingURL=ngx-editor.js.map
